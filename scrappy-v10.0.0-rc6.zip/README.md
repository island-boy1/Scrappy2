# Scrappy v10.0.0-rc3

Consolidated release candidate built from the verified v9.9.51 baseline.

## Included
- Existing 20-yard Georgia directory and inventory connectors
- Existing provenance, search, new-arrivals, saved-search and vehicle-detail behavior
- Pull-A-Part official inventory/photo/details and parts interchange
- EZ Pull N Pay Columbus ARIO investigation retained
- Full-site Diagnostics workspace
- Duplicate and data-quality audit
- Connector-classification audit
- VIN-service and Pull-A-Part dependency checks
- About/Data Sources release-status page
- `npm run check` static validation

## Deferred work
- S&W U Pull automated inventory access: pending permission
- Pick Your Part Fayetteville/Savannah: protected source
- Remaining fallback/direct-link yards: awaiting verified official enumeration
- Cross-device accounts/notifications and production hosting: require external infrastructure

Scrappy does not guess source IDs, invent VINs, bypass access controls, or promote fallback inventory without verified lineage.

## RC2
Diagnostic-only correction: baseline inventory uses the same fetchInventory array as /api/inventory; zero-row dependent checks are SKIPPED; per-yard inventory counts are shown.
