const state={inventory:[],yards:[],filtered:[],searchDiagnostics:[],coverage:null};
const $=id=>document.getElementById(id);
const norm=v=>(v??'').toString().trim().toLowerCase();
const compact=v=>norm(v).replace(/[^a-z0-9]+/g,'');
const arrivalFmt=new Intl.DateTimeFormat('en-US',{year:'numeric',month:'short',day:'numeric',timeZone:'UTC'});
function formatArrival(row){
 const raw=String(row?.arrival||row?.arrivalDate||'').trim(); if(!raw)return '—';
 const m=raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
 if(m){const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return arrivalFmt.format(d)}
 const mdy=raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
 if(mdy){let y=+mdy[3];if(y<100)y+=2000;return arrivalFmt.format(new Date(Date.UTC(y,+mdy[1]-1,+mdy[2])))}
 const d=new Date(raw);
 return Number.isNaN(d.getTime())?raw:arrivalFmt.format(d);
}
function detailField(label,value,cls=''){
 const missing=value===undefined||value===null||String(value).trim()==='';
 return `<div class="${missing?'detail-field-missing':''}"><strong>${esc(label)}</strong><span class="${cls}">${missing?'—':esc(value)}</span></div>`;
}
function resultFeature(row){
 if(row?.pullApart?.locID&&row?.pullApart?.ticketID&&row?.pullApart?.lineID) return '<span class="vehicle-feature" title="Official Pull-A-Part details and published photo are checked when opened">DETAILS + PHOTO</span>';
 if(row?.yardId==='pick-n-pull-jefferson'&&row?.vin) return '<span class="vehicle-feature" title="Fallback discovery record can be checked against the official Pick-n-Pull VIN detail page">VIN VERIFY</span>';
 if(row?.sourceUrl) return '<span class="vehicle-feature vehicle-feature-muted" title="Source page available">SOURCE PAGE</span>';
 return '';
}
function matches(value,query){return !query||norm(value).includes(query)||compact(value).includes(compact(query))}
async function load(make='',model=''){
 const selectedYard=$('yard')?.value||'';
 $('status').textContent=(make&&model)?'Querying live search-driven yards…':'Refreshing inventory…';
 try{
  const selectedYear=$('year')?.value||'';
  const url='/api/inventory'+(make&&model?('?make='+encodeURIComponent(make)+'&model='+encodeURIComponent(model)+(selectedYear?'&year='+encodeURIComponent(selectedYear):'')):'');
  const r=await fetch(url,{cache:'no-store'});
  if(!r.ok) throw new Error('Inventory request failed: '+r.status);
  const data=await r.json();
  state.inventory=data.inventory||[];state.yards=data.yards||[];state.searchDiagnostics=data.searchDiagnostics||[];state.coverage=data.coverage||null;
  populateFilters();
  if(selectedYard && state.yards.some(y=>y.id===selectedYard)) $('yard').value=selectedYard;
  renderYards();search();
  $('lastRefresh').textContent=new Date(data.generatedAt||Date.now()).toLocaleString();
  const q=state.searchDiagnostics.filter(x=>x.query);
  $('status').textContent=q.length?`${state.inventory.length.toLocaleString()} vehicles loaded · ${q.length} on-demand connector${q.length===1?'':'s'} checked`:`${state.inventory.length.toLocaleString()} vehicles loaded`;
 }catch(e){$('status').textContent='Source unavailable';$('empty').style.display='block';$('empty').innerHTML='<h2>Inventory source unavailable</h2><p>'+esc(e.message||'Start the server and try again.')+'</p>';}
}
function populateFilters(){
 const makes=[...new Set(state.inventory.map(x=>x.make).filter(Boolean))].sort();
 $('makes').innerHTML=makes.map(x=>`<option value="${esc(x)}"></option>`).join('');
 populateModelOptions();
 populateYearOptions();
 $('yard').innerHTML='<option value="">All yards</option>'+state.yards.map(y=>`<option value="${esc(y.id)}">${esc(y.name)}</option>`).join('');
}
function populateModelOptions(){
 const el=$('model'); if(!el)return;
 const current=el.value;
 const make=norm($('make')?.value);
 const models=[...new Set(state.inventory.filter(x=>!make||norm(x.make)===make).map(x=>x.model).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));
 el.innerHTML='<option value="">All models</option>'+models.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
 if(models.includes(current))el.value=current;
}
function populateYearOptions(){
 const from=$('yearFrom'),to=$('yearTo'); if(!from||!to)return;
 const oldFrom=from.value,oldTo=to.value;
 const years=[...new Set(state.inventory.map(x=>Number(x.year)).filter(Number.isFinite))].sort((a,b)=>b-a);
 from.innerHTML='<option value="">From</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
 to.innerHTML='<option value="">To</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
 if(years.includes(Number(oldFrom)))from.value=oldFrom;
 if(years.includes(Number(oldTo)))to.value=oldTo;
}
function sourceBadge(row){
 const trust=row.sourceTrust||'MANUAL';
 const label=row.sourceLabel||row.sourceType||'Source';
 const cls=trust==='OFFICIAL'?'source-official':trust==='FALLBACK'?'source-fallback':'source-public';
 return `<span class="source-pill ${cls}" title="${esc(label)}">${esc(trust)}</span>`;
}
function search(){
 const f={make:norm($('make').value),model:norm($('model').value),submodel:norm($('submodel').value),yearFrom:Number($('yearFrom')?.value)||null,yearTo:Number($('yearTo')?.value)||null,yard:norm($('yard').value),newOnly:$('newOnly').checked,liveOnly:$('liveOnly').checked};
 if(f.yearFrom&&f.yearTo&&f.yearFrom>f.yearTo){const t=f.yearFrom;f.yearFrom=f.yearTo;f.yearTo=t;}
 const cutoff=new Date(Date.now()-14*864e5);
 state.filtered=state.inventory.filter(x=>
  matches(x.make,f.make)&&matches(x.model,f.model)&&matches(x.submodel,f.submodel)&&(!f.yearFrom||Number(x.year)>=f.yearFrom)&&(!f.yearTo||Number(x.year)<=f.yearTo)&&(!f.yard||norm(x.yardId)===f.yard)&&(!f.liveOnly||x.verifiedSource===true)&&(!f.newOnly|| (x.arrivalDate && new Date(x.arrivalDate)>=cutoff))
 );
 $('resultCount').textContent=state.filtered.length.toLocaleString();
 $('yardCount').textContent=new Set(state.filtered.map(x=>x.yardId)).size;
 $('liveCount').textContent=new Set(state.filtered.filter(x=>x.verifiedSource===true).map(x=>x.yardId)).size;
 renderCoverageNote(f);
 $('results').innerHTML=state.filtered.slice(0,1000).map((row,i)=>`<tr class="result-row"><td data-label="Yard"><strong>${esc(row.yard)}</strong><br><span class="muted">${row.diy?'DIY / U-Pull':'Full service'}</span></td><td data-label="Year">${esc(row.year)}</td><td data-label="Make">${esc(row.make)}</td><td data-label="Model"><strong>${esc(row.model)}</strong><div>${resultFeature(row)}</div></td><td data-label="Sub model / trim">${esc(row.submodel||'—')}</td><td data-label="Body">${esc(row.body||'—')}</td><td data-label="Row">${esc(row.row||'—')}</td><td data-label="VIN / Stock"><span class="vin-stock">${esc(row.vin||row.stock||'—')}</span></td><td data-label="Arrival">${esc(formatArrival(row))}</td><td data-label="Source">${sourceBadge(row)}<div class="small">${esc(row.sourceLabel||'')}</div></td><td data-label="Detail"><button class="detail-btn" data-i="${i}">View</button></td></tr>`).join('');
 document.querySelectorAll('.detail-btn').forEach(b=>b.onclick=()=>openDetail(state.filtered[+b.dataset.i]));
 $('empty').style.display=state.filtered.length?'none':'block';
 renderMap();
}
function renderCoverageNote(f){
 const box=$('coverageNote'); if(!box)return; const c=state.coverage;
 if(!c){box.hidden=true;return}
 const hasVehicleQuery=!!(f.make&&f.model);
 const allYards=!f.yard;
 if(!allYards){box.hidden=true;return}
 box.hidden=false;
 if(hasVehicleQuery){
  box.innerHTML=`<strong>Statewide search coverage:</strong> ${c.configuredYards||20} yards configured. The ${c.searchDrivenYards||6} on-demand connectors were queried for this Make + Model. Protected/direct-link yards can only contribute when their official sites are accessible.`;
 }else{
  box.innerHTML=`<strong>Statewide inventory coverage:</strong> ${state.inventory.length.toLocaleString()} vehicles are currently enumerable from ${new Set(state.inventory.map(x=>x.yardId)).size} contributing yards. ${c.searchDrivenYards||6} additional yards require both Make + Model and are not included in this blank total. ${c.protectedYards||2} protected and ${c.directLinkOnlyYards||2} direct-link-only yards may not contribute inventory automatically.`;
 }
}

function renderYards(){
 $('yards').innerHTML=state.yards.map(y=>`<div class="yard"><h3>${esc(y.name)}</h3><p>${esc(y.city||'Georgia')} · ${y.diy?'DIY / U-Pull':'Full service'}</p><p>${esc(y.address||'')}</p><p><a class="yard-link" href="${esc(y.website)}" target="_blank">Official site / inventory</a> · <a class="yard-link" href="${esc(y.mapUrl)}" target="_blank">Map</a></p><span class="badge ${y.status==='live'?'':'off'}">${y.status==='live'?'LIVE CONNECTOR':(y.status==='verified'?'PUBLIC INVENTORY VERIFIED':'DIRECT LINK')}</span></div>`).join('');
}
function renderMap(){
 const seen=new Set();const rows=[];
 for(const x of state.filtered){if(seen.has(x.yardId))continue;const y=state.yards.find(v=>v.id===x.yardId);if(y){seen.add(x.yardId);rows.push(y)}}
 $('mapList').innerHTML=rows.map(y=>`<div class="map-pin"><div><strong>${esc(y.name)}</strong><small>${esc(y.city)}</small></div><a href="${esc(y.mapUrl)}" target="_blank">Directions</a></div>`).join('')||'<p class="muted">Search results will appear here as yard locations.</p>';
}
function saveAlert(){
 const a={make:$('make').value,model:$('model').value,submodel:$('submodel').value,yearFrom:$('yearFrom')?.value||'',yearTo:$('yearTo')?.value||'',yard:$('yard').value,created:new Date().toISOString()};
 const list=JSON.parse(localStorage.getItem('gja_alerts')||'[]');list.unshift(a);localStorage.setItem('gja_alerts',JSON.stringify(list.slice(0,20)));renderAlerts();$('alertMsg').textContent='Alert saved on this device.';
}
function renderAlerts(){const list=JSON.parse(localStorage.getItem('gja_alerts')||'[]');$('alerts').innerHTML=list.length?list.map((a,i)=>`<div class="alert"><span>${esc([a.year,a.make,a.model,a.submodel,a.yard||'All yards'].filter(Boolean).join(' · '))}</span><button data-i="${i}">Remove</button></div>`).join(''):'<p class="muted">No saved alerts.</p>';document.querySelectorAll('.alert button').forEach(b=>b.onclick=()=>{const l=JSON.parse(localStorage.getItem('gja_alerts')||'[]');l.splice(+b.dataset.i,1);localStorage.setItem('gja_alerts',JSON.stringify(l));renderAlerts()})}
async function decodeVIN(){const vin=$('vin').value.trim().toUpperCase();if(!vin){$('vinResult').textContent='Enter a VIN.';return}$('vinResult').textContent='Decoding…';try{const r=await fetch('/api/vin/'+encodeURIComponent(vin));const d=await r.json();const x=d.Results||[];const get=k=>(x.find(v=>v.Variable===k)||{}).Value||'';$('vinResult').innerHTML=`<strong>${esc(get('Model Year'))} ${esc(get('Make'))} ${esc(get('Model'))}</strong><br>${esc(get('Trim'))} ${esc(get('Drive Type'))}<br><span class="muted">${esc(get('Vehicle Type'))}</span>`}catch(e){$('vinResult').textContent='VIN decode unavailable.'}}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let liveTimer;
['make','model','submodel','yearFrom','yearTo','yard','newOnly','liveOnly'].forEach(id=>{ const el=$(id); if(!el)return; el.addEventListener('input',()=>{
 search();
 if(id==='make'||id==='model'){
  clearTimeout(liveTimer);
  const make=$('make').value.trim(),model=$('model').value.trim();
  if(make&&model) liveTimer=setTimeout(()=>runInventorySearch(),700);
 }
 });
});
async function runInventorySearch(){
 const make=$('make').value.trim(),model=$('model').value.trim(),yard=$('yard').value;
 const searchDriven=yard && (yard.startsWith('pull-apart-')||yard.startsWith('go-pull-it-'));
 if(searchDriven && (!make||!model)){
  $('status').textContent='This yard requires both Make and Model for live inventory search.';
  $('empty').style.display='block';
  $('empty').innerHTML='<h2>Make and Model required</h2><p>This yard uses an on-demand inventory search. Enter both fields, then click Search inventory.</p>';
  return;
 }
 const btn=$('searchBtn');
 if(btn){btn.disabled=true;btn.textContent='Searching live yards…';}
 try{
  if(make&&model){await load(make,model);await loadConnectorStatus();}
  else search();
 }finally{if(btn){btn.disabled=false;btn.textContent='Search inventory';}}
}
$('make').addEventListener('change',populateModelOptions);
$('make').addEventListener('input',populateModelOptions);
$('searchBtn').onclick=runInventorySearch;
$('clearBtn').onclick=()=>{['make','model','submodel','yearFrom','yearTo'].forEach(id=>$(id).value='');$('yard').value='';$('newOnly').checked=false;$('liveOnly').checked=false;load()};
$('refreshBtn').onclick=()=>load();$('saveAlert').onclick=saveAlert;$('decodeBtn').onclick=decodeVIN;
renderAlerts();

async function openDetail(row){
 $('detailModal').hidden=false;
 $('detailContent').innerHTML=`<div class="detail-head"><div><p class="eyebrow">VEHICLE DETAIL</p><h2>${esc(row.year)} ${esc(row.make)} ${esc(row.model)}</h2><p>${esc(row.submodel||'')} ${row.submodel?'· ':''}${esc(row.yard)}</p></div><div class="detail-head-badges">${sourceBadge(row)}${resultFeature(row)}</div></div><div class="detail-layout"><div class="detail-info-panel"><div class="detail-grid">${detailField('VIN',row.vin,'detail-vin')}${detailField('Stock',row.stock)}${detailField('Row',row.row)}${detailField('Arrival',row.arrival||row.arrivalDate?formatArrival(row):'')}${detailField('Body',row.body)}${detailField('Color',row.color)}${detailField('Engine',row.engine)}${detailField('Drive',row.drive)}</div>${row.verification?`<div class="source-detail fitment-detail"><strong>Fitment verification</strong><p class="muted">${esc(row.verification.status)} · ${row.verification.verified||0} verified · ${row.verification.pending||0} still to check</p>${(row.verification.checks||[]).map(c=>`<div class="small">${c.pass===true?'✓':c.pass===false?'✕':'•'} ${esc(c.label)}</div>`).join('')}</div>`:''}<div id="papExtended" class="source-detail" hidden></div><div class="source-detail provenance-card"><strong>Inventory provenance</strong><span>${esc(row.sourceLabel||row.sourceType||'Unknown')} · ${esc(row.sourceTrust||'MANUAL')}</span>${row.sourceTrust==='FALLBACK'?'<small>Fallback records should be verified with the yard before travel.</small>':''}</div><div class="detail-actions">${row.sourceUrl?`<a class="primary-link" href="${esc(row.sourceUrl)}" target="_blank" rel="noopener">Open source</a>`:''}${row.vin?`<button class="secondary" onclick="decodeDetailVIN('${esc(row.vin)}')">Decode VIN</button>`:''}</div><div id="detailDecode" class="vin-result"></div></div><div class="detail-media-panel"><div id="photoArea" class="photo-area photo-loading"><div class="photo-placeholder">Checking for a published vehicle photo…</div></div></div></div>`;
 if(row.yardId==='pick-n-pull-jefferson'&&row.vin){
  const box=$('papExtended'); box.hidden=false; box.innerHTML='<strong>Pick-n-Pull official verification</strong><p class="muted">Checking this fallback-discovered VIN against the official Pick-n-Pull vehicle detail page…</p>';
  try{
   const r=await fetch('/api/picknpull-vehicle?vin='+encodeURIComponent(row.vin)); const d=await r.json();
   if(d.verified){
    const pairs=Object.entries(d.details||{}).filter(([,v])=>v!=null&&String(v).trim());
    box.innerHTML=`<strong>Official Pick-n-Pull VIN verified</strong><p class="muted">The VIN was found on Pick-n-Pull's official vehicle-detail system. Discovery remains labeled FALLBACK because the full Jefferson list came from a third-party index.</p>${pairs.length?`<div class="detail-grid">${pairs.map(([k,v])=>`<div><strong>${esc(k.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase()))}</strong><span>${esc(v)}</span></div>`).join('')}</div>`:''}<div class="detail-actions"><a class="primary-link" href="${esc(d.url)}" target="_blank" rel="noopener">Open official vehicle page</a></div>`;
   }else box.innerHTML=`<strong>Official verification unavailable</strong><p class="muted">Scrappy could not verify this VIN on Pick-n-Pull's official vehicle-detail system. The discovery record remains FALLBACK.</p>`;
  }catch(e){box.innerHTML='<strong>Official verification unavailable</strong><p class="muted">The fallback record remains unverified. Confirm with the yard before travel.</p>'}
 }
 if(row.pullApart?.locID&&row.pullApart?.ticketID&&row.pullApart?.lineID){
  try{
   const q=new URLSearchParams({locID:row.pullApart.locID,ticketID:row.pullApart.ticketID,lineID:row.pullApart.lineID});
   const r=await fetch('/api/pullapart-vehicle?'+q.toString()); const d=await r.json();
   $('photoArea').classList.remove('photo-loading'); if(d.image){$('photoArea').innerHTML=`<img src="${esc(d.image)}" alt="${esc(row.year+' '+row.make+' '+row.model)}" class="vehicle-photo"><p class="muted">Photo published by Pull-A-Part.</p>`}else $('photoArea').innerHTML='<p class="muted">No Pull-A-Part vehicle photo was available.</p>';
   const info=d.extendedInfo;
   if(info){
    const obj=Array.isArray(info)?(info[0]||{}):info;
    const preferred=['bodyStyle','exteriorColor','driveType','engineSize','engineCylinders','transmission','trim','series'];
    const pairs=[];
    for(const k of preferred){if(obj&&obj[k]!=null&&String(obj[k]).trim())pairs.push([k,obj[k]])}
    if(!pairs.length&&obj&&typeof obj==='object') for(const [k,v] of Object.entries(obj)){if(v!=null&&typeof v!=='object'&&String(v).trim()&&pairs.length<8)pairs.push([k,v])}
    if(pairs.length){$('papExtended').hidden=false;$('papExtended').innerHTML=`<strong>Pull-A-Part vehicle information</strong><div class="detail-grid">${pairs.map(([k,v])=>`<div><strong>${esc(k.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase()))}</strong><span>${esc(v)}</span></div>`).join('')}</div>`}
   }
  }catch(e){$('photoArea').classList.remove('photo-loading');$('photoArea').innerHTML='<p class="muted">Pull-A-Part detail lookup unavailable.</p>'}
 } else if(row.sourceUrl){
  try{const r=await fetch('/api/vehicle?url='+encodeURIComponent(row.sourceUrl));const d=await r.json();$('photoArea').classList.remove('photo-loading');if(d.image){$('photoArea').innerHTML=`<img src="${esc(d.image)}" alt="${esc(row.year+' '+row.make+' '+row.model)}" class="vehicle-photo"><p class="muted">Photo published by the yard/source.</p>`}else $('photoArea').innerHTML='<p class="muted">No public vehicle photo was found on this source page.</p>'}catch(e){$('photoArea').classList.remove('photo-loading');$('photoArea').innerHTML='<p class="muted">Photo lookup unavailable; use the source link above.</p>'}
 }
}
async function decodeDetailVIN(vin){$('detailDecode').textContent='Decoding…';try{const r=await fetch('/api/vin/'+encodeURIComponent(vin));const d=await r.json();const x=d.Results||[];const get=k=>(x.find(v=>v.Variable===k)||{}).Value||'';$('detailDecode').innerHTML=`<strong>${esc(get('Model Year'))} ${esc(get('Make'))} ${esc(get('Model'))}</strong><br>${esc(get('Trim'))} ${esc(get('Drive Type'))} · ${esc(get('Body Class'))}`}catch(e){$('detailDecode').textContent='VIN decode unavailable.'}}
$('modalClose').onclick=()=>{$('detailModal').hidden=true};$('detailModal').addEventListener('click',e=>{if(e.target.id==='detailModal')$('detailModal').hidden=true});

const interchangeState={donors:[],styleChoices:[],donorDetailRows:[]};
function interchangePayload(){const c=$('ixCategory'),p=$('ixPart'),m=$('ixModel'),f=$('ixFitment');return {yardLocationID:$('ixYard').value,make:$('ixMake').value.trim(),model:m.value.trim(),modelID:Number(m.options[m.selectedIndex]?.dataset?.modelId||0),year:$('ixYear').value.trim(),vehicleDataSetID:$('ixStyle').value,category:(c.options[c.selectedIndex]?.text||'').trim(),part:(p.options[p.selectedIndex]?.text||'').trim(),partType:Number(p.value||0),fitmentInterchangeNumber:f.value,fitmentLabel:(f.options[f.selectedIndex]?.text||'').trim()}}
function showInterchange(html){$('interchangeResult').classList.add('show');$('interchangeResult').innerHTML=html}
function appendInterchange(html){$('interchangeResult').classList.add('show');$('interchangeResult').insertAdjacentHTML('beforeend',html)}
function renderDonors(){
 $('donorList').innerHTML=interchangeState.donors.length?interchangeState.donors.map((d,i)=>`<span class="donor-chip">${esc(d.year)} ${esc(d.make)} ${esc(d.model)} <button data-donor-i="${i}" title="Remove donor">×</button></span>`).join(''):'<span class="muted">No compatible donor vehicles added yet.</span>';
 document.querySelectorAll('[data-donor-i]').forEach(b=>b.onclick=()=>{interchangeState.donors.splice(+b.dataset.donorI,1);renderDonors()});
}
function validYmm(x){return /^\d{4}$/.test(x.year)&&x.make&&x.model}
$('addDonorBtn').onclick=()=>{const d={year:$('donorYear').value.trim(),make:$('donorMake').value.trim(),model:$('donorModel').value.trim()};if(!validYmm(d)){showInterchange('<strong>Enter donor year, make and model.</strong><p class="muted">Use a compatible donor combination returned by the official interchange lookup.</p>');return}if(!interchangeState.donors.some(x=>x.year===d.year&&norm(x.make)===norm(d.make)&&norm(x.model)===norm(d.model)))interchangeState.donors.push(d);$('donorYear').value=$('donorMake').value=$('donorModel').value='';renderDonors()};
$('clearDonorsBtn').onclick=()=>{interchangeState.donors=[];renderDonors();showInterchange('<strong>Donor list cleared.</strong>')};

// v9.8.5: browser-context fallback. Pull-A-Part's public InterchangeLookup returned 200
// in Chrome while the identical Codespaces/Node request returned 404. This fallback
// makes the same public JSON calls from the user's browser and never guesses fitment.
const PAP_IX_BROWSER='https://inventoryservice.pullapart.com';
function bixNorm(v){return String(v??'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim()}
function bixArray(v){if(Array.isArray(v))return v;if(v&&Array.isArray(v.interchangeGuide))return v.interchangeGuide;if(v&&Array.isArray(v.data))return v.data;if(v&&Array.isArray(v.results))return v.results;if(v&&Array.isArray(v.items))return v.items;return []}
function bixVal(o,keys){for(const k of keys){if(o&&o[k]!==undefined&&o[k]!==null&&String(o[k]).trim()!=='')return o[k]}return null}
function bixLabel(o){return String(bixVal(o,['style','styleName','vehicleStyle','description','Description','name','Name','makeName','modelName','modelYear','year','categoryName','partTypeCategoryName','pTypeCategoryName','partTypeName','partName','text','label','application','trimmedApplication'])||'').trim()}
function bixId(o,keys=[]){return bixVal(o,[...keys,'id','ID','makeID','modelID','vehicleDataSetID','pTypeCategoryID','partTypeCategoryID','partTypeId','partTypeID','partType'])}
function bixPick(rows,wanted){const w=bixNorm(wanted);return rows.find(x=>bixNorm(bixLabel(x))===w)||rows.find(x=>bixNorm(bixLabel(x)).includes(w)||w.includes(bixNorm(bixLabel(x))))||null}
const BIX_KNOWN_MAKES=['MERCEDES-BENZ','LAND ROVER','ALFA ROMEO','ASTON MARTIN','ROLLS-ROYCE','VOLKSWAGEN','MITSUBISHI','OLDSMOBILE','CHEVROLET','CHRYSLER','CADILLAC','INFINITI','HYUNDAI','LINCOLN','MERCURY','PONTIAC','PORSCHE','SUBARU','SUZUKI','TOYOTA','VOLVO','ACURA','AUDI','BMW','BUICK','DODGE','FIAT','FORD','GENESIS','GMC','HONDA','JAGUAR','JEEP','KIA','LEXUS','MAZDA','MINI','NISSAN','RAM','SAAB','SATURN','SCION','TESLA'];
function bixParseYmm(text){const raw=String(text||'').trim(),out=[];if(!raw)return out;const upper=raw.toUpperCase(),make=[...BIX_KNOWN_MAKES].sort((a,b)=>b.length-a.length).find(m=>upper===m||upper.startsWith(m+' '));if(!make)return out;const rest=raw.slice(make.length).trim(),m=rest.match(/^(.+?)\s+(19\d{2}|20\d{2}|\d{2})(?:\s*[-–—]\s*(19\d{2}|20\d{2}|\d{2}))?(?=\s|\(|,|$)(.*)$/);if(!m)return out;const model=m[1].trim();if(!model)return out;const expand=y=>{y=String(y);if(y.length===2){const n=Number(y);return n<=30?2000+n:1900+n}return Number(y)};const y1=expand(m[2]),y2=m[3]?expand(m[3]):y1;if(y1<1900||y1>2100||y2<1900||y2>2100||y2<y1||y2-y1>30)return out;const fitment=(m[4]||'').replace(/^\s*[,;-]?\s*/,'').trim();for(let y=y1;y<=y2;y++)out.push({year:String(y),make,model,application:raw,fitment,explicitYearRange:y2>y1?`${y1}-${y2}`:''});return out}
async function bixGet(path){const url=PAP_IX_BROWSER+path;const r=await fetch(url,{headers:{accept:'application/json, text/plain, */*'},cache:'no-store',mode:'cors'});const text=await r.text();let json;try{json=JSON.parse(text.replace(/^\uFEFF/,''))}catch{throw new Error(`Browser interchange returned non-JSON data (${r.status})`)}if(!r.ok)throw new Error(`Browser interchange HTTP ${r.status}`);return json}
async function resolveBrowserInterchange(x){
 const makes=bixArray(await bixGet('/Make/'));const mr=bixPick(makes,x.make);if(!mr)throw new Error('Make not returned by official browser API');const makeID=Number(bixId(mr,['makeID']));
 // v9.9.15: carry the exact official modelID selected in the Model dropdown.
 // Do not substitute the stale 1453 mapping; Pull-A-Part's captured 2017 XC60 request uses 1791.
 let modelID=Number(x.modelID||0);
 if(!modelID){const models=bixArray(await bixGet('/Model?makeID='+makeID));const modelRow=bixPick(models,x.model);modelID=Number(bixId(modelRow,['modelID'])||0)}
 if(!modelID)throw new Error('Official model ID could not be resolved; Scrappy will not guess compatibility.');
 const styles=bixArray(await bixGet('/VehicleDataSet/Interchangeable?makeID='+makeID+'&modelID='+modelID+'&modelYear='+encodeURIComponent(x.year)));if(styles.length!==1&&!x.vehicleDataSetID)return {ok:false,needsSelection:true,stage:'STYLE',choices:styles.map(v=>({id:bixId(v,['vehicleDataSetID']),label:bixLabel(v)}))};
 const style=x.vehicleDataSetID?styles.find(v=>String(bixId(v,['vehicleDataSetID']))===String(x.vehicleDataSetID)):styles[0];if(!style)throw new Error('Selected official style is no longer available. Refresh the style list.');const vehicleDataSetID=Number(bixId(style,['vehicleDataSetID']));
 const cats=bixArray(await bixGet('/PTypeCategory/Interchangeable?vehicleDataSetID='+vehicleDataSetID));const cat=bixPick(cats,x.category);if(!cat)return {ok:false,needsSelection:true,stage:'CATEGORY',choices:cats.map(v=>({id:bixId(v,['pTypeCategoryID','partTypeCategoryID']),label:bixLabel(v)}))};const pTypeCategoryID=Number(bixId(cat,['pTypeCategoryID','partTypeCategoryID']));
 const parts=bixArray(await bixGet('/PType/Interchangeable?vehicleDataSetID='+vehicleDataSetID+'&pTypeCategoryID='+pTypeCategoryID));const pr=bixPick(parts,x.part);if(!pr)return {ok:false,needsSelection:true,stage:'PART',choices:parts.map(v=>({id:bixId(v,['partTypeId','partTypeID','partType']),label:bixLabel(v)}))};const partType=Number(bixId(pr,['partTypeId','partTypeID','partType']));
 const active=bixArray(await bixGet('/InterchangeLookup/Active?partType='+partType+'&vehicleDataSetID='+vehicleDataSetID));const records=active.filter(r=>Number(r.interchangeLookupID||0)>0&&r.interchangeNumber&&String(r.interchangeNumber).toUpperCase()!=='IDK');const donors=[];for(const r of records){for(const d of bixParseYmm(r.application||r.trimmedApplication)){const key=x=>x.year+'|'+bixNorm(x.make)+'|'+bixNorm(x.model);let donor=donors.find(q=>key(q)===key(d));const fitment=String(r.trimmedApplication||d.fitment||'').trim(),evidence={interchangeLookupID:r.interchangeLookupID,interchangeNumber:r.interchangeNumber,application:r.application||'',fitment,isExact:!!r.isExact};if(!donor){donor={year:d.year,make:d.make,model:d.model,fitmentRequirements:[],interchangeNumbers:[],evidence:[]};donors.push(donor)}if(fitment&&!donor.fitmentRequirements.includes(fitment))donor.fitmentRequirements.push(fitment);if(r.interchangeNumber&&!donor.interchangeNumbers.includes(r.interchangeNumber))donor.interchangeNumbers.push(r.interchangeNumber);donor.evidence.push(evidence)}}
 return {ok:true,stage:'ACTIVE',transport:'browser-cors',source:'official-api',sourceLabel:'Pull-A-Part official InterchangeLookup API',makeID,modelID,vehicleDataSetID,pTypeCategoryID,partType,records,recordCount:records.length,donors,donorCount:donors.length,note:donors.length?'Donor candidates were parsed from explicit Pull-A-Part application text. Fitment requirements are preserved and must be verified against the donor vehicle before purchase.':'Official interchange records were returned, but no explicit year/make/model donor strings were present; Scrappy will not guess compatibility.'}
}
// v9.9.30: query each compatible make/model once, then filter compatible years locally.
// This avoids six simultaneous statewide connector runs for one interchange search and
// makes it much less likely that slower yards are missed or rate-limited.
async function fetchInterchangeInventory(make,model,year,matchType='OFFICIAL INTERCHANGE'){
 const qs=new URLSearchParams({make:String(make||''),model:String(model||''),refresh:'1'});
 const r=await fetch('/api/inventory?'+qs.toString(),{cache:'no-store'});
 if(!r.ok)throw new Error('Georgia inventory request failed: '+r.status);
 const data=await r.json();
 const modelRows=(data.inventory||[]).filter(row=>norm(row.make)===norm(make)&&norm(row.model)===norm(model));
 const rows=modelRows.filter(row=>String(row.year||'')===String(year||''));
 return rows.map(row=>({...row,interchangeMatchType:matchType,interchangeCoverage:{modelTotal:modelRows.length,compatibleYearTotal:rows.length}}));
}
async function fetchDonorInventoryGroups(donors,matchType='OFFICIAL INTERCHANGE'){
 const groups=new Map();
 for(const d of donors||[]){const k=norm(d.make)+'|'+norm(d.model);if(!groups.has(k))groups.set(k,{make:d.make,model:d.model,donors:[]});groups.get(k).donors.push(d)}
 const out=[];
 for(const g of groups.values()){
  const qs=new URLSearchParams({make:String(g.make||''),model:String(g.model||''),refresh:'1'});
  const r=await fetch('/api/inventory?'+qs.toString(),{cache:'no-store'});if(!r.ok)throw new Error('Georgia inventory request failed: '+r.status);
  const data=await r.json(), modelRows=(data.inventory||[]).filter(row=>norm(row.make)===norm(g.make)&&norm(row.model)===norm(g.model));
  const compatibleYears=new Set(g.donors.map(d=>String(d.year)));
  const compatible=modelRows.filter(row=>compatibleYears.has(String(row.year||'')));
  const excluded=modelRows.filter(row=>!compatibleYears.has(String(row.year||'')));
  for(const row of compatible){const d=g.donors.find(x=>String(x.year)===String(row.year));out.push({...row,interchangeMatchType:matchType,fitmentRequirements:[...(d?.applications||[]),...(d?.fitmentRequirements||[])],interchangeCoverage:{modelTotal:modelRows.length,compatibleTotal:compatible.length,excludedOtherYears:excluded.length}})}
 }
 return out;
}
function parseFitmentChecks(requirements=[]){
 const text=(requirements||[]).join(' / ');
 const out={raw:text,vinCode:'',engineLiters:null,amps:null};
 const vm=text.match(/VIN\s+([A-Z0-9]{2})\s*\(\s*4th\s+and\s+5th\s+digit/i);if(vm)out.vinCode=vm[1].toUpperCase();
 const em=text.match(/\b(\d+(?:\.\d+)?)\s*L\b/i);if(em)out.engineLiters=Number(em[1]);
 const am=text.match(/\b(\d{2,3})\s*amp\b/i);if(am)out.amps=Number(am[1]);
 return out;
}
async function verifyDonorRow(row){
 const req=parseFitmentChecks(row.fitmentRequirements||[]),checks=[];
 let mismatch=false,verified=0,pending=0;
 if(req.vinCode){if(row.vin&&String(row.vin).length>=5){const actual=String(row.vin).slice(3,5).toUpperCase(),pass=actual===req.vinCode;checks.push({label:`VIN positions 4–5: ${actual} ${pass?'matches':'does not match'} ${req.vinCode}`,pass});if(pass)verified++;else mismatch=true}else{checks.push({label:`VIN positions 4–5 ${req.vinCode}: VIN unavailable`,pass:null});pending++}}
 if(req.engineLiters){let actual=null;try{if(row.vin){const r=await fetch('/api/vin/'+encodeURIComponent(row.vin),{cache:'no-store'});if(r.ok){const j=await r.json(),v=(j.Results||[])[0]||{};const n=Number(v.DisplacementL);if(Number.isFinite(n)&&n>0)actual=n}}}catch{}if(actual!==null){const pass=Math.abs(actual-req.engineLiters)<0.11;checks.push({label:`Engine: ${actual}L ${pass?'matches':'does not match'} ${req.engineLiters}L`,pass});if(pass)verified++;else mismatch=true}else{checks.push({label:`Engine ${req.engineLiters}L: not automatically verified`,pass:null});pending++}}
 if(req.amps){checks.push({label:`Alternator rating: ${req.amps} amp requires part/label verification`,pass:null});pending++}
 const status=mismatch?'FITMENT MISMATCH':(verified>0&&pending>0?'PARTIALLY VERIFIED':(verified>0&&pending===0?'VERIFIED':'CANDIDATE — VERIFY'));
 return {...row,verification:{status,checks,verified,pending,mismatch}};
}
async function renderInterchangeRows(rows,label='donor',append=false){
 const unique=[];const seen=new Set();
 for(const row of rows||[]){const key=[row.yardId,row.vin,row.stock,row.year,row.make,row.model,row.row].map(v=>String(v||'')).join('|');if(seen.has(key))continue;seen.add(key);unique.push(row)}
 const verifiedRows=await Promise.all(unique.map(verifyDonorRow));
 const baseIndex=interchangeState.donorDetailRows.length;
 interchangeState.donorDetailRows.push(...verifiedRows);
 const coverage=verifiedRows.reduce((a,r)=>{const c=r.interchangeCoverage||{};a.excluded=Math.max(a.excluded,Number(c.excludedOtherYears||0));return a},{excluded:0});
 const html=`<div class="ix-donor-section"><h3>Georgia ${esc(label)} inventory</h3><p class="muted">${verifiedRows.length} matching vehicle${verifiedRows.length===1?'':'s'} currently returned by participating Georgia inventory connectors. Only years included in the selected official interchange are shown.${coverage.excluded?` ${coverage.excluded} same-model Georgia vehicle${coverage.excluded===1?' was':'s were'} found in other years and excluded because this fitment does not list those years.`:''} Scrappy verifies VIN/engine requirements when authoritative vehicle data is available; amperage and other part-specific requirements remain pending until checked on the donor part.</p>${verifiedRows.length?`<div class="ix-results">${verifiedRows.map((row,i)=>{const v=row.verification||{status:'CANDIDATE — VERIFY',checks:[]};const verified=v.checks.filter(c=>c.pass===true).length,pending=v.checks.filter(c=>c.pass==null).length;return `<div class="ix-card"><div><h3>${esc(row.year)} ${esc(row.make)} ${esc(row.model)}</h3><p><strong>${esc(row.yard||'Georgia yard')}</strong>${row.row?` · Row ${esc(row.row)}`:''}</p><p>${row.vin?`VIN ${esc(row.vin)}`:(row.stock?`Stock ${esc(row.stock)}`:'Vehicle identifier not published')}</p><p class="small">Arrival ${esc(formatArrival(row))} · ${esc(row.sourceLabel||row.sourceType||'Inventory source')}</p><p class="small"><strong>Fitment summary:</strong> ${verified} verified · ${pending} still to check</p>${v.checks.length?`<div class="small"><strong>Automatic fitment checks:</strong>${v.checks.map(c=>`<div>${c.pass===true?'✓':c.pass===false?'✕':'•'} ${esc(c.label)}</div>`).join('')}</div>`:''}<div class="detail-actions"><button class="detail-btn ix-view-vehicle" data-donor-detail-i="${baseIndex+i}">View vehicle</button></div></div><span class="ix-badge">${esc(v.status)}</span></div>`}).join('')}</div>`:'<p><strong>No matching donor vehicles are currently returned by the connected Georgia inventories.</strong></p>'}</div>`;
 if(append)appendInterchange(html);else showInterchange(html);
 document.querySelectorAll('.ix-view-vehicle').forEach(b=>b.onclick=()=>{const row=interchangeState.donorDetailRows[+b.dataset.donorDetailI];if(row)openDetail(row)});
}
$('interchangeBtn').onclick=async()=>{
 const x=interchangePayload();if(!x.make||!x.model||!x.year||!x.vehicleDataSetID||!x.partType||!x.fitmentInterchangeNumber){showInterchange('<strong>Complete repair vehicle, style, part and Fitment.</strong><p class="muted">Select one official Pull-A-Part fitment before searching compatibility.</p>');return}
 showInterchange('<strong>Searching Pull-A-Part official fitment interchange…</strong>');
 try{
  const payload={InterchangeNumber:x.fitmentInterchangeNumber,Locations:[Number(x.yardLocationID)],MakeID:0,ModelID:Number(x.modelID),ModelYear:Number(x.year),PartType:Number(x.partType),SearchSourceTypeID:1,VehicleDataSetID:Number(x.vehicleDataSetID)};
  const makes=bixArray(await bixGet('/Make/'));const mr=bixPick(makes,x.make);payload.MakeID=Number(bixId(mr,['makeID'])||0);if(!payload.MakeID)throw new Error('Official make ID unavailable');
  let rows=[],transport='browser-direct',browserError='';
  try{
   const br=await fetch(PAP_IX_BROWSER+'/Vehicle/InterchangeSearch',{method:'POST',headers:{'accept':'application/json, text/javascript, */*; q=0.01','content-type':'application/json'},body:JSON.stringify(payload),cache:'no-store',mode:'cors'});
   const bt=await br.text();let bj;try{bj=JSON.parse(bt.replace(/^\uFEFF/,''))}catch{throw new Error('Browser InterchangeSearch returned non-JSON data (HTTP '+br.status+')')}
   if(!br.ok)throw new Error('Browser InterchangeSearch HTTP '+br.status);rows=bixArray(bj);
   console.info('v9.9.30 browser InterchangeSearch',{transport,status:br.status,receivedRows:rows.length,responseShape:Array.isArray(bj)?'array':(bj&&Array.isArray(bj.interchangeGuide)?'interchangeGuide':'other'),searchResultsCount:bj&&Array.isArray(bj.searchResults)?bj.searchResults.length:0,payload});
  }catch(e){
   browserError=e?.message||String(e);transport='server-fallback';
   const r=await fetch('/api/interchange/search-verify',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload),cache:'no-store'});
   const diag=await r.json();if(!r.ok||!diag.ok)throw new Error('Browser direct failed: '+browserError+'; server fallback failed: '+(diag.error||'InterchangeSearch verification failed')+' · HTTP '+(diag.upstreamStatus||r.status));rows=bixArray(diag.rows);
   console.info('v9.9.30 server fallback',{browserError,requestUrl:diag.requestUrl,requestPayload:diag.requestPayload,upstreamStatus:diag.upstreamStatus,receivedRows:diag.receivedRows,rawPreview:diag.rawPreview});
  }
  const donors=[];for(const row of rows){const year=String(row.year||''),make=String(row.make||'').trim(),model=String(row.model||'').trim();if(!/^\d{4}$/.test(year)||!make||!model)continue;const key=year+'|'+bixNorm(make)+'|'+bixNorm(model);let d=donors.find(v=>v.key===key);if(!d){d={key,year,make,model,modelID:row.modelID,makeID:row.makeID,applications:[],interchangeNumbers:[],fitmentRequirements:[x.fitmentLabel]};donors.push(d)}if(row.application&&!d.applications.includes(row.application))d.applications.push(row.application);if(row.interchangeNumber&&!d.interchangeNumbers.includes(row.interchangeNumber))d.interchangeNumbers.push(row.interchangeNumber)}
  interchangeState.donors=donors;renderDonors();
  const official=`<strong>Official fitment interchange connected.</strong><p class="muted">Fitment ${esc(x.fitmentInterchangeNumber)} · ${donors.length} compatible year/make/model record${donors.length===1?'':'s'} returned by Pull-A-Part Vehicle/InterchangeSearch via ${esc(transport==='browser-direct'?'browser direct':'server fallback')}.</p><div class="ix-results">${donors.map(d=>`<div class="ix-card"><div><h3>${esc(d.year)} ${esc(d.make)} ${esc(d.model)}</h3><p><strong>Interchange:</strong> ${esc(d.interchangeNumbers.join(', ')||x.fitmentInterchangeNumber)}</p>${d.applications.length?`<p>${esc(d.applications.join(' / '))}</p>`:''}<p class="small">Pull-A-Part official Vehicle/InterchangeSearch</p></div><span class="ix-badge">OFFICIAL</span></div>`).join('')}</div>`;showInterchange(official);
  if(donors.length){appendInterchange(`<div id="donorSearchStatus" class="ix-donor-section"><p><strong>Searching ${donors.length} official compatible combinations across Georgia inventory now…</strong></p></div>`);const donorRows=await fetchDonorInventoryGroups(donors,'OFFICIAL INTERCHANGE');const status=$('donorSearchStatus');if(status)status.remove();await renderInterchangeRows(donorRows,'compatible donor',true)}
 }catch(e){showInterchange('<strong>Official fitment interchange search unavailable.</strong><p class="muted">'+esc(e.message)+'</p>')}
};
$('exactCandidateBtn').onclick=async()=>{const x=interchangePayload();if(!validYmm(x)){showInterchange('<strong>Enter repair vehicle year, make and model.</strong>');return}showInterchange('<strong>Searching statewide inventory…</strong>');try{await renderInterchangeRows(await fetchInterchangeInventory(x.make,x.model,x.year,'EXACT VEHICLE'),'exact')}catch(e){showInterchange('<strong>Search unavailable.</strong><p class="muted">'+esc(e.message)+'</p>')}};
$('candidateBtn').onclick=async()=>{if(!interchangeState.donors.length){showInterchange('<strong>Add at least one compatible donor vehicle first.</strong><p class="muted">Use Pull-A-Part’s official interchange directory, then enter each compatible year/make/model combination above.</p>');return}showInterchange(`<strong>Searching ${interchangeState.donors.length} donor combination${interchangeState.donors.length===1?'':'s'} across Georgia…</strong>`);try{const donorRows=await fetchDonorInventoryGroups(interchangeState.donors,'OFFICIAL / MANUAL INTERCHANGE');await renderInterchangeRows(donorRows,'donor')}catch(e){showInterchange('<strong>Donor search unavailable.</strong><p class="muted">'+esc(e.message)+'</p>')}};
renderDonors();

async function loadConnectorStatus(){
  try{
    const r=await fetch('/api/connectors');
    if(!r.ok) throw new Error('Connector endpoint '+r.status);
    const data=await r.json();
    renderConnectors(data.statuses||[]);
  }catch(e){
    const tbody=document.getElementById('connectorResults');
    if(tbody) tbody.innerHTML='<tr><td colspan="10">Could not load connector status.</td></tr>';
  }
}

function qualityBadge(x){
  const q=x.quality||'—';
  const warnings=(x.warnings||[]);
  const detail=warnings.length?`<div class="quality-notes">${warnings.map(w=>`<div>⚠ ${esc(w)}</div>`).join('')}</div>`:'';
  return `<span class="quality-pill quality-${esc(q.replaceAll(' ','_'))}">${esc(q)}</span>${detail}`;
}
function coverageCell(v){
  const n=Number(v||0); return `<span class="coverage ${n>=75?'coverage-good':n>=25?'coverage-mid':'coverage-low'}">${n}%</span>`;
}
function renderConnectors(items){
  const tbody=document.getElementById('connectorResults');
  if(!tbody) return;
  const statusOrder={CONNECTION_ERROR:0,PARSER_ERROR:1,EMPTY:2,FALLBACK_REVIEW:3,LIVE:4,SEARCH_DRIVEN:5,DIRECT_LINK_ONLY:6,UNTESTED:7,CHECKING:8};
  items=[...items].sort((a,b)=>(statusOrder[a.status]??99)-(statusOrder[b.status]??99)||Number(b.possibleDuplicate)-Number(a.possibleDuplicate)||a.name.localeCompare(b.name));
  tbody.innerHTML=items.map(x=>`
    <tr class="${x.possibleDuplicate?'connector-warning-row':''}">
      <td><strong>${esc(x.name)}</strong><div class="small">${esc(x.city||'')}</div></td>
      <td><span class="status-pill status-${esc(x.status||'UNTESTED')}">${esc((x.status||'UNTESTED').replaceAll('_',' '))}</span></td>
      <td><div class="source-type">${esc(x.sourceType||'—')}</div><div class="small trust-${esc(x.trustLevel||'MANUAL')}">${esc(x.trustLevel||'MANUAL')}</div>${x.searchTelemetry?`<div class="query-telemetry">Last query: ${esc(x.searchTelemetry.query||'—')} → ${Number(x.searchTelemetry.vehicleCount||0)} result${Number(x.searchTelemetry.vehicleCount||0)===1?'':'s'}${x.searchTelemetry.error?' · ERROR':''}</div>`:''}</td>
      <td>${Number(x.vehicleCount||0).toLocaleString()}</td>
      <td>${coverageCell(x.vinCoverage)}</td>
      <td>${coverageCell(x.rowCoverage)}</td>
      <td>${coverageCell(x.arrivalCoverage)}</td>
      <td>${qualityBadge(x)}</td>
      <td>${x.responseMs!=null?esc(x.responseMs)+' ms':'—'}</td>
      <td>${x.lastSuccess?new Date(x.lastSuccess).toLocaleString():'—'}</td>
    </tr>`).join('');
  const count=s=>items.filter(x=>x.status===s).length;
  document.getElementById('liveConnectorCount').textContent=count('LIVE');
  document.getElementById('emptyConnectorCount').textContent=count('EMPTY');
  document.getElementById('errorConnectorCount').textContent=count('CONNECTION_ERROR')+count('PARSER_ERROR');
  document.getElementById('directConnectorCount').textContent=count('DIRECT_LINK_ONLY')+count('UNTESTED');
  const sd=document.getElementById('searchDrivenConnectorCount'); if(sd) sd.textContent=count('SEARCH_DRIVEN');
  const fb=document.getElementById('fallbackConnectorCount'); if(fb) fb.textContent=count('FALLBACK_REVIEW');
  const warningCount=items.filter(x=>(x.warnings||[]).length>0).length;
  const w=document.getElementById('warningConnectorCount'); if(w) w.textContent=warningCount;
  const audit=document.getElementById('connectorAuditSummary');
  if(audit){const contributing=items.filter(x=>Number(x.vehicleCount||0)>0).length;const official=items.filter(x=>x.trustLevel==='OFFICIAL'&&Number(x.vehicleCount||0)>0).length;const needs=items.filter(x=>['EMPTY','CONNECTION_ERROR','PARSER_ERROR'].includes(x.status)).length;audit.innerHTML=`<strong>20-yard coverage audit:</strong> ${items.length}/20 yards classified · ${contributing} currently contributing inventory · ${official} contributing from official sources · ${needs} need connector attention.`;}
}

async function runFenixDiagnostic(){
 const btn=document.getElementById('fenixDiagnosticBtn'),box=document.getElementById('fenixDiagnosticResult');if(!btn||!box)return;
 btn.disabled=true;btn.textContent='Running…';box.innerHTML='Checking Fenix official recent inventory…';
 try{const r=await fetch('/api/fenix-diagnostics?refresh=1',{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error('HTTP '+r.status);const x=d.connector||{};const cov=x.validRows?`VIN ${Math.round(100*(x.withVin||0)/x.validRows)}% · Row ${Math.round(100*(x.withRow||0)/x.validRows)}% · Arrival ${Math.round(100*(x.withArrival||0)/x.validRows)}%`:'No parsed vehicle coverage';box.innerHTML=`<strong>${esc(x.status||'UNKNOWN')}</strong> · ${Number(x.validRows||0).toLocaleString()} Moultrie vehicles · ${esc(x.responseMs||0)} ms<br><span class="muted">Scanned ${esc(x.rowsScanned||0)} rows · matched Moultrie ${esc(x.moultrieRows||0)} · invalid ${esc(x.invalidRows||0)} · ${esc(cov)}${x.error?` · Error: ${esc(x.error)}`:''}</span>`;await loadConnectorStatus();}
 catch(e){box.innerHTML=`<strong>Diagnostic failed.</strong> <span class="muted">${esc(e.message)}</span>`;}finally{btn.disabled=false;btn.textContent='Run Fenix diagnostic';}
}
const fenixBtn=document.getElementById('fenixDiagnosticBtn');if(fenixBtn)fenixBtn.onclick=runFenixDiagnostic;

async function runSwDiagnostic(){
 const btn=document.getElementById('swDiagnosticBtn'),box=document.getElementById('swDiagnosticResult');if(!btn||!box)return;
 btn.disabled=true;btn.textContent='Running…';box.innerHTML='Checking S&amp;W official U-Pull inventory source…';
 try{const r=await fetch('/api/sw-diagnostics?refresh=1',{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error('HTTP '+r.status);const x=d.connector||{};const candidates=(x.candidates||[]).length;const cov=x.validRows?`VIN ${Math.round(100*(x.withVin||0)/x.validRows)}% · Stock ${Math.round(100*(x.withStock||0)/x.validRows)}% · Row ${Math.round(100*(x.withRow||0)/x.validRows)}% · Arrival ${Math.round(100*(x.withArrival||0)/x.validRows)}%`:'No parsed vehicle coverage';box.innerHTML=`<strong>${esc(x.status||'UNKNOWN')}</strong> · S&amp;W page HTTP ${esc(x.httpStatus??'—')} · linked inventory HTTP ${esc(x.linkedHttpStatus??'—')} · ${Number(x.validRows||0).toLocaleString()} parsed vehicles · ${esc(x.responseMs||0)} ms<br><span class="muted">Linked inventory ${Number(x.linkedHtmlBytes||0).toLocaleString()} bytes · tables ${esc(x.tables||0)} · rows ${esc(x.rowsScanned||0)} · ${esc(cov)}${x.error?` · Error: ${esc(x.error)}`:''}</span>${x.linkedInventoryUrl?`<details><summary>Linked S&amp;W inventory source</summary><div class="small">${esc(x.linkedInventoryUrl)}</div></details>`:''}${(x.linkedForms||[]).length?`<details><summary>Inventory search form</summary><div class="small">${(x.linkedForms||[]).map(f=>`${esc(f.method)} ${esc(f.action)} · fields: ${esc((f.fields||[]).join(', '))}`).join('<br>')}</div></details>`:''}${x.clientDiscovery?`<details open><summary>S&W connector discovery</summary><div class="small">${x.clientDiscovery.permissionRequired?`<strong>AUTHORIZED ACCESS NEEDED</strong><br>${esc(x.clientDiscovery.note||'Automated S&W bundle/data scraping is disabled pending permission or an authorized feed/API.')}<br><br>`:''}${(x.clientDiscovery.resources||[]).length?`<strong>Genuine page resources (${x.clientDiscovery.resources.length})</strong><br>${x.clientDiscovery.resources.map(v=>`${esc(v.kind)} · ${esc(v.url)}`).join('<br>')}<br>`:''}${(x.clientDiscovery.dataCandidates||[]).length?`<strong>JavaScript data/API candidates (${x.clientDiscovery.dataCandidates.length})</strong><br>${x.clientDiscovery.dataCandidates.map(v=>`${esc(v.kind)} · ${esc(v.url)}`).join('<br>')}<br>`:''}${(x.clientDiscovery.probes||[]).length?`<strong>Focused probes (${x.clientDiscovery.probes.length})</strong><br>${x.clientDiscovery.probes.map(v=>`${esc(v.httpStatus||'ERR')} · ${esc(v.contentType||'')} · ${Number(v.bytes||0).toLocaleString()} bytes · ${esc(v.url)}`).join('<br>')}`:''}</div></details>`:''}`;await loadConnectorStatus();}
 catch(e){box.innerHTML=`<strong>Diagnostic failed.</strong> <span class="muted">${esc(e.message)}</span>`;}finally{btn.disabled=false;btn.textContent='Run S&amp;W diagnostic';}
}
const swBtn=document.getElementById('swDiagnosticBtn');if(swBtn)swBtn.onclick=runSwDiagnostic;

const oldLoad=load;
load=async function(...args){
  await oldLoad(...args);
  await loadConnectorStatus();
};
const cr=document.getElementById('connectorRefreshBtn');
if(cr) cr.onclick=async()=>{cr.disabled=true;cr.textContent='Refreshing…';try{await fetch('/api/inventory?refresh=1');await loadConnectorStatus();}finally{cr.disabled=false;cr.textContent='Refresh status';}};

// Initial application + connector-status load
load();


// v9.9.0 workspace navigation: separate major jobs without duplicating data or connectors.
function openWorkspace(name,{scroll=true}={}){
 const valid=['search','interchange','yards','saved','diagnostics','about'];if(!valid.includes(name))name='search';
 document.querySelectorAll('.workspace').forEach(v=>v.classList.toggle('active',v.id==='workspace-'+name));
 document.querySelectorAll('.workspace-tab').forEach(b=>b.classList.toggle('active',b.dataset.workspace===name));
 try{history.replaceState(null,'','#'+name)}catch{}
 if(scroll)window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('.workspace-tab').forEach(b=>b.addEventListener('click',()=>openWorkspace(b.dataset.workspace)));
openWorkspace((location.hash||'#search').slice(1),{scroll:false});

// v9.9.15 — mirror Pull-A-Part's yard-context initialization before interchange lookups.
// Birmingham location=5 is verified from Pull-A-Part's own Network sequence. Other
// yard IDs are intentionally not guessed. Interchange results remain independent
// of whether the repair vehicle is currently present in that yard.
let ixContextToken=0;
async function primeIxYardContext(makeID=0){
 const locationID=Number($('ixYard')?.value||0);
 if(!locationID)throw new Error('Select a Pull-A-Part yard first');
 const base='https://inventoryservice.pullapart.com';
 const suffix=makeID?'&makeID='+encodeURIComponent(makeID):'';
 const path='/Model/OnYard?locations='+encodeURIComponent(locationID)+suffix;
 // Pull-A-Part's browser sequence uses OnYard first. The response is context only;
 // it is never used to filter the interchange catalog.
 const r=await fetch(base+path,{headers:{accept:'application/json, text/javascript, */*; q=0.01'},cache:'no-store',mode:'cors'});
 if(!r.ok)throw new Error('Yard context HTTP '+r.status);
 return {locationID,path};
}
async function primeIxMakeContext(makeID){
 // Match the observed browser sequence: OnYard(location), interchange make, then
 // OnYard(location+make). These calls initialize context but do not gate catalog choices.
 await primeIxYardContext(0);
 if(makeID){
  try{await bixGet('/VehicleDataSet/Interchangeable/?makeID='+encodeURIComponent(makeID))}catch{}
  await primeIxYardContext(makeID);
 }
}
// v9.9.6 — load official Pull-A-Part Style choices automatically once Make + Model + Year are complete.
let ixStyleLoadToken=0, ixStyleTimer=null;
function resetIxStyle(message='Select vehicle first'){
 const s=$('ixStyle'); if(!s)return; s.innerHTML='<option value="">'+esc(message)+'</option>'; s.disabled=true; interchangeState.styleChoices=[];
}
async function loadOfficialStyles(){
 const make=$('ixMake').value.trim(),model=$('ixModel').value.trim(),year=$('ixYear').value.trim();
 const modelID=Number($('ixModel').options[$('ixModel').selectedIndex]?.dataset?.modelId||0);
 const token=++ixStyleLoadToken;
 if(!$('ixYard').value){resetIxStyle('Select yard first');return}
 if(!make||!model||!/^\d{4}$/.test(year)){resetIxStyle();return}
 const sel=$('ixStyle'); sel.innerHTML='<option value="">Loading styles…</option>'; sel.disabled=true;
 try{
  let choices=[];
  const qs=new URLSearchParams({make,model,year,modelID:String(modelID||'')});
  const r=await fetch('/api/interchange/styles?'+qs.toString(),{cache:'no-store'}); const d=await r.json();
  if(token!==ixStyleLoadToken)return;
  if(r.ok&&d.ok) choices=(d.choices||[]).filter(c=>Number(c.id)>0&&String(c.label||'').trim());
  if(!choices.length){
   // Same public browser-context API fallback that made v9.9.2/9.9.3 work in Chrome.
   const makes=bixArray(await bixGet('/Make/')); const mr=bixPick(makes,make); const makeID=Number(bixId(mr,['makeID']));
   if(!makeID||!modelID)throw new Error('Official style lookup could not resolve the selected model ID.');
   const rows=bixArray(await bixGet('/VehicleDataSet/Interchangeable?makeID='+makeID+'&modelID='+modelID+'&modelYear='+encodeURIComponent(year)));
   choices=rows.map(v=>({id:bixId(v,['vehicleDataSetID']),label:bixLabel(v)})).filter(c=>Number(c.id)>0&&String(c.label||'').trim());
  }
  if(token!==ixStyleLoadToken)return;
  if(!choices.length){resetIxStyle('No styles returned');return}
  interchangeState.styleChoices=choices;
  sel.innerHTML='<option value="">Select Style</option>'+choices.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join(''); sel.disabled=false;
 }catch(e){if(token!==ixStyleLoadToken)return;resetIxStyle('Style lookup unavailable')}
}
function resetIxCategory(message='Select style first'){const s=$('ixCategory');s.innerHTML='<option value="">'+esc(message)+'</option>';s.disabled=true;resetIxPart();resetIxFitment()}
function resetIxPart(message='Select category first'){const s=$('ixPart');s.innerHTML='<option value="">'+esc(message)+'</option>';s.disabled=true;const f=$('ixFitment');if(f){f.innerHTML='<option value="">Select part first</option>';f.disabled=true}}
function resetIxFitment(message='Select part first'){const s=$('ixFitment');if(!s)return;s.innerHTML='<option value="">'+esc(message)+'</option>';s.disabled=true}
async function loadOfficialFitments(){const vehicleDataSetID=$('ixStyle').value,partType=Number($('ixPart').value||0);resetIxFitment();if(!vehicleDataSetID||!partType)return;const sel=$('ixFitment');sel.innerHTML='<option value="">Loading fitments…</option>';try{const rows=bixArray(await bixGet('/InterchangeLookup/Active?partType='+partType+'&vehicleDataSetID='+encodeURIComponent(vehicleDataSetID)));const choices=rows.filter(r=>Number(r.interchangeLookupID||0)>0&&r.interchangeNumber&&String(r.interchangeNumber).toUpperCase()!=='IDK');if(!choices.length)throw new Error('No active fitments returned');sel.innerHTML='<option value="">Select Fitment</option>'+choices.map(r=>`<option value="${esc(r.interchangeNumber)}">${esc(r.application||r.trimmedApplication||r.interchangeNumber)}</option>`).join('');sel.disabled=false}catch(e){sel.innerHTML='<option value="">Fitment lookup unavailable</option>';sel.disabled=true}}
async function loadOfficialModels(){
 const make=$('ixMake').value.trim(),sel=$('ixModel'); resetIxStyle();resetIxCategory();
 if(!$('ixYard').value){sel.innerHTML='<option value="">Select yard first</option>';sel.disabled=true;return}
 if(!make){sel.innerHTML='<option value="">Select make first</option>';sel.disabled=true;return}
 sel.innerHTML='<option value="">Loading models…</option>';sel.disabled=true;
 try{
  const makes=bixArray(await bixGet('/Make/')); const mr=bixPick(makes,make); const makeID=Number(bixId(mr,['makeID']));
  if(!makeID)throw new Error('Official make ID unavailable');
  await primeIxMakeContext(makeID);
  const r=await fetch('/api/interchange/models?'+new URLSearchParams({make}),{cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Model lookup failed');const choices=(d.choices||[]).filter(c=>c.id&&c.label).sort((a,b)=>String(a.label).localeCompare(String(b.label),undefined,{sensitivity:'base'}));sel.innerHTML='<option value="">Select Model</option>'+choices.map(c=>`<option value="${esc(c.label)}" data-model-id="${esc(c.id)}">${esc(c.label)}</option>`).join('');sel.disabled=false}catch(e){sel.innerHTML='<option value="">Model lookup unavailable</option>';sel.disabled=true}
}
async function loadOfficialCategories(){
 const vehicleDataSetID=$('ixStyle').value; resetIxCategory(); if(!vehicleDataSetID)return;
 const sel=$('ixCategory');sel.innerHTML='<option value="">Loading categories…</option>';sel.disabled=true;
 try{await primeIxYardContext();const r=await fetch('/api/interchange/categories?'+new URLSearchParams({vehicleDataSetID}),{cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Category lookup failed');const choices=(d.choices||[]).filter(c=>c.id&&c.label);sel.innerHTML='<option value="">Select Category</option>'+choices.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('');sel.disabled=false}catch(e){sel.innerHTML='<option value="">Category lookup unavailable</option>';sel.disabled=true}
}
async function loadOfficialParts(){
 const vehicleDataSetID=$('ixStyle').value,pTypeCategoryID=$('ixCategory').value;resetIxPart();if(!vehicleDataSetID||!pTypeCategoryID)return;
 const sel=$('ixPart');sel.innerHTML='<option value="">Loading parts…</option>';sel.disabled=true;
 const path='/PType/Interchangeable?vehicleDataSetID='+encodeURIComponent(vehicleDataSetID)+'&pTypeCategoryID='+encodeURIComponent(pTypeCategoryID);
 try{
  // v9.9.15: browser-CORS is the PRIMARY Part lookup path. Pull-A-Part's own
  // browser UI returns partType/description for this exact public endpoint,
  // while the Codespaces/Node request has repeatedly returned category rows.
  const br=await fetch('https://inventoryservice.pullapart.com'+path,{headers:{accept:'application/json, text/javascript, */*; q=0.01'},cache:'no-store',mode:'cors'});
  if(!br.ok)throw new Error('Official browser Part lookup HTTP '+br.status);
  const rows=bixArray(await br.json());
  const choices=rows.map(row=>({id:Number(row?.partType),label:String(row?.description||'').trim()})).filter(c=>Number.isFinite(c.id)&&c.id>0&&c.label).sort((a,b)=>a.label.localeCompare(b.label,undefined,{sensitivity:'base'}));
  if(!choices.length)throw new Error('Official browser Part lookup returned no part records');
  sel.innerHTML='<option value="">Select Part</option>'+choices.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('');sel.disabled=false;
  sel.dataset.transport='browser-cors';
 }catch(browserError){
  // Keep the server route only as a diagnostic/fallback; never reinterpret
  // category rows as parts.
  try{
   const r=await fetch('/api/interchange/parts?'+new URLSearchParams({vehicleDataSetID,pTypeCategoryID}),{cache:'no-store'});const d=await r.json();
   if(!r.ok||!d.ok)throw new Error(d.error||'Server Part lookup failed');
   const choices=(d.choices||[]).filter(c=>c.id&&c.label);
   if(!choices.length)throw new Error('Server Part lookup returned no part records');
   sel.innerHTML='<option value="">Select Part</option>'+choices.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('');sel.disabled=false;sel.dataset.transport='server-fallback';
  }catch(serverError){
   sel.innerHTML='<option value="">Part lookup unavailable</option>';sel.disabled=true;
   showInterchange(`<strong>Official Part lookup unavailable.</strong><p class="muted">Browser: ${esc(browserError.message)}<br>Server: ${esc(serverError.message)}</p>`);
  }
 }
}
function scheduleOfficialStyles(){clearTimeout(ixStyleTimer);resetIxStyle();resetIxCategory();ixStyleTimer=setTimeout(loadOfficialStyles,250)}
$('ixYard').addEventListener('change',()=>{
 resetIxStyle('Select vehicle first');resetIxCategory();resetIxPart();
 const m=$('ixModel');m.innerHTML='<option value="">Select make first</option>';m.disabled=true;
 if($('ixYard').value&&$('ixMake').value)loadOfficialModels();
});
$('ixMake').addEventListener('change',loadOfficialModels);
$('ixModel').addEventListener('change',scheduleOfficialStyles);
$('ixYear').addEventListener('input',scheduleOfficialStyles);
$('ixYear').addEventListener('change',scheduleOfficialStyles);
$('ixStyle').addEventListener('change',loadOfficialCategories);
$('ixCategory').addEventListener('change',loadOfficialParts);
$('ixPart').addEventListener('change',loadOfficialFitments);

// v9.9.44 EZ Pull N Pay Columbus recovery diagnostic
document.addEventListener('click',async(e)=>{
 if(e.target?.id!=='ezColumbusDiagBtn')return;
 const box=document.getElementById('ezColumbusDiagOut');if(!box)return;box.textContent='Running Columbus diagnostic…';
 try{const r=await fetch('/api/ez-columbus-diagnostics'),x=await r.json();
 box.innerHTML=`<strong>${esc(x.status)}</strong> · HTTP ${esc(x.httpStatus||'—')} · ${Number(x.parsedVehicles||0).toLocaleString()} parsed vehicles · ${Number(x.elapsedMs||0).toLocaleString()} ms<br><span class="muted">HTML ${Number(x.bytes||0).toLocaleString()} bytes · tables ${x.tables||0} · rows ${x.rows||0}</span>${(x.candidates||[]).length?`<details open><summary>Official-page inventory candidates (${x.candidates.length})</summary>${x.candidates.map(v=>`<div class="small">${esc(v.kind)} · ${esc(v.url)}</div>`).join('')}</details>`:''}${x.plugin?`<details open><summary>Official inventory plugin discovery</summary><div class="small">${x.plugin.inventoryPage?`Inventory page · HTTP ${esc(x.plugin.inventoryPage.httpStatus??'—')} · ${Number(x.plugin.inventoryPage.bytes||0).toLocaleString()} bytes · ${esc(x.plugin.inventoryPage.url)}<br>`:''}${(x.plugin.scripts||[]).length?`<strong>Plugin scripts (${x.plugin.scripts.length})</strong><br>${x.plugin.scripts.map(v=>esc(v)).join('<br>')}<br>`:''}${(x.plugin.references||[]).length?`<strong>API / AJAX / action references (${x.plugin.references.length})</strong><br>${x.plugin.references.map(v=>`${esc(v.kind)} · ${esc(v.url||v.value||'')}`).join('<br>')}`:'No API/AJAX references discovered.'}${x.plugin.ajax?`<br><br><strong>Official WordPress AJAX metadata</strong><br>${(x.plugin.ajax.actions||[]).length?x.plugin.ajax.actions.map(v=>`${esc(v.action)} · ${(v.attempts||[]).map(q=>q.error?`ERROR ${esc(q.error)}`:`HTTP ${esc(q.httpStatus)} · ${Number(q.bytes||0).toLocaleString()} bytes · ${esc(q.preview||'')}`).join(' | ')}`).join('<br>'):'No discovered actions returned metadata.'}`:''}${x.plugin.ario?`<br><br><strong>AutoRecycler / ARIO discovery</strong><br>${(x.plugin.ario.references||[]).length?`Discovered official ARIO references (${x.plugin.ario.references.length})<br>${x.plugin.ario.references.map(v=>`${esc(v.kind)} · ${esc(v.url)}`).join('<br>')}`:'No ARIO reference discovered.'}${(x.plugin.ario.probes||[]).length?`<br><strong>Exact-reference probes</strong><br>${x.plugin.ario.probes.map(v=>v.error?`${esc(v.url)} · ERROR ${esc(v.error)}`:`HTTP ${esc(v.httpStatus)} · ${Number(v.bytes||0).toLocaleString()} bytes · Columbus mention ${v.columbusMention?'YES':'NO'} · ${esc(v.finalUrl||v.url)}${(v.identifiers||[]).length?`<br>Identifiers: ${v.identifiers.map(esc).join(' · ')}`:''}${(v.locationContext||[]).length?`<br><strong>Location parameter context</strong><br>${v.locationContext.map(esc).join('<br>')}`:''}${(v.scriptContext||[]).length?`<br><strong>Verified ARIO location resolution</strong><br>${v.scriptContext.map(q=>`${esc(q.url)} · HTTP ${esc(q.httpStatus)} · ${Number(q.bytes||0).toLocaleString()} bytes<br>${(q.hits||[]).map(esc).join('<br>')}`).join('<br>')}`:''}${(v.initData||[]).length?`<br><strong>Initialization data</strong><br>${v.initData.map(q=>q.error?`${esc(q.url)} · ERROR ${esc(q.error)}`:`HTTP ${esc(q.httpStatus)} · ${Number(q.bytes||0).toLocaleString()} bytes · Atlanta ${q.atlantaMention?'YES':'NO'} · Columbus ${q.columbusMention?'YES':'NO'}<br>${esc(q.url)}${(q.identity||[]).length?`<br>Identity fields: ${q.identity.map(esc).join(' · ')}`:''}`).join('<br>')}`:''}`).join('<br>')}`:''}`:''}</div></details>`:''}`;
 }catch(err){box.textContent='Diagnostic failed: '+(err?.message||err)}
});

// v10.0.0-rc3 full-site diagnostic.
const siteDiagnosticBtn=document.getElementById('siteDiagnosticBtn');
if(siteDiagnosticBtn)siteDiagnosticBtn.onclick=async()=>{
  const box=document.getElementById('siteDiagnosticSummary'),body=document.getElementById('siteDiagnosticResults');
  siteDiagnosticBtn.disabled=true;
  siteDiagnosticBtn.textContent='Running…';
  box.textContent='Testing Scrappy and public dependencies…';
  body.innerHTML='';
  try{
    const r=await fetch('/api/site-diagnostic?refresh=1',{cache:'no-store'});
    const d=await r.json();
    box.innerHTML=`<strong>${esc(d.status)}</strong> · ${esc(d.summary.passed)}/${esc(d.summary.total)} checks passed · ${Number(d.durationMs||0).toLocaleString()} ms<br><span class="muted">${esc(d.note||'')}</span>`;
    body.innerHTML=(d.tests||[]).map(t=>`<tr><td>${esc(t.name)}</td><td><strong>${esc(t.status||(t.ok?'PASS':'ATTENTION'))}</strong></td><td>${esc(t.detail||'')}</td><td>${t.responseMs?esc(t.responseMs)+' ms':'—'}</td></tr>`).join('');const yb=document.getElementById('siteDiagnosticYards'),ys=document.getElementById('siteDiagnosticYardSummary');if(ys)ys.textContent=`${Number(d.inventory?.vehicles||0).toLocaleString()} vehicles · ${d.inventory?.contributingYards||0} yards contributing`;if(yb)yb.innerHTML=(d.inventory?.yards||[]).map(y=>`<tr><td>${esc(y.yard)}</td><td>${y.reportedVehicles&&Number(y.reportedVehicles)>Number(y.vehicles||0)?`${Number(y.reportedVehicles).toLocaleString()} reported <span class=\"small\">(${Number(y.vehicles||0).toLocaleString()} searchable rows)</span>`:Number(y.vehicles||0).toLocaleString()}</td><td>${esc(y.status||'')}</td><td>${esc(y.source||'—')}</td></tr>`).join('');
  }catch(e){
    box.innerHTML=`<strong>Diagnostic failed.</strong> ${esc(e.message)}`;
  }finally{
    siteDiagnosticBtn.disabled=false;
    siteDiagnosticBtn.textContent='Run full diagnostic';
  }
};
