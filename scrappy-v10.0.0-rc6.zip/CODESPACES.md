# Scrappy v10.0.0-rc2 — Codespaces

```bash
cd /workspaces/Scrappy2
pkill -f "node server.js" || true
npm start
```

Open port 3000, then use **Diagnostics → Run full diagnostic**.
