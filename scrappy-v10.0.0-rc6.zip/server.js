const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||3000,ROOT=__dirname;
const BUILD_VERSION='10.0.0-rc6';
const pnpJeffersonTelemetry=new Map();
const papDeepDiagnostics=new Map();

const raw=[
['pull-apart-atl-east','Pull-A-Part Atlanta East','Lithonia','6513 Marshall Boulevard, Lithonia, GA 30058','https://www.pullapart.com/locations/georgia/atlanta-east/',true,'verified'],
['pull-apart-atl-north','Pull-A-Part Atlanta North','Norcross','4416 Buford Hwy, Norcross, GA 30071','https://www.pullapart.com/locations/georgia/atlanta-north/',true,'verified'],
['pull-apart-atl-south','Pull-A-Part Atlanta South','Conley','1540 Henrico Road, Conley, GA 30288','https://www.pullapart.com/locations/georgia/atlanta-south/',true,'verified'],
['pull-apart-augusta','Pull-A-Part Augusta','Augusta','327 SandBar Ferry Rd, Augusta, GA 30901','https://www.pullapart.com/locations/georgia/augusta/',true,'verified'],
['go-pull-it-norcross','GO Pull-It Atlanta East','Norcross','4600 Buford Hwy, Norcross, GA 30071','https://gopullit.com/inventory/?location=atlanta-east',true,'verified'],
['go-pull-it-gainesville','GO Pull-It Gainesville','Gainesville','2156 Athens Hwy, Gainesville, GA 30507','https://gopullit.com/inventory/?location=gainesville-ga',true,'verified'],
['ez-pull-n-pay-atlanta','EZ Pull N Pay Atlanta','Atlanta','1172 Field Rd NW, Atlanta, GA 30318','https://ezpullnpay.com/atlanta/',true,'live'],
['ez-pull-n-pay-stockbridge','EZ Pull N Pay Stockbridge','Stockbridge','473 Hwy 138 E, Stockbridge, GA 30281','https://ezpullnpay.com/stockbridge/',true,'live'],
['ez-pull-n-pay-warner','EZ Pull N Pay Warner Robins','Warner Robins','11128 Hawkinsville Rd, Warner Robins, GA 31093','https://ezpullnpay.com/warner-robins/',true,'live'],
['ez-pull-n-pay-columbus','EZ Pull N Pay Columbus','Columbus','3843 Aldridge Rd, Columbus, GA 31903','https://ezpullnpay.com/columbus-location/',true,'verified'],
['cagles',"Cagle's U Pull It",'Cartersville','1139 Old Alabama Rd SW, Cartersville, GA 30120','https://caglesupullit.com/inventory.aspx',true,'live'],
['sw','S&W U Pull','Lithonia','1826 Lithonia Industrial Blvd, Lithonia, GA 30058','https://www.sandwauto.com/inventory-search',true,'live'],
['pyp-fayetteville','Pick Your Part Fayetteville','Fayetteville','155 Roberts Rd, Fayetteville, GA 30214','https://www.pyp.com/inventory/fayetteville-1229/',true,'live'],
['pyp-savannah','Pick Your Part Savannah','Savannah','1321 Hwy 80 West, Savannah, GA 31408','https://www.pyp.com/inventory/savannah-1163/',true,'live'],
['pick-n-pull-jefferson','Pick-N-Pull Jefferson','Jefferson','2991 Highway 124 W, Jefferson, GA 30549','https://www.picknpull.com/locations/195/jefferson-ga',true,'verified'],
['fenix-moultrie','Fenix U-Pull Moultrie','Moultrie','232 Industrial Rd, Moultrie, GA 31768','https://fenixupull.com/inventory/',true,'verified'],
['highway82','Highway 82 Pick & Pay','Poulan','455 Hwy 82 NW, Poulan, GA 31781','https://hwy82pp.com/search-inventory/',true,'live'],
['cash-n-carry','Cash N Carry Pull Your Part','Savannah','500 Staley Ave, Savannah, GA 31405','https://cashncarryparts.com/search-inventory/',true,'live'],
['southern-pik-a-part-augusta','Southern Pik-A-Part Augusta','Augusta','1550 Doug Barnard Pkwy, Augusta, GA 30906','http://spapaugusta.us/',true,'unknown'],
['southern-pik-a-part-columbus','Southern Pik-A-Part Columbus','Columbus','281 Brennan Rd, Columbus, GA 31903','http://spap.us/',true,'unknown']
];
const YARDS=raw.map(([id,name,city,address,website,diy,status])=>({id,name,city,address,website,diy,status,live:status==='live',mapUrl:'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(address)}));
const searchConnectorTelemetry=new Map();
const pypConnectorTelemetry=new Map();
const MAKE_ALIASES={
 'vw':'VOLKSWAGEN','mercedes':'MERCEDES-BENZ','mercedes benz':'MERCEDES-BENZ','mb':'MERCEDES-BENZ',
 'chevy':'CHEVROLET','gmc truck':'GMC','land rover':'LAND ROVER','alfa romeo':'ALFA ROMEO',
 'volkswagen':'VOLKSWAGEN','volvo':'VOLVO','bmw':'BMW','mini':'MINI'
};
const MODEL_ALIASES={
 'xc 60':'XC60','xc-60':'XC60','xc 90':'XC90','xc-90':'XC90','xc 40':'XC40','xc-40':'XC40',
 'f 150':'F-150','f150':'F-150','f- 150':'F-150','silverado 1500':'SILVERADO 1500',
 'grand cherokee':'GRAND CHEROKEE','town and country':'TOWN & COUNTRY','town & country':'TOWN & COUNTRY',
 '3 series':'3 SERIES','5 series':'5 SERIES','c class':'C-CLASS','e class':'E-CLASS'
};
function canonicalMake(v){const x=String(v||'').replace(/\s+/g,' ').trim().toLowerCase();return MAKE_ALIASES[x]||x.toUpperCase()}
function canonicalModel(v){let x=String(v||'').replace(/[–—]/g,'-').replace(/\s+/g,' ').trim().toLowerCase();x=x.replace(/\s*\/\s*/g,'/');return MODEL_ALIASES[x]||x.toUpperCase()}
function canonicalSubmodel(v){return String(v||'').replace(/[–—]/g,'-').replace(/\s+/g,' ').trim().toUpperCase()}
function normalizeRecord(x){return {...x,make:canonicalMake(x.make),model:canonicalModel(x.model),submodel:canonicalSubmodel(x.submodel)}}
function dedupeInventory(rows){
 const map=new Map();
 for(const raw of rows){const x=normalizeRecord(raw);const vin=String(x.vin||'').replace(/[^A-Z0-9]/gi,'').toUpperCase();
  const key=vin.length>=11?`VIN:${vin}`:(x.sourceRecordKey?`SRC:${x.yardId}|${x.sourceRecordKey}`:`ROW:${x.yardId}|${x.year}|${x.make}|${x.model}|${x.submodel}|${x.row}|${x.arrival}`);
  if(!map.has(key)){map.set(key,{...x,sourceUrls:x.sourceUrl?[x.sourceUrl]:[]});continue}
  const old=map.get(key); const urls=new Set([...(old.sourceUrls||[]),...(x.sourceUrl?[x.sourceUrl]:[])]);
  map.set(key,{...old, ...x, sourceUrl:old.sourceUrl||x.sourceUrl, sourceUrls:[...urls], live:!!old.live||!!x.live, isNew:!!old.isNew||!!x.isNew});
 }
 return [...map.values()];
}


function strip(s){return(s||'').replace(/<[^>]*>/g,' ').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&#x27;/g,"'").replace(/\s+/g,' ').trim()}
function isRecent(s){if(!s)return false;const d=new Date(s);return !isNaN(d)&&((Date.now()-d.getTime())/86400000<=14)}
function dateFromMDY(s){if(!s)return null;const m=String(s).match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);if(!m)return null;let y=+m[3];if(y<100)y+=2000;return new Date(y,+m[1]-1,+m[2]).toISOString()}
function rowsFromTable(html,yardId,yardName,sourceUrl){
 const out=[];
 for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
  for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
   const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip); if(c.length<3)continue;
   let year,make='',model='',submodel='',row='',vin='',stock='',arrival='';
   if(yardId==='sw'&&c.length>=5)[row,year,make,model,vin]=c;
   else if(yardId==='cash-n-carry'&&c.length>=7)[year,make,model,,stock,row,arrival]=c;
   else if(yardId.startsWith('ez-pull-n-pay')&&c.length>=8)[year,make,model,, ,stock,row,arrival]=c;
   else if(yardId==='cagles'&&c.length>=5)[year,make,model,row,arrival]=c;
   year=Number(year);
   if(year>1900&&year<2100&&make&&model&&!/year|make|model/i.test(make)){
    const y=YARDS.find(v=>v.id===yardId)||{}; const ad=dateFromMDY(arrival);
    out.push({yardId,yard:yardName,year,make,model,submodel,row,vin,stock,arrival,arrivalDate:ad,sourceUrl,diy:y.diy!==false,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
   }
  }
 }
 return out;
}
function parsePyp(html,yardId,yardName,url){
 const out=[];
 const y=YARDS.find(v=>v.id===yardId)||{};
 // Current PYP inventory is server-rendered. Vehicle cards begin with a year/make/model
 // heading and contain stock, Section/Row/Space, VIN and Available date in the same card.
 // Split on vehicle headings instead of relying on one specific surrounding CSS layout.
 const headingRe=/<h[1-6][^>]*>\s*((?:19|20)\d{2})[\s\S]*?<\/h[1-6]>/gi;
 const heads=[...html.matchAll(headingRe)];
 for(let i=0;i<heads.length;i++){
  const title=strip(heads[i][0]);
  const tm=title.match(/^((?:19|20)\d{2})\s+(.+)$/i); if(!tm) continue;
  const year=Number(tm[1]), vehicle=strip(tm[2]);
  if(!vehicle||/vehicle inventory|last chance|page \d+/i.test(vehicle)) continue;
  const endPos=i+1<heads.length?heads[i+1].index:Math.min(html.length,heads[i].index+12000);
  const chunk=strip(html.slice(heads[i].index,endPos));
  const toks=vehicle.split(/\s+/); if(toks.length<2) continue;
  const make=toks.shift(), model=toks.join(' ');
  const vin=(chunk.match(/\bVIN\s*:?[\s|]*([A-HJ-NPR-Z0-9]{17})\b/i)||[])[1]||'';
  // PYP stock format is currently location-stock, e.g. 1229-38114.
  const stock=(chunk.match(/\b(\d{3,5}-\d{3,8})\b/)||[])[1]||'';
  const section=(chunk.match(/\bSection\s*:?[\s|]*([^|]{1,30}?)(?=\s*(?:\||Row\b|Space\b|VIN\b|Available\b))/i)||[])[1]||'';
  const row=(chunk.match(/\bRow\s*:?[\s|]*([A-Z0-9-]{1,12})\b/i)||[])[1]||'';
  const space=(chunk.match(/\bSpace\s*:?[\s|]*([A-Z0-9-]{1,12})\b/i)||[])[1]||'';
  const arrival=(chunk.match(/\bAvailable\s*:?[\s|]*(\d{1,2}\/\d{1,2}\/\d{4})\b/i)||[])[1]||'';
  const ad=dateFromMDY(arrival);
  const rowLabel=[section&&('Section '+section.trim()),row&&('Row '+row),space&&('Space '+space)].filter(Boolean).join(' · ');
  out.push({yardId,yard:yardName,year,make,model,submodel:'',row:rowLabel,vin,stock,arrival,arrivalDate:ad,sourceUrl:url,diy:y.diy!==false,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
 }
 return dedupeInventory(out);
}

async function fetchText(url,timeoutMs=12000){const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);try{const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.9','Cache-Control':'no-cache'},signal:ctrl.signal});if(!r.ok)throw Error(`${r.status}`);return await r.text()}finally{clearTimeout(timer)}}
function withTimeout(promise,ms,label='connector'){return Promise.race([promise,new Promise((_,reject)=>setTimeout(()=>reject(new Error(`${label} timed out after ${ms}ms`)),ms))])}
async function safeRows(label,fn,ms=15000){try{const rows=await withTimeout(Promise.resolve().then(fn),ms,label);return Array.isArray(rows)?rows:[]}catch(e){console.error(`${label} skipped: ${e.message}`);return []}}

const pullApartMakeIdCache=new Map();
const PULLAPART_CACHE_FILE=require('path').join(ROOT,'pullapart-make-cache.json');
function loadPapMakeCache(){try{const o=JSON.parse(require('fs').readFileSync(PULLAPART_CACHE_FILE,'utf8'));for(const [k,v] of Object.entries(o||{})){if(k&&Number(v)>0)pullApartMakeIdCache.set(canonicalMake(k),Number(v));}}catch{}}
function savePapMakeCache(){try{const o=Object.fromEntries([...pullApartMakeIdCache.entries()].sort());require('fs').writeFileSync(PULLAPART_CACHE_FILE,JSON.stringify(o,null,2));}catch(e){console.error('Pull-A-Part make cache write failed:',e.message)}}
loadPapMakeCache();
const pullApartCatalog={makes:new Map(),models:new Map(),locations:new Map(),lastUpdated:null};

function papModelKey(v){return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
function papModelMatches(actual,wanted){
 const a=papModelKey(actual), w=papModelKey(wanted);
 if(!a||!w) return false;
 return a===w || a.startsWith(w) || w.startsWith(a);
}
function parsePapVinInfo(value){
 if(!value) return {};
 if(typeof value==='object') return value;
 if(typeof value==='string'){
  try{return JSON.parse(value)}catch{}
 }
 return {};
}
function rememberPapRows(rows){
 for(const v of rows||[]){
  const make=canonicalMake(v.makeName), mid=Number(v.makeID);
  if(make&&mid){pullApartCatalog.makes.set(make,mid);if(pullApartMakeIdCache.get(make)!==mid){pullApartMakeIdCache.set(make,mid);savePapMakeCache();}}
  const model=String(v.modelName||'').trim(), modelId=Number(v.modelID);
  if(make&&model){
   if(!pullApartCatalog.models.has(make)) pullApartCatalog.models.set(make,new Map());
   const m=pullApartCatalog.models.get(make); const key=papModelKey(model);
   if(key&&!m.has(key)) m.set(key,{name:model,id:modelId||null});
  }
  const locationId=Number(v.locationID), locationName=String(v.locationName||'').trim();
  if(locationId&&locationName) pullApartCatalog.locations.set(locationId,locationName);
 }
 pullApartCatalog.lastUpdated=new Date().toISOString();
}
function papObservedModelCatalog(make){
 const key=canonicalMake(make);
 const m=pullApartCatalog.models.get(key);
 const models=m?[...m.values()].sort((a,b)=>String(a.name).localeCompare(String(b.name))):[];
 return {
  make:key,
  makeId:pullApartCatalog.makes.get(key)||pullApartMakeIdCache.get(key)||null,
  source:'observed-official-inventory',
  complete:false,
  status:'OBSERVED_ONLY',
  explanation:'These models were learned from authoritative Pull-A-Part vehicle rows. They are not treated as a complete master model list.',
  models
 };
}
function papModelCatalogAssessment(make,model){
 const cat=papObservedModelCatalog(make), wanted=papModelKey(model);
 const hit=cat.models.find(x=>papModelKey(x.name)===wanted)||null;
 return {...cat,requestedModel:String(model||''),requestedModelKey:wanted,requestedModelObserved:!!hit,requestedModelId:hit?.id||null};
}
function papYardId(v){
 const loc=String(v.locationName||pullApartCatalog.locations.get(Number(v.locationID))||'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim();
 if(loc.includes('ATLANTA EAST')) return 'pull-apart-atl-east';
 if(loc.includes('ATLANTA NORTH')) return 'pull-apart-atl-north';
 if(loc.includes('ATLANTA SOUTH')) return 'pull-apart-atl-south';
 if(loc.includes('AUGUSTA')) return 'pull-apart-augusta';
 return null;
}
function papTelemetryBase(query,started){
 return {attemptedAt:new Date().toISOString(),query,vehicleCount:0,responseMs:Date.now()-started,error:'',stage:'STARTED',endpoint:'/Vehicle/Search',makeId:null,modelKey:papModelKey(query.split(/\s+/).slice(1).join(' ')),attempts:0,successfulResponses:0,httpErrors:0,timeouts:0,transportErrors:0,rawRecords:0,targetMakeRecords:0,targetModelRecords:0,georgiaModelRecords:0,diagnostic:'',idsTried:[],responseSamples:[],modelsSeen:[],locationsSeen:[]};
}
function setPapTelemetry(yardIds,base,rows=[]){
 for(const yardId of yardIds){
  const n=rows.filter(r=>r.yardId===yardId).length;
  searchConnectorTelemetry.set(yardId,{...base,vehicleCount:n,responseMs:base.responseMs||0});
 }
}
async function papPost(endpoint,headers,body,timeoutMs=6500){
 const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
 try{
  const r=await fetch(endpoint,{method:'POST',headers,body:JSON.stringify(body),signal:ctrl.signal});
  const text=await r.text();
  let json=null; try{json=JSON.parse(text)}catch{}
  return {ok:r.ok,status:r.status,json,text:text.slice(0,500),contentType:r.headers.get('content-type')||'',bodyBytes:Buffer.byteLength(text||'','utf8')};
 }finally{clearTimeout(timer)}
}



async function pullApartSiteDiscovery(){
 const started=Date.now();
 const pages=['https://www.pullapart.com/used-auto-parts/search-car-inventory/','https://www.pullapart.com/inventory-v2/','https://www.pullapart.com/inventory-v2/search/'];
 const headers={'user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/9.6.0','accept':'text/html,application/xhtml+xml,application/javascript,text/javascript,*/*'};
 const out={version:BUILD_VERSION,generatedAt:new Date().toISOString(),pages:[],scripts:[],candidates:[],errors:[],responseMs:0};
 const seenScripts=new Set(), candidateSet=new Set();
 const addCandidate=(value,source)=>{if(!value)return; const v=String(value).replace(/&amp;/g,'&').trim(); if(v.length<4||v.length>500)return; const key=v+'|'+source; if(candidateSet.has(key))return; candidateSet.add(key); out.candidates.push({value:v,source});};
 const scan=(text,source)=>{
   const patterns=[
    /https?:\\?\\?\/\/[^"'`\\s<>]+/gi,
    /(?:https?:)?\/\/[^"'`\\s<>]+/gi,
    /["'`](\/?[^"'`\\s<>]*(?:api|inventory|vehicle|search|interchange|model|make)[^"'`\\s<>]*)["'`]/gi,
    /(?:AdvancedVehicleSearch|BasicVehicleSearch|VehicleSearch|GetModels|GetMakes|GetInventory|InventorySearch)[^"'`\\s<>]*/gi
   ];
   for(const p of patterns){let m;let count=0;while((m=p.exec(text))&&count<250){const v=m[1]||m[0]; if(/pullapart|inventory|vehicle|interchange|api|model|make|search/i.test(v)) addCandidate(v,source); count++;}}
 };
 for(const page of pages){
  try{
   const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),10000);
   const r=await fetch(page,{headers,signal:ctrl.signal}); const html=await r.text(); clearTimeout(timer);
   out.pages.push({url:page,status:r.status,ok:r.ok,bytes:Buffer.byteLength(html||'','utf8')}); scan(html,page);
   const rx=/<script[^>]+src=["']([^"']+)["'][^>]*>/gi; let m;
   while((m=rx.exec(html))){try{const u=new URL(m[1],page).href; if(!seenScripts.has(u)){seenScripts.add(u);out.scripts.push({url:u,status:null,bytes:0})}}catch{}}
  }catch(e){out.errors.push({source:page,error:e?.message||String(e)})}
 }
 // Inspect a bounded number of first-party scripts. This runs from the user's Codespace,
 // which sees the same public site resources as the app connector.
 let inspected=0;
 for(const item of out.scripts){
  if(inspected>=30) break;
  try{
   const u=new URL(item.url); if(!/pullapart\.com$/i.test(u.hostname)&&!/\.pullapart\.com$/i.test(u.hostname)) continue;
   const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),10000);
   const r=await fetch(item.url,{headers,signal:ctrl.signal}); const js=await r.text(); clearTimeout(timer);
   item.status=r.status; item.bytes=Buffer.byteLength(js||'','utf8'); inspected++; scan(js,item.url);
  }catch(e){item.error=e?.message||String(e)}
 }
 out.scriptsInspected=inspected;
 out.candidates=out.candidates.filter(x=>/pullapart|externalinterchange|inventory|vehicle|interchange|api|model|make|search/i.test(x.value)).slice(0,500);
 out.responseMs=Date.now()-started;
 out.note='Discovery only: this endpoint inventories the current Pull-A-Part site pages/scripts so we can identify the same live search service used by their website before replacing the legacy connector.';
 return out;
}

const PAP_INVENTORY_BASE='https://inventoryservice.pullapart.com';
const PAP_GA_LOCATIONS=[21,4,3,9];
let papMakeCatalogCache={at:0,rows:[]};
const papModelCatalogCache=new Map();

async function papGetJson(pathname,timeoutMs=6500){
 const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
 try{
  const r=await fetch(PAP_INVENTORY_BASE+pathname,{headers:{'accept':'application/json','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/inventory-v2/search/','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/9.6.0'},signal:ctrl.signal});
  const text=await r.text(); let json=null; try{json=JSON.parse(text)}catch{}
  if(!r.ok) throw Error(`Pull-A-Part ${pathname} returned HTTP ${r.status}`);
  if(json===null) throw Error(`Pull-A-Part ${pathname} did not return JSON`);
  return json;
 }finally{clearTimeout(timer)}
}
async function papVehicleDetails(locID,ticketID,lineID){
 const ids=[locID,ticketID,lineID].map(Number);
 if(ids.some(x=>!Number.isFinite(x)||x<=0)) throw Error('Invalid Pull-A-Part vehicle identifiers');
 const [extended,image] = await Promise.allSettled([
  papGetJson(`/VehicleExtendedInfo/${ids[0]}/${ids[1]}/${ids[2]}`,6500),
  (async()=>{
   const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),5500);
   try{
    const q=new URLSearchParams({locID:String(ids[0]),ticketID:String(ids[1]),lineID:String(ids[2]),programID:'35',imageIndex:'1'});
    const r=await fetch('https://imageservice.pullapart.com/img/retrieveimage/?'+q.toString(),{headers:{'accept':'application/json','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/inventory-v2/search/','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/9.6.0'},signal:ctrl.signal});
    const text=await r.text(); let json=null; try{json=JSON.parse(text)}catch{}
    if(!r.ok) throw Error(`Pull-A-Part image service returned HTTP ${r.status}`);
    return json;
   } finally {clearTimeout(timer)}
  })()
 ]);
 const ext=extended.status==='fulfilled'?extended.value:null;
 const img=image.status==='fulfilled'?image.value:null;
 const imageUrl=(img&&typeof img==='object'&&(img.webPath||img.WebPath||img.url||img.imageUrl))||null;
 return {extendedInfo:ext,image:imageUrl&&String(imageUrl).toLowerCase().includes('error retrieving image')?null:imageUrl,extendedInfoError:extended.status==='rejected'?extended.reason?.message||String(extended.reason):null,imageError:image.status==='rejected'?image.reason?.message||String(image.reason):null};
}

async function getPapMakeCatalog(force=false){
 if(!force && papMakeCatalogCache.rows.length && Date.now()-papMakeCatalogCache.at<6*60*60*1000) return papMakeCatalogCache.rows;
 const rows=await papGetJson('/Make/');
 const arr=Array.isArray(rows)?rows:[];
 papMakeCatalogCache={at:Date.now(),rows:arr};
 for(const x of arr){const name=canonicalMake(x.makeName),id=Number(x.makeID);if(name&&id){pullApartCatalog.makes.set(name,id);pullApartMakeIdCache.set(name,id)}}
 if(arr.length) savePapMakeCache();
 pullApartCatalog.lastUpdated=new Date().toISOString();
 return arr;
}
async function getPapModelCatalog(makeId,makeName='',force=false){
 const key=Number(makeId); const cached=papModelCatalogCache.get(key);
 if(!force && cached?.rows?.length && Date.now()-cached.at<6*60*60*1000) return cached.rows;
 const rows=await papGetJson(`/Model?makeID=${encodeURIComponent(key)}`);
 const arr=Array.isArray(rows)?rows:[]; papModelCatalogCache.set(key,{at:Date.now(),rows:arr});
 const make=canonicalMake(makeName);
 if(make){
  const m=new Map();
  for(const x of arr){const name=String(x.modelName||'').trim(),id=Number(x.modelID)||null,k=papModelKey(name);if(k&&name)m.set(k,{name,id})}
  pullApartCatalog.models.set(make,m);
 }
 pullApartCatalog.lastUpdated=new Date().toISOString();
 return arr;
}
async function papLiveModelCatalogAssessment(make,model){
 const targetMake=canonicalMake(make), targetModelKey=papModelKey(model);
 const makes=await getPapMakeCatalog();
 const makeRow=makes.find(x=>canonicalMake(x.makeName)===targetMake)||null;
 if(!makeRow) return {make:targetMake,makeId:null,source:'official-current-catalog',complete:true,status:'MAKE_NOT_FOUND',models:[],requestedModel:String(model||''),requestedModelKey:targetModelKey,requestedModelObserved:false,requestedModelId:null};
 const models=await getPapModelCatalog(makeRow.makeID,targetMake);
 const normalized=models.map(x=>({name:String(x.modelName||''),id:Number(x.modelID)||null,showWebsite:x.showWebsite!==false})).filter(x=>x.name).sort((a,b)=>a.name.localeCompare(b.name));
 const hit=normalized.find(x=>papModelKey(x.name)===targetModelKey)||null;
 return {make:targetMake,makeId:Number(makeRow.makeID),source:'official-current-catalog',complete:true,status:hit?'MODEL_FOUND':'MODEL_NOT_FOUND',models:normalized,requestedModel:String(model||''),requestedModelKey:targetModelKey,requestedModelObserved:!!hit,requestedModelId:hit?.id||null};
}

async function fetchPullApartSearch(make,model){
 if(!make||!model) return [];
 const yardIds=['pull-apart-atl-east','pull-apart-atl-north','pull-apart-atl-south','pull-apart-augusta'];
 const endpoint=PAP_INVENTORY_BASE+'/Vehicle/Search';
 const headers={'accept':'application/json','content-type':'application/json','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/inventory-v2/search/','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/9.6.0'};
 const targetMake=canonicalMake(make), targetModel=canonicalModel(model), targetModelKey=papModelKey(model);
 const started=Date.now(), query=[make,model].filter(Boolean).join(' ');
 let t=papTelemetryBase(query,started); t.version=BUILD_VERSION; t.endpoint='/Vehicle/Search'; t.apiBase=PAP_INVENTORY_BASE; t.locationIds=[...PAP_GA_LOCATIONS]; t.catalogSource='official-current-catalog'; t.catalogRequests=0;
 try{
  t.stage='RESOLVE_MAKE'; t.catalogRequests++;
  const makes=await getPapMakeCatalog();
  const makeRow=makes.find(x=>canonicalMake(x.makeName)===targetMake)||null;
  if(!makeRow){
   t.stage='MAKE_NOT_FOUND'; t.responseMs=Date.now()-started; t.diagnostic=`${targetMake} was not found in Pull-A-Part's current /Make/ catalog.`;
   setPapTelemetry(yardIds,t,[]); papDeepDiagnostics.set(query,{...t,rowsByYard:Object.fromEntries(yardIds.map(id=>[id,0]))}); return [];
  }
  const makeId=Number(makeRow.makeID); t.makeId=makeId; pullApartMakeIdCache.set(targetMake,makeId); savePapMakeCache();

  t.stage='RESOLVE_MODEL'; t.catalogRequests++;
  const models=await getPapModelCatalog(makeId,targetMake);
  const modelRow=models.find(x=>papModelKey(x.modelName)===targetModelKey)||null;
  t.modelCatalog={make:targetMake,makeId,source:'official-current-catalog',complete:true,status:modelRow?'MODEL_FOUND':'MODEL_NOT_FOUND',requestedModel:String(model||''),requestedModelKey:targetModelKey,requestedModelObserved:!!modelRow,requestedModelId:modelRow?Number(modelRow.modelID):null,models:models.map(x=>({name:String(x.modelName||''),id:Number(x.modelID)||null})).filter(x=>x.name)};
  if(!modelRow){
   t.stage='MODEL_NOT_FOUND'; t.responseMs=Date.now()-started; t.modelsSeen=t.modelCatalog.models.map(x=>x.name).slice(0,150); t.diagnostic=`${targetModel} was not found in Pull-A-Part's current official model catalog for ${targetMake}.`;
   setPapTelemetry(yardIds,t,[]); papDeepDiagnostics.set(query,{...t,rowsByYard:Object.fromEntries(yardIds.map(id=>[id,0]))}); return [];
  }
  const modelId=Number(modelRow.modelID); t.modelId=modelId; t.stage='VEHICLE_SEARCH'; t.attempts=1;
  const res=await papPost(endpoint,headers,{Locations:PAP_GA_LOCATIONS,MakeID:makeId,Models:[modelId],Years:[]},8000);
  t.responseSamples=[{status:res.status,ok:res.ok,contentType:res.contentType,bodyBytes:res.bodyBytes,preview:res.text}];
  if(!res.ok){t.httpErrors=1;throw Error(`Pull-A-Part /Vehicle/Search returned HTTP ${res.status}`)}
  t.successfulResponses=1;
  const groups=Array.isArray(res.json)?res.json:[];
  const raw=[];
  for(const group of groups){
   const locationID=Number(group?.locationID)||0;
   for(const bucket of ['exact','other']) for(const v of (Array.isArray(group?.[bucket])?group[bucket]:[])) raw.push({...v,_bucket:bucket,locationID:v.locationID||locationID});
  }
  t.rawRecords=raw.length;
  const makeRows=raw.filter(v=>canonicalMake(v.makeName)===targetMake);
  const modelRows=makeRows.filter(v=>papModelKey(v.modelName)===targetModelKey);
  t.targetMakeRecords=makeRows.length; t.targetModelRecords=modelRows.length;
  t.modelsSeen=[...new Set(makeRows.map(v=>String(v.modelName||'').trim()).filter(Boolean))].sort();
  t.locationsSeen=[...new Set(groups.map(g=>String(g?.locationID||'')).filter(Boolean))].sort();
  rememberPapRows(modelRows.map(v=>({...v,locationName:v.locName||v.locationName,locationID:v.locID||v.locationID})));
  const out=[];
  for(const v of modelRows){
   const normalized={...v,locationName:v.locName||v.locationName,locationID:v.locID||v.locationID};
   const yardId=papYardId(normalized); if(!yardId) continue;
   const y=YARDS.find(x=>x.id===yardId); if(!y) continue;
   const arrival=v.dateYardOn?String(v.dateYardOn).split('T')[0]:'';
   let ad=null; if(arrival){try{ad=new Date(arrival+'T00:00:00').toISOString()}catch{}}
   out.push({yardId,yard:y.name,year:Number(v.modelYear)||'',make:v.makeName||targetMake,model:v.modelName||targetModel,submodel:'',row:v.row||'',vin:v.vin||'',stock:'',arrival,arrivalDate:ad,sourceUrl:y.website,diy:true,live:true,isNew:ad?isRecent(ad):false,body:'',drive:'',sourceType:'official-api',pullApart:{vinID:v.vinID||null,ticketID:v.ticketID||null,lineID:v.lineID||null,locID:v.locID||v.locationID||null,modelID:v.modelID||modelId,matchBucket:v._bucket}});
  }
  const rows=dedupeInventory(out); t.georgiaModelRecords=rows.length; t.vehicleCount=rows.length; t.responseMs=Date.now()-started;
  t.stage=rows.length?'PARSED_RESULTS':'NO_GEORGIA_RESULTS';
  t.diagnostic=rows.length?`Current Pull-A-Part /Vehicle/Search returned ${rows.length} Georgia ${targetMake} ${targetModel} vehicle(s).`:`Pull-A-Part's current /Vehicle/Search returned no Georgia ${targetMake} ${targetModel} vehicles.`;
  setPapTelemetry(yardIds,t,rows);
  papDeepDiagnostics.set(query,{...t,rowsByYard:Object.fromEntries(yardIds.map(id=>[id,rows.filter(r=>r.yardId===id).length]))});
  return rows;
 }catch(e){
  if(e?.name==='AbortError') t.timeouts=(t.timeouts||0)+1; else t.transportErrors=(t.transportErrors||0)+1;
  t={...t,responseMs:Date.now()-started,error:e?.message||String(e),stage:'CONNECTOR_ERROR',diagnostic:'Current Pull-A-Part Inventory Service request failed.'};
  setPapTelemetry(yardIds,t,[]); papDeepDiagnostics.set(query,{...t,rowsByYard:Object.fromEntries(yardIds.map(id=>[id,0]))});
  console.error('Pull-A-Part current Inventory Service connector failed:',e.message); return [];
 }
}

const fenixTelemetry={version:BUILD_VERSION,status:'NOT_RUN',url:'https://fenixupull.com/recent-inventory/',rowsScanned:0,moultrieRows:0,validRows:0,invalidRows:0,withVin:0,withStock:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:null,sample:[]};
async function fetchFenixMoultrie(){
 const url='https://fenixupull.com/recent-inventory/'; const started=Date.now();
 Object.assign(fenixTelemetry,{version:BUILD_VERSION,status:'RUNNING',url,rowsScanned:0,moultrieRows:0,validRows:0,invalidRows:0,withVin:0,withStock:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:new Date().toISOString(),sample:[]});
 try{
  const html=await fetchText(url), out=[]; const y=YARDS.find(x=>x.id==='fenix-moultrie');
  for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
   for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
    fenixTelemetry.rowsScanned++;
    const cells=tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[];
    const c=cells.map(strip); if(c.length<8) continue;
    if(!/^Moultrie,?\s*GA$/i.test(String(c[7]||'').trim())) continue;
    fenixTelemetry.moultrieRows++;
    const date=c[0], make=c[1], model=c[2], year=Number(c[3]), row=c[4], vin=String(c[5]||'').replace(/[^A-Z0-9]/gi,'').toUpperCase(), stock=c[6];
    const href=(tr.match(/href=["']([^"']+)["']/i)||[])[1]||'';
    let detail=url; try{if(href) detail=new URL(href,url).href}catch{}
    const ad=dateFromMDY(date);
    if(!(year>1900&&year<2101&&make&&model&&vin.length===17)){fenixTelemetry.invalidRows++;continue}
    out.push({yardId:'fenix-moultrie',yard:y.name,year,make,model,submodel:'',row,vin,stock,arrival:date,arrivalDate:ad,sourceUrl:detail,diy:true,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
   }
  }
  const rows=dedupeInventory(out);
  Object.assign(fenixTelemetry,{status:rows.length?'LIVE':'EMPTY',validRows:rows.length,withVin:rows.filter(x=>x.vin).length,withStock:rows.filter(x=>x.stock).length,withRow:rows.filter(x=>x.row).length,withArrival:rows.filter(x=>x.arrival).length,responseMs:Date.now()-started,checkedAt:new Date().toISOString(),sample:rows.slice(0,5).map(x=>({year:x.year,make:x.make,model:x.model,row:x.row,vin:x.vin,stock:x.stock,arrival:x.arrival}))});
  return rows;
 }catch(e){Object.assign(fenixTelemetry,{status:'ERROR',error:e.message,responseMs:Date.now()-started,checkedAt:new Date().toISOString()});console.error('Fenix Moultrie connector failed:',e.message);return []}
}
function parseGo(html,yardId,yardName,url){
 const out=[]; const tables=html.match(/<table[\s\S]*?<\/table>/gi)||[];
 for(const table of tables){for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
  const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip); if(c.length<5)continue;
  const year=Number(c[0]); if(year<1900||year>2100)continue;
  const [yr,make,model,row,vin,arrival]=c; const ad=dateFromMDY(arrival); const y=YARDS.find(x=>x.id===yardId);
  const href=(tr.match(/href=["']([^"']*\/inventory\/[^"']+)["']/i)||[])[1];
  const detail=href?(href.startsWith('http')?href:new URL(href,'https://gopullit.com').href):url;
  out.push({yardId,yard:yardName,year:Number(yr),make,model,submodel:'',row,vin,stock:'',arrival:arrival||'',arrivalDate:ad,sourceUrl:detail,diy:true,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
 }} return out;
}
async function fetchGoSearch(yardId,yardName,make,model){
 if(!make||!model)return [];
 const loc=yardId==='go-pull-it-gainesville'?'gainesville-ga':'atlanta-east';
 const url='https://gopullit.com/inventory/?location='+encodeURIComponent(loc)+'&make='+encodeURIComponent(make.toUpperCase())+'&model='+encodeURIComponent(model.toUpperCase());
 const started=Date.now(), query=[make,model].filter(Boolean).join(' ');
 try{
  const rows=parseGo(await fetchText(url),yardId,yardName,url);
  searchConnectorTelemetry.set(yardId,{attemptedAt:new Date().toISOString(),query,vehicleCount:rows.length,responseMs:Date.now()-started,error:''});
  return rows;
 }catch(e){
  searchConnectorTelemetry.set(yardId,{attemptedAt:new Date().toISOString(),query,vehicleCount:0,responseMs:Date.now()-started,error:e.message||String(e)});
  console.error('GO Pull-It connector failed:',e.message);return []
 }
}
function pickNPullText(html){return strip(String(html||'').replace(/<br\s*\/?\s*>/gi,' | ').replace(/<\/\s*(?:div|p|li|tr|td|th|section|article|h[1-6])\s*>/gi,' | '))}
function pickNPullField(text,label){
 const re=new RegExp('\\b'+label.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+'\\s*:?\\s*([^|]{1,100}?)(?=\\s*\\||\\s+(?:Row|Date Added|Trim|Engine|Transmission|Color|VIN|Barcode|Stock|Make|Model|Year)\\b|$)','i');
 return strip((text.match(re)||[])[1]||'');
}
async function fetchPickNPullOfficialVehicle(vin){
 const clean=String(vin||'').replace(/[^A-Z0-9]/gi,'').toUpperCase();
 if(clean.length!==17) throw Error('A 17-character VIN is required');
 const url='https://www.picknpull.com/check-inventory/vehicle-details/'+encodeURIComponent(clean);
 const started=Date.now();
 const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.9'},redirect:'follow'});
 const html=await r.text();
 if(!r.ok) return {verified:false,status:r.status,url,responseMs:Date.now()-started,error:'Official Pick-n-Pull detail request failed: '+r.status};
 const text=pickNPullText(html);
 const vinFound=(text.match(/\\b[A-HJ-NPR-Z0-9]{17}\\b/i)||[])[0]||'';
 const sameVin=vinFound.toUpperCase()===clean || text.toUpperCase().includes(clean);
 const details={
  row:pickNPullField(text,'Row'),dateAdded:pickNPullField(text,'Date Added'),trim:pickNPullField(text,'Trim'),
  engine:pickNPullField(text,'Engine'),transmission:pickNPullField(text,'Transmission'),color:pickNPullField(text,'Color'),
  barcode:pickNPullField(text,'Barcode')||pickNPullField(text,'Stock')
 };
 const hasDetail=Object.values(details).some(Boolean);
 return {verified:Boolean(sameVin&&(hasDetail||/Pick[- ]?n[- ]?Pull/i.test(text))),vin:clean,url,responseMs:Date.now()-started,details,error:''};
}

async function fetchRow52JeffersonSearch(make,model,year=''){
 const started=Date.now(), base='https://www.row52.com/Search';
 const q=[year,make,model].filter(Boolean).join(' ').trim();
 if(!make||!model) return [];
 const diag={yardId:'pick-n-pull-jefferson',mode:'ROW52_YEAR_SEARCH',attemptedAt:new Date().toISOString(),query:q,year:year||'',pagesFetched:0,recordsReceived:0,usableVehicles:0,responseMs:0,sourceUrl:base,error:'',strategy:''};
 const out=[];
 try{
  // Row52's public Search page reliably honors the Year parameter.  RC5 attempted to send
  // free text in YMMorVIN, which the site does not use for this request and therefore missed
  // Jefferson.  For an exact-year search, retrieve that year's result pages and filter the
  // returned vehicle text locally by make/model + PICK-n-PULL Jefferson.
  const years=[];
  if(/^\d{4}$/.test(String(year||''))) years.push(String(year));
  else {
   // Without a year, use a bounded recent-year sweep. Baseline Jefferson inventory remains
   // supplied separately; this connector is a search supplement, not a claimed full feed.
   const now=new Date().getUTCFullYear(); for(let y=now;y>=Math.max(1981,now-15);y--) years.push(String(y));
  }
  diag.strategy=years.length===1?'exact-year Row52 search':'bounded recent-year Row52 sweep';
  for(const yr of years){
   for(let page=1;page<=4;page++){
    const url=base+'?'+new URLSearchParams({MakeId:'0',ModelId:'0',Page:String(page),Year:yr}).toString();
    const html=await fetchText(url,10000); diag.pagesFetched++;
    const text=pickNPullText(html);
    const re=/\b((?:19|20)\d{2})\s+([A-Za-z0-9&.'-]+)\s+(.+?)\s+PICK[- ]n[- ]PULL Jefferson\s+((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},?\s+20\d{2})\s+([A-HJ-NPR-Z0-9]{17}|Not Available)/gi;
    let m, found=0;
    while((m=re.exec(text))){
     found++;
     const recMake=strip(m[2]),recModel=strip(m[3]);
     if(norm(recMake)!==norm(make) || norm(recModel)!==norm(model)) continue;
     const vin=/^[A-HJ-NPR-Z0-9]{17}$/i.test(m[5])?m[5].toUpperCase():'';
     const iso=new Date(m[4]).toISOString();
     out.push({yardId:'pick-n-pull-jefferson',yard:'Pick-N-Pull Jefferson',year:Number(m[1]),make:recMake,model:recModel,submodel:'',color:'',row:'',vin,stock:'',arrival:m[4],arrivalDate:iso,sourceUrl:url,diy:true,live:false,isNew:isRecent(iso),sourceType:'row52-targeted-search'});
    }
    diag.recordsReceived+=found;
    // Row52 generally returns the complete exact-year result on page 1 when the result set is small.
    // Continue only when the page visibly advertises more pagination/results.
    const totalMatch=text.match(/([\d,]+)\s+Results:/i); const total=totalMatch?Number(totalMatch[1].replace(/,/g,'')):0;
    if(!total || total<=30*page) break;
   }
   if(out.length && years.length>1) break;
  }
 }catch(e){diag.error=e.message||String(e)}
 const rows=dedupeInventory(out); diag.usableVehicles=rows.length;diag.responseMs=Date.now()-started;
 pnpJeffersonTelemetry.set('pick-n-pull-jefferson-search',diag);
 return rows;
}

async function fetchPickNPullJefferson(){
 const official='https://www.picknpull.com/check-inventory/vehicle-search?distance=25&zip=30549';
 try{
  const direct=parseGo(await fetchText(official),'pick-n-pull-jefferson','Pick-N-Pull Jefferson',official);
  if(direct.length) return direct.map(x=>({...x,sourceType:'official-public-html'}));
 }catch(e){console.error('Pick-N-Pull Jefferson official connector failed:',e.message)}
 // Pick-n-Pull's search page is client-rendered in this environment. The fallback inventory
 // publishes 15 rows per page plus a current total. RC2 fetched only page 1; RC3 walks all pages.
 const started=Date.now(), base='https://u-pull-it.com/inventory/pick-n-pull-jefferson';
 const diag={yardId:'pick-n-pull-jefferson',attemptedAt:new Date().toISOString(),recordsReceived:0,rejectedMalformed:0,recordsWithVin:0,usableVehicles:0,responseMs:0,sourceUrl:base,pagesFetched:0,reportedTotal:null,complete:false,error:''};
 const cleaned=[]; let expected=null, page=1, previousFingerprint='';
 try{
  while(page<=120){
   const url=page===1?base:base+'?page='+page;
   const html=await fetchText(url,10000);
   diag.pagesFetched++;
   if(expected==null){const m=strip(html).match(/Showing\s+[\d,]+\s+vehicles/i)||strip(html).match(/of\s+([\d,]+)/i); if(m){const n=(m[1]||m[0].match(/[\d,]+/)[0]).replace(/,/g,''); expected=Number(n);diag.reportedTotal=expected}}
   const table=(html.match(/<table[\s\S]*?<\/table>/gi)||[])[0]||'';
   const pageRows=[]; let ordinal=0;
   for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
    const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip); if(c.length<7)continue;
    const year=Number(c[0]),make=strip(c[1]),model=strip(c[2]);
    if(!(year>1900&&year<2101&&make&&model)){diag.rejectedMalformed++;continue}
    ordinal++; const row=strip(c[4]); let vin=String(c[5]||'').replace(/[^A-Z0-9]/gi,'').toUpperCase(); if(!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin))vin='';
    const arrival=strip(c[6]), iso=/^\d{4}-\d{2}-\d{2}$/.test(arrival)?new Date(arrival+'T00:00:00Z').toISOString():dateFromMDY(arrival);
    if(vin)diag.recordsWithVin++;
    pageRows.push({yardId:'pick-n-pull-jefferson',yard:'Pick-N-Pull Jefferson',year,make,model,submodel:'',color:strip(c[3]),row,vin,stock:'',arrival,arrivalDate:iso,sourceUrl:url,diy:true,live:false,isNew:iso?isRecent(iso):false,sourceType:'public-index-fallback',sourceRecordKey:`page-${page}-row-${ordinal}`});
   }
   if(!pageRows.length)break;
   const fingerprint=pageRows.map(v=>[v.year,v.make,v.model,v.row,v.arrival].join('|')).join('||');
   if(fingerprint===previousFingerprint)break;
   previousFingerprint=fingerprint; cleaned.push(...pageRows); diag.recordsReceived+=pageRows.length;
   if(expected&&cleaned.length>=expected)break;
   if(pageRows.length<15 && !expected)break;
   page++;
  }
  diag.usableVehicles=cleaned.length; diag.complete=!!expected&&cleaned.length>=expected;
  if(expected&&!diag.complete)diag.error=`Fallback pagination returned ${cleaned.length} of ${expected} reported vehicles`;
 }catch(e){diag.error=e.message||String(e)}
 diag.responseMs=Date.now()-started; pnpJeffersonTelemetry.set('pick-n-pull-jefferson',diag);
 return cleaned;
}


async function fetchPublicIndexedYard(url,yardId,yardName){
 try{
  const html=await fetchText(url), out=[];
  for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
   for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
    const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip);
    if(c.length<5) continue;
    const year=Number(c[0]); if(year<1900||year>2100) continue;
    const make=c[1], model=c[2];
    if(!make||!model||/year/i.test(make)) continue;
    let color='',row='',vin='',arrival='';
    if(c.length>=7){color=c[3];row=c[4];vin=c[5];arrival=c[6]}
    // Some public indexes move columns around. Recover VIN/row/date from any cell when possible.
    const joined=c.join(' | ');
    const vinMatch=joined.toUpperCase().match(/\b[A-HJ-NPR-Z0-9]{17}\b/);
    if(vinMatch) vin=vinMatch[0];
    const rowMatch=joined.match(/\bROW\s*[:#-]?\s*([A-Z0-9-]{1,12})\b/i);
    if(rowMatch) row=rowMatch[1];
    const dateMatch=joined.match(/\b(?:DATE\s+ADDED|ARRIVAL|AVAILABLE)\s*:?\s*(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/i);
    if(dateMatch) arrival=dateMatch[1];
    const y=YARDS.find(x=>x.id===yardId), ad=dateFromMDY(arrival);
    out.push({yardId,yard:yardName,year,make,model,submodel:'',row,vin,stock:'',arrival,arrivalDate:ad,sourceUrl:url,diy:true,live:true,isNew:ad?isRecent(ad):false,sourceType:'public-index'});
   }
  }
  return out;
 }catch(e){console.error('Public indexed source failed '+yardName+':',e.message);return []}
}


const cashNCarryTelemetry={version:BUILD_VERSION,status:'NOT_RUN',url:'https://cashncarryparts.com/search-inventory/',rowsScanned:0,validRows:0,invalidRows:0,placeholderDatesCleared:0,withColor:0,withStock:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:null};
function validCashArrival(s){
 const v=String(s||'').trim();
 if(!v||/^0?1\/0?1\/(?:19)?70$/.test(v)) return '';
 const d=dateFromMDY(v); if(!d) return '';
 const y=new Date(d).getUTCFullYear(); return y>=2000&&y<=new Date().getUTCFullYear()+1?v:'';
}
async function fetchCashNCarry(){
 const url='https://cashncarryparts.com/search-inventory/'; const started=Date.now();
 Object.assign(cashNCarryTelemetry,{version:BUILD_VERSION,status:'RUNNING',url,rowsScanned:0,validRows:0,invalidRows:0,placeholderDatesCleared:0,withColor:0,withStock:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:new Date().toISOString()});
 try{
  const html=await fetchText(url), out=[]; const y=YARDS.find(x=>x.id==='cash-n-carry');
  for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
   for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
    const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip);
    if(c.length<7) continue;
    cashNCarryTelemetry.rowsScanned++;
    const [yearText,make,model,color,stock,row,arrivalRaw]=c;
    const year=Number(yearText);
    if(!(year>1900&&year<2101&&make&&model)||/^(year|make|model)$/i.test(String(make).trim())){cashNCarryTelemetry.invalidRows++;continue}
    const arrival=validCashArrival(arrivalRaw);
    if(arrivalRaw&&!arrival) cashNCarryTelemetry.placeholderDatesCleared++;
    const ad=arrival?dateFromMDY(arrival):null;
    out.push({yardId:'cash-n-carry',yard:y.name,year,make,model,submodel:'',body:'',color,row,vin:'',stock,arrival,arrivalDate:ad,sourceUrl:url,diy:true,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
   }
  }
  const seen=new Set(), rows=[];
  for(const v of out){const k=(v.stock||[v.year,v.make,v.model,v.row,v.arrival].join('|')).toUpperCase();if(seen.has(k))continue;seen.add(k);rows.push(v)}
  Object.assign(cashNCarryTelemetry,{status:rows.length?'LIVE':'EMPTY',validRows:rows.length,withColor:rows.filter(x=>x.color).length,withStock:rows.filter(x=>x.stock).length,withRow:rows.filter(x=>x.row).length,withArrival:rows.filter(x=>x.arrival).length,responseMs:Date.now()-started,checkedAt:new Date().toISOString()});
  return rows;
 }catch(e){Object.assign(cashNCarryTelemetry,{status:'ERROR',error:e.message,responseMs:Date.now()-started,checkedAt:new Date().toISOString()});console.error('Cash N Carry connector failed:',e.message);return []}
}

const highway82Telemetry={version:BUILD_VERSION,status:'NOT_RUN',url:'https://hwy82pp.com/search-inventory/',rowsScanned:0,poulanRows:0,validRows:0,invalidRows:0,withColor:0,withEngine:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:null};
async function fetchHighway82(){
 const url='https://hwy82pp.com/search-inventory/'; const started=Date.now();
 Object.assign(highway82Telemetry,{version:BUILD_VERSION,status:'RUNNING',url,rowsScanned:0,poulanRows:0,validRows:0,invalidRows:0,withColor:0,withEngine:0,withRow:0,withArrival:0,responseMs:0,error:'',checkedAt:new Date().toISOString()});
 try{
  const html=await fetchText(url), out=[]; const y=YARDS.find(x=>x.id==='highway82');
  for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
   for(const tr of table.match(/<tr[\s\S]*?<\/tr>/gi)||[]){
    const c=(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip);
    if(c.length<8) continue;
    highway82Telemetry.rowsScanned++;
    const [yearText,make,model,color,engine,row,arrival,location]=c;
    if(String(location).trim().toUpperCase()!=='POULAN') continue;
    highway82Telemetry.poulanRows++;
    const year=Number(yearText);
    if(!(year>1900&&year<2101&&make&&model)){highway82Telemetry.invalidRows++;continue}
    const ad=dateFromMDY(arrival);
    out.push({yardId:'highway82',yard:y.name,year,make,model,submodel:'',body:'',color,engine,row,vin:'',stock:'',arrival,arrivalDate:ad,sourceUrl:url,diy:true,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html'});
   }
  }
  const seen=new Set(), rows=[];
  for(const v of out){const k=[v.year,v.make,v.model,v.color,v.row,v.arrival].join('|').toUpperCase();if(seen.has(k))continue;seen.add(k);rows.push(v)}
  Object.assign(highway82Telemetry,{status:rows.length?'LIVE':'EMPTY',validRows:rows.length,withColor:rows.filter(x=>x.color).length,withEngine:rows.filter(x=>x.engine).length,withRow:rows.filter(x=>x.row).length,withArrival:rows.filter(x=>x.arrival).length,responseMs:Date.now()-started,checkedAt:new Date().toISOString()});
  return rows;
 }catch(e){Object.assign(highway82Telemetry,{status:'ERROR',error:e.message,responseMs:Date.now()-started,checkedAt:new Date().toISOString()});console.error('Highway 82 connector failed:',e.message);return []}
}

async function createPypSession(){
 const headers={
  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
  'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language':'en-US,en;q=0.9','Cache-Control':'no-cache','Pragma':'no-cache',
  'Upgrade-Insecure-Requests':'1','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'same-origin','Sec-Fetch-User':'?1'
 };
 let cookie='';
 try{
  const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),8000); const r=await fetch('https://www.pyp.com/',{headers:{...headers,'Sec-Fetch-Site':'none'},signal:ctrl.signal}); clearTimeout(timer);
  const sc=r.headers.getSetCookie?r.headers.getSetCookie():[];
  cookie=sc.map(x=>x.split(';')[0]).join('; ');
  // Consume body so keep-alive/session handling is clean.
  await r.arrayBuffer();
 }catch(e){}
 return {headers,cookie};
}
async function fetchPypText(url,session){
 const h={...session.headers,'Referer':'https://www.pyp.com/'};
 if(session.cookie) h.Cookie=session.cookie;
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),8000); let r; try{r=await fetch(url,{headers:h,redirect:'follow',signal:ctrl.signal})}finally{clearTimeout(timer)};
 if(!r.ok){
  const server=r.headers.get('server')||'';
  throw Error(`${r.status}${server?` (${server})`:''}`);
 }
 const sc=r.headers.getSetCookie?r.headers.getSetCookie():[];
 if(sc.length){
  const add=sc.map(x=>x.split(';')[0]);
  session.cookie=[session.cookie,...add].filter(Boolean).join('; ');
 }
 return r.text();
}
async function fetchPypYard(id,name,base,maxPages=75){
 const started=Date.now(), rows=[], session=await createPypSession();
 const diag={yardId:id,yard:name,attemptedAt:new Date().toISOString(),baseUrl:base,pagesRequested:0,pagesSuccessful:0,pagesParsed:0,vehiclesParsed:0,responseMs:0,lastPage:0,lastHttpError:'',parserNote:'',sessionCookie:!!session.cookie,accessMode:'browser-like session'};
 for(let page=1;page<=maxPages;page++){
  const url=page===1?base:base+'?page='+page;
  diag.pagesRequested++; diag.lastPage=page;
  try{
   const html=await fetchPypText(url,session); diag.pagesSuccessful++;
   const parsed=parsePyp(html,id,name,url);
   if(!parsed.length){
    diag.parserNote=`Page ${page} returned HTML but no vehicle cards were parsed (HTML ${html.length} chars).`;
    break;
   }
   diag.pagesParsed++; rows.push(...parsed);
   // Current official pages expose a "Next Page" link while more inventory remains.
   if(!/Next\s*Page/i.test(strip(html))) break;
  }catch(e){
   diag.lastHttpError=e?.message||String(e);
   console.error(`PYP ${name} page ${page} failed:`,diag.lastHttpError);
   break;
  }
 }
 const result=dedupeInventory(rows);
 diag.vehiclesParsed=result.length; diag.responseMs=Date.now()-started;
 pypConnectorTelemetry.set(id,diag);
 return result;
}

const SW_OFFICIAL_PAGE='https://www.sandwauto.com/inventory-search';
const SW_LEGACY_FULL_SERVICE='http://search2675.used-auto-parts.biz/inventory/retail.htm';
const swTelemetry={version:BUILD_VERSION,status:'NOT_RUN',url:SW_OFFICIAL_PAGE,linkedInventoryUrl:'',httpStatus:null,linkedHttpStatus:null,htmlBytes:0,linkedHtmlBytes:0,tables:0,rowsScanned:0,validRows:0,withVin:0,withStock:0,withRow:0,withArrival:0,links:[],forms:[],scripts:[],candidates:[],linkedForms:[],clientDiscovery:[],responseMs:0,error:'',checkedAt:null,sample:[],provenance:'Official S&W U-Pull inventory search page'};
function swExtractUrls(html,base){
 const vals=[]; for(const m of html.matchAll(/(?:href|src|action)\s*=\s*["']([^"']+)["']/gi)){try{vals.push(new URL(m[1],base).href)}catch{}}
 return [...new Set(vals)].filter(u=>/inventory|yard|vehicle|search|api|u-pull|used-auto-parts/i.test(u));
}
function swForms(html,base){
 return [...html.matchAll(/<form\b[^>]*[\s\S]*?<\/form>/gi)].slice(0,20).map(m=>{
  const raw=m[0],action=(raw.match(/action\s*=\s*["']([^"']*)/i)||[])[1]||'',method=((raw.match(/method\s*=\s*["']([^"']*)/i)||[])[1]||'GET').toUpperCase();
  let actionUrl='';try{actionUrl=new URL(action||base,base).href}catch{actionUrl=action}
  const fields=[...raw.matchAll(/<(?:input|select|textarea)\b[^>]*\bname\s*=\s*["']([^"']+)/gi)].map(x=>x[1]);
  return {action:actionUrl,method,fields:[...new Set(fields)].slice(0,30)};
 });
}
function parseSwLinkedInventory(html,sourceUrl){
 const out=[],y=YARDS.find(v=>v.id==='sw')||{};
 for(const table of html.match(/<table[\s\S]*?<\/table>/gi)||[]){
  const trs=table.match(/<tr[\s\S]*?<\/tr>/gi)||[]; if(!trs.length)continue;
  const matrix=trs.map(tr=>(tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi)||[]).map(strip)).filter(r=>r.length>=3);
  if(!matrix.length)continue;
  let headers=matrix[0].map(x=>x.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim());
  const headerish=headers.some(x=>/year|make|model|vin|stock|row|date|arrival/.test(x));
  const idx=(re)=>headers.findIndex(h=>re.test(h));
  for(let ri=headerish?1:0;ri<matrix.length;ri++){
   const c=matrix[ri]; let year='',make='',model='',vin='',stock='',row='',arrival='';
   if(headerish){
    const take=re=>{const i=idx(re);return i>=0?(c[i]||''):''};
    year=take(/^year$|model year/); make=take(/^make$|manufacturer/); model=take(/^model$|vehicle model/); vin=take(/^vin$|vehicle identification/); stock=take(/stock|yard number/); row=take(/^row$|location|section/); arrival=take(/arrival|date in|received|yard date|date$/);
   }else{
    const joined=c.join(' | '); const ym=joined.match(/\b((?:19|20)\d{2})\b/); year=ym?ym[1]:'';
    const vi=joined.match(/\b([A-HJ-NPR-Z0-9]{17})\b/i); vin=vi?vi[1]:'';
    if(c.length>=5){row=c[0];year=year||c[1];make=c[2];model=c[3];vin=vin||c[4]}
   }
   year=Number(year); if(!(year>1900&&year<2100)||!make||!model||/year|make|model/i.test(make))continue;
   const ad=dateFromMDY(arrival); out.push({yardId:'sw',yard:'S&W U Pull',year,make,model,submodel:'',row,vin,stock,arrival,arrivalDate:ad,sourceUrl,diy:y.diy!==false,live:true,isNew:ad?isRecent(ad):false,sourceType:'official-public-html',sourceLabel:'S&W linked inventory system',sourceTrust:'OFFICIAL',verifiedSource:true});
  }
 }
 return dedupeInventory(out);
}
async function swFetch(url,timeoutMs=12000){
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);try{const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.9','Cache-Control':'no-cache'},redirect:'follow',signal:ctrl.signal});const html=await r.text();return {r,html}}finally{clearTimeout(timer)}}
function swRealResources(html,base){
 const out=[],seen=new Set(),add=(kind,raw)=>{if(!raw)return;try{const u=new URL(String(raw).replace(/&amp;/g,'&'),base);if(!/^https?:$/.test(u.protocol))return;const k=kind+'|'+u.href;if(seen.has(k))return;seen.add(k);out.push({kind,url:u.href})}catch{}};
 for(const m of html.matchAll(/<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi))add('script',m[1]);
 for(const m of html.matchAll(/<form\b[^>]*\baction\s*=\s*["']([^"']+)["']/gi))add('form',m[1]);
 for(const m of html.matchAll(/<a\b[^>]*\bhref\s*=\s*["']([^"']+)["']/gi))if(/inventory|search|upull|u-pull|api|json|data/i.test(m[1]))add('link',m[1]);
 return out;
}
function swJsDataRefs(text,base,source){
 const out=[],seen=new Set(),add=(kind,raw)=>{if(!raw)return;let v=String(raw).replace(/\\\//g,'/').replace(/&amp;/g,'&').trim();if(v.length>300||!/(?:api|inventory|vehicle|search|upull|u-pull|json|data)/i.test(v))return;try{const u=new URL(v,base);if(!/^https?:$/.test(u.protocol))return;const k=kind+'|'+u.href;if(seen.has(k))return;seen.add(k);out.push({kind,source,url:u.href})}catch{}};
 for(const m of text.matchAll(/\bfetch\s*\(\s*["'`]([^"'`]+)["'`]/g))add('fetch',m[1]);
 for(const m of text.matchAll(/\baxios\.(?:get|post|put|patch|delete)\s*\(\s*["'`]([^"'`]+)["'`]/g))add('axios',m[1]);
 for(const m of text.matchAll(/\b(?:url|endpoint|apiUrl|inventoryUrl)\s*[:=]\s*["'`]([^"'`]+)["'`]/gi))add('endpoint',m[1]);
 return out;
}
async function swDiscoverClientData(mainHtml,base){
 const resources=swRealResources(mainHtml,base),data=[],seen=new Set();
 // v9.9.43: do not automatically retrieve/analyze S&W JavaScript bundles or probe guessed data routes.
 // S&W's published Terms prohibit automated scraping tools without permission.
 // Keep page-level resource discovery only; connector integration resumes when S&W supplies
 // an authorized feed/API or permission is documented.
 return {resources:resources.slice(0,40),dataCandidates:[],probes:[],permissionRequired:true,
   note:'S&W page resource identified. Automated bundle/data scraping is disabled pending S&W permission or an authorized inventory feed/API.'};
}
async function fetchSwUPullDiagnostic(){
 const started=Date.now();
 Object.assign(swTelemetry,{version:BUILD_VERSION,status:'RUNNING',url:SW_OFFICIAL_PAGE,linkedInventoryUrl:'',httpStatus:null,linkedHttpStatus:null,htmlBytes:0,linkedHtmlBytes:0,tables:0,rowsScanned:0,validRows:0,withVin:0,withStock:0,withRow:0,withArrival:0,links:[],forms:[],scripts:[],candidates:[],linkedForms:[],clientDiscovery:[],responseMs:0,error:'',checkedAt:new Date().toISOString(),sample:[],provenance:'Official S&W U-Pull inventory search page'});
 try{
  const main=await swFetch(SW_OFFICIAL_PAGE); swTelemetry.httpStatus=main.r.status;swTelemetry.htmlBytes=main.html.length;swTelemetry.links=swExtractUrls(main.html,main.r.url).slice(0,80);swTelemetry.forms=swForms(main.html,main.r.url);swTelemetry.scripts=[...main.html.matchAll(/<script\b[^>]*src\s*=\s*["']([^"']+)/gi)].map(m=>{try{return new URL(m[1],main.r.url).href}catch{return m[1]}}).slice(0,50);swTelemetry.candidates=[...new Set([...swTelemetry.links,...swTelemetry.scripts])].filter(u=>u!==SW_LEGACY_FULL_SERVICE).slice(0,80);
  swTelemetry.clientDiscovery=await swDiscoverClientData(main.html,main.r.url);
  let rows=parseSwLinkedInventory(main.html,main.r.url);if(!rows.length)rows=rowsFromTable(main.html,'sw','S&W U Pull',main.r.url).map(x=>({...x,sourceLabel:'Official S&W U-Pull inventory',sourceTrust:'OFFICIAL',verifiedSource:true}));
  swTelemetry.tables=(main.html.match(/<table\b/gi)||[]).length;swTelemetry.rowsScanned=(main.html.match(/<tr\b/gi)||[]).length;
  // The rebuilt page may load inventory client-side. Probe only same-origin candidate resources discovered in its HTML.
  if(!rows.length){for(const u of swTelemetry.candidates.slice(0,30)){try{const q=new URL(u);if(q.hostname!=='www.sandwauto.com'&&q.hostname!=='sandwauto.com')continue;if(!/inventory|vehicle|search|api/i.test(q.href))continue;const sub=await swFetch(q.href,8000);if(!sub.r.ok)continue;let parsed=parseSwLinkedInventory(sub.html,sub.r.url);if(!parsed.length)parsed=rowsFromTable(sub.html,'sw','S&W U Pull',sub.r.url).map(x=>({...x,sourceLabel:'Official S&W U-Pull inventory',sourceTrust:'OFFICIAL',verifiedSource:true}));if(parsed.length){rows=parsed;swTelemetry.linkedInventoryUrl=sub.r.url;swTelemetry.linkedHttpStatus=sub.r.status;swTelemetry.linkedHtmlBytes=sub.html.length;swTelemetry.linkedForms=swForms(sub.html,sub.r.url);break}}catch{}}
  }
  rows=rows.map(x=>({...x,sourceUrl:x.sourceUrl||SW_OFFICIAL_PAGE,sourceType:'official-public-html',sourceLabel:'Official S&W U-Pull inventory',sourceTrust:'OFFICIAL',verifiedSource:true}));
  swTelemetry.validRows=rows.length;swTelemetry.withVin=rows.filter(x=>x.vin).length;swTelemetry.withStock=rows.filter(x=>x.stock).length;swTelemetry.withRow=rows.filter(x=>x.row).length;swTelemetry.withArrival=rows.filter(x=>x.arrival||x.arrivalDate).length;swTelemetry.sample=rows.slice(0,5);swTelemetry.status=rows.length?'LIVE':(main.r.ok?'OFFICIAL_PAGE_DISCOVERED':'SOURCE_DISCOVERED');swTelemetry.responseMs=Date.now()-started;swTelemetry.checkedAt=new Date().toISOString();return rows;
 }catch(e){Object.assign(swTelemetry,{status:'ERROR',error:e?.message||String(e),responseMs:Date.now()-started,checkedAt:new Date().toISOString()});return []}
}

async function fetchEzColumbusDiagnostic(){
 const started=Date.now(),pageUrl='https://ezpullnpay.com/columbus-location/';
 const out={yardId:'ez-pull-n-pay-columbus',yard:'EZ Pull N Pay Columbus',pageUrl,status:'UNKNOWN',httpStatus:0,bytes:0,tables:0,rows:0,parsedVehicles:0,candidates:[],plugin:{scripts:[],references:[],inventoryPage:null},elapsedMs:0};
 const addUnique=(arr,obj,key='url')=>{if(obj?.[key]&&!arr.some(x=>x[key]===obj[key]))arr.push(obj)};
 try{
  const r=await fetch(pageUrl,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2'},signal:AbortSignal.timeout(10000)}),html=await r.text();
  out.httpStatus=r.status;out.bytes=html.length;out.tables=(html.match(/<table\b/gi)||[]).length;out.rows=(html.match(/<tr\b/gi)||[]).length;
  const parsed=rowsFromTable(html,'ez-pull-n-pay-columbus','EZ Pull N Pay Columbus',pageUrl);out.parsedVehicles=parsed.length;
  const seen=new Set(),add=(kind,v)=>{if(!v)return;try{const u=new URL(String(v).replace(/&amp;/g,'&'),pageUrl).href;if(seen.has(u))return;seen.add(u);if(/inventory|autorecycler|ario|yard|vehicle|search/i.test(u))out.candidates.push({kind,url:u})}catch{}};
  for(const m of html.matchAll(/<(?:iframe|script)\b[^>]*\bsrc=["']([^"']+)["']/gi))add('embed/script',m[1]);
  for(const m of html.matchAll(/<a\b[^>]*\bhref=["']([^"']+)["']/gi))add('link',m[1]);
  for(const m of html.matchAll(/https?:\/\/[^"'<> \s]+/gi))add('page-url',m[0]);

  // Follow only resources explicitly linked by EZ Pull N Pay's official page.
  const scripts=out.candidates.filter(x=>x.kind==='embed/script'&&/i-pull-u-pull-inventory-search-system/i.test(x.url)).slice(0,8);
  out.plugin.scripts=scripts.map(x=>x.url);
  const refs=[],refSeen=new Set(),addRef=(kind,raw,source)=>{
   if(!raw)return;let v=String(raw).replace(/\\\//g,'/').replace(/&amp;/g,'&').trim();
   if(v.length>500||!/(?:ajax|wp-json|api|inventory|vehicle|yard|search|action)/i.test(v))return;
   try{const u=new URL(v,source||pageUrl).href,k=kind+'|'+u;if(refSeen.has(k))return;refSeen.add(k);refs.push({kind,url:u,source})}catch{}
  };
  for(const item of scripts){
   try{
    const jr=await fetch(item.url,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2'},signal:AbortSignal.timeout(10000)}),js=await jr.text();
    for(const m of js.matchAll(/\bfetch\s*\(\s*["'`]([^"'`]+)["'`]/g))addRef('fetch',m[1],item.url);
    for(const m of js.matchAll(/\b(?:url|ajaxurl|apiUrl|endpoint)\s*[:=]\s*["'`]([^"'`]+)["'`]/gi))addRef('endpoint',m[1],item.url);
    for(const m of js.matchAll(/["'`]([^"'`]*(?:admin-ajax\.php|wp-json|\/api\/|inventory|vehicle|yard)[^"'`]*)["'`]/gi))if(m[1].length<300)addRef('script-string',m[1],item.url);
    // WordPress AJAX action names are useful even when the URL is localized elsewhere.
    for(const m of js.matchAll(/\baction\s*[:=]\s*["'`]([A-Za-z0-9_-]+)["'`]/gi)){
      const key='action|'+m[1];if(!refSeen.has(key)){refSeen.add(key);refs.push({kind:'wp-action',value:m[1],source:item.url})}
    }
   }catch(e){addUnique(refs,{kind:'script-error',url:item.url,error:e?.message||String(e)})}
  }
  out.plugin.references=refs.slice(0,60);

  const inventoryLink=out.candidates.find(x=>/ezpullnpay\.com\/inventory-2-2\/?/i.test(x.url));
  if(inventoryLink){
   try{
    const ir=await fetch(inventoryLink.url,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2'},signal:AbortSignal.timeout(10000)}),ih=await ir.text();
    out.plugin.inventoryPage={url:inventoryLink.url,httpStatus:ir.status,bytes:ih.length,tables:(ih.match(/<table\b/gi)||[]).length,rows:(ih.match(/<tr\b/gi)||[]).length};
    for(const m of ih.matchAll(/<(?:iframe|script)\b[^>]*\bsrc=["']([^"']+)["']/gi))addRef('inventory-page-resource',m[1],inventoryLink.url);
    for(const m of ih.matchAll(/https?:\/\/[^"'<> \s]+/gi))if(/admin-ajax|wp-json|api|inventory|vehicle|yard/i.test(m[0]))addRef('inventory-page-url',m[0],inventoryLink.url);
    out.plugin.references=refs.slice(0,80);
    // v9.9.47: query only action names discovered from EZ Pull N Pay's own official plugin.
    // These calls retrieve integration metadata; they do not promote any inventory to official.
    const ajaxUrl='https://ezpullnpay.com/wp-admin/admin-ajax.php';
    out.plugin.ajax={url:ajaxUrl,actions:[]};
    const allowedActions=['sif_get_stores','sif_get_locations','sif_get_makes','sif_update_models'];
    const discoveredActions=new Set(refs.filter(x=>x.kind==='wp-action').map(x=>x.value));
    for(const action of allowedActions.filter(x=>discoveredActions.has(x))){
      const attempts=[];
      for(const body of [
        new URLSearchParams({action}),
        new URLSearchParams({action,store_id:'',location_id:'',make_id:''})
      ]){
        try{
          const ar=await fetch(ajaxUrl,{method:'POST',headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2','content-type':'application/x-www-form-urlencoded; charset=UTF-8','referer':inventoryLink?.url||pageUrl,'x-requested-with':'XMLHttpRequest'},body:body.toString(),signal:AbortSignal.timeout(10000)});
          const txt=await ar.text(), ct=ar.headers.get('content-type')||'';
          attempts.push({httpStatus:ar.status,contentType:ct,bytes:txt.length,preview:txt.slice(0,5000)});
          if(ar.ok && txt && txt!=='0' && txt!=='-1') break;
        }catch(e){attempts.push({error:e?.message||String(e)})}
      }
      out.plugin.ajax.actions.push({action,attempts});
    }
    out.plugin.ario={references:[],probes:[]};
    const arioSeen=new Set(), addArio=(kind,raw,source)=>{
      if(!raw)return;let v=String(raw).replace(/\\\//g,'/').replace(/&amp;/g,'&').trim();
      if(!/(?:autorecycler\.io|ario\.autorecycler\.io)/i.test(v))return;
      try{const u=new URL(v,source||pageUrl).href;if(arioSeen.has(u))return;arioSeen.add(u);out.plugin.ario.references.push({kind,url:u,source})}catch{}
    };
    for(const c of out.candidates||[])addArio(c.kind,c.url,pageUrl);
    for(const r of refs)addArio(r.kind,r.url||'',r.source||pageUrl);
    if(out.plugin.inventoryPage?.url){
      try{
        const rr=await fetch(out.plugin.inventoryPage.url,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2'},signal:AbortSignal.timeout(10000)}),txt=await rr.text();
        for(const m of txt.matchAll(/https?:\/\/[^"'<> \s]+/gi))addArio('inventory-page',m[0],out.plugin.inventoryPage.url);
        for(const m of txt.matchAll(/<(?:iframe|script)\b[^>]*\bsrc=["']([^"']+)["']/gi))addArio('inventory-resource',m[1],out.plugin.inventoryPage.url);
      }catch{}
    }
    // Probe only exact ARIO URLs discovered from EZ Pull N Pay's official pages/configuration.
    for(const ref of out.plugin.ario.references.slice(0,10)){
      try{
        const pr=await fetch(ref.url,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2','referer':out.plugin.inventoryPage?.url||pageUrl},redirect:'follow',signal:AbortSignal.timeout(10000)});
        const txt=await pr.text(), found=[];
        for(const m of txt.matchAll(/(?:ez[- ]?pull[- ]?n[- ]?pay[- /]?|yard[- /]?)[a-z0-9_-]*(?:columbus|atlanta|stockbridge|warner|robins)[a-z0-9_-]*/gi))if(!found.includes(m[0]))found.push(m[0]);
        for(const m of txt.matchAll(/https?:\/\/[^"'<> \s]+/gi))if(/autorecycler\.io|columbus/i.test(m[0])&&!found.includes(m[0]))found.push(m[0]);
        const locationContext=[];
        // Resolve how the verified Atlanta ARIO page supplies the location value.
        // We inspect only the exact ARIO page already discovered from EZ Pull N Pay.
        for(const m of txt.matchAll(/.{0,260}(?:init\/data\?location=|location(?:Slug|Name|Id|ID)?\s*[:=]|ez-pull-n-pay-atlanta).{0,420}/gi))
          if(!locationContext.includes(m[0])) locationContext.push(m[0]);
        const scriptContext=[{url:pr.url,httpStatus:pr.status,bytes:txt.length,hits:locationContext.slice(0,8)}];
        const initBase='https://app.autorecycler.io/api/1.1/init/data?location=';
        const verifiedPageUrl=pr.url;
        const initRefs=[initBase+encodeURIComponent(verifiedPageUrl)];
        const initData=[];
        for(const iu of initRefs){
          try{
            const ir=await fetch(iu,{headers:{'user-agent':'Mozilla/5.0 Scrappy/10.0.0-rc2','referer':verifiedPageUrl},signal:AbortSignal.timeout(7000)});
            const it=await ir.text();let parsed=null;try{parsed=JSON.parse(it)}catch{}
            const compact=parsed?JSON.stringify(parsed):it;
            const identity=[];
            for(const m of compact.matchAll(/.{0,90}(?:location|yard|store|slug|name|address|city|columbus|atlanta|inventory|api).{0,180}/gi))if(!identity.includes(m[0]))identity.push(m[0]);
            initData.push({url:iu,httpStatus:ir.status,contentType:ir.headers.get('content-type')||'',bytes:it.length,columbusMention:/columbus/i.test(it),atlantaMention:/atlanta/i.test(it),identity:identity.slice(0,30),preview:it.slice(0,10000)});
          }catch(e){initData.push({url:iu,error:e?.message||String(e)})}
        }
        out.plugin.ario.probes.push({url:ref.url,httpStatus:pr.status,finalUrl:pr.url,contentType:pr.headers.get('content-type')||'',bytes:txt.length,columbusMention:/columbus/i.test(txt),identifiers:found.slice(0,30),locationContext:locationContext.slice(0,20),scriptContext,initRefs,initData});
      }catch(e){out.plugin.ario.probes.push({url:ref.url,error:e?.message||String(e)})}
    }


   }catch(e){out.plugin.inventoryPage={url:inventoryLink.url,error:e?.message||String(e)}}
  }
  out.status=parsed.length?'OFFICIAL_LIVE':'PLUGIN_DISCOVERED';
 }catch(e){out.status='ERROR';out.error=e?.message||String(e)}
 out.elapsedMs=Date.now()-started;return out;
}
async function fetchInventory(filters={}){
 const jobs=[
  ['Cagle\'s U Pull It',()=>fetchText('https://caglesupullit.com/inventory.aspx').then(h=>rowsFromTable(h,'cagles',"Cagle's U Pull It",'https://caglesupullit.com/inventory.aspx'))],
  ['S&W U Pull',()=>fetchSwUPullDiagnostic()],
  ['EZ Pull N Pay Atlanta',()=>fetchText('https://ezpullnpay.com/atlanta/').then(h=>rowsFromTable(h,'ez-pull-n-pay-atlanta','EZ Pull N Pay Atlanta','https://ezpullnpay.com/atlanta/'))],
  ['EZ Pull N Pay Stockbridge',()=>fetchText('https://ezpullnpay.com/stockbridge/').then(h=>rowsFromTable(h,'ez-pull-n-pay-stockbridge','EZ Pull N Pay Stockbridge','https://ezpullnpay.com/stockbridge/'))],
  ['EZ Pull N Pay Warner Robins',()=>fetchText('https://ezpullnpay.com/warner-robins/').then(h=>rowsFromTable(h,'ez-pull-n-pay-warner','EZ Pull N Pay Warner Robins','https://ezpullnpay.com/warner-robins/'))],
  ['EZ Pull N Pay Columbus',()=>fetchText('https://ezpullnpay.com/columbus-location/').then(h=>rowsFromTable(h,'ez-pull-n-pay-columbus','EZ Pull N Pay Columbus','https://ezpullnpay.com/columbus-location/'))],
  ['Pick Your Part Fayetteville',()=>fetchPypYard('pyp-fayetteville','Pick Your Part Fayetteville','https://www.pyp.com/inventory/fayetteville-1229/',75)],
  ['Pick Your Part Savannah',()=>fetchPypYard('pyp-savannah','Pick Your Part Savannah','https://www.pyp.com/inventory/savannah-1163/',75)],
  ['Fenix Moultrie',()=>fetchFenixMoultrie()],
  ['Highway 82',()=>fetchHighway82()],
  ['Cash N Carry',()=>fetchCashNCarry()],
  ['Pick-N-Pull Jefferson',()=>fetchPickNPullJefferson()]
 ];
 if(filters.make&&filters.model){
  jobs.push(['Pick-N-Pull Jefferson Row52 search',()=>fetchRow52JeffersonSearch(filters.make,filters.model,filters.year)]);
  jobs.push(['Pull-A-Part Georgia',()=>fetchPullApartSearch(filters.make,filters.model)]);
  jobs.push(['GO Pull-It Atlanta East',()=>fetchGoSearch('go-pull-it-norcross','GO Pull-It Atlanta East',filters.make,filters.model)]);
  jobs.push(['GO Pull-It Gainesville',()=>fetchGoSearch('go-pull-it-gainesville','GO Pull-It Gainesville',filters.make,filters.model)]);
 }
 const groups=await Promise.all(jobs.map(([label,fn])=>safeRows(label,fn,15000)));
 const all=groups.flat();
 // Columbus fallback is independent and must never hold up the main response.
 if(!all.some(v=>v.yardId==='ez-pull-n-pay-columbus')){
  const fallback=await safeRows('EZ Pull N Pay Columbus fallback',async()=>{
   const html=await fetchText('https://yardhound.app/?yard_id=178',8000),text=strip(html),y=YARDS.find(x=>x.id==='ez-pull-n-pay-columbus'),rows=[];
   const re=/(19\d{2}|20\d{2})\s+([A-Z][A-Z0-9&.'-]+)\s+([A-Z0-9][A-Z0-9&.' /-]{1,55}?)\s+EZ Pull N Pay Columbus\b/gi; let m;
   while((m=re.exec(text))) rows.push({yardId:y.id,yard:y.name,year:Number(m[1]),make:m[2],model:strip(m[3]),submodel:'',row:'',vin:'',stock:'',arrival:'',arrivalDate:null,sourceUrl:'https://yardhound.app/?yard_id=178',diy:true,live:false,isNew:false,sourceType:'public-index-fallback'});
   return dedupeInventory(rows);
  },9000); all.push(...fallback);
 }
 return enrichInventorySources(dedupeInventory(all));
}


function sourceTrustFor(type){
 if(type==='official-api'||type==='official-public-html') return 'OFFICIAL';
 if(type==='public-index-fallback') return 'FALLBACK';
 if(type==='public-index') return 'PUBLIC INDEX';
 return 'MANUAL';
}
function sourceLabelFor(type){return SOURCE_LABELS[type]||type||'Unknown source'}
function enrichInventorySources(rows){
 return rows.map(v=>({...v,sourceLabel:sourceLabelFor(v.sourceType),sourceTrust:sourceTrustFor(v.sourceType),verifiedSource:sourceTrustFor(v.sourceType)==='OFFICIAL'}));
}

const SOURCE_LABELS={
 'official-api':'Official API',
 'official-public-html':'Official public inventory',
 'public-index':'Public inventory index',
 'public-index-fallback':'Third-party fallback'
};
const YARD_SOURCE_HINTS={
 'pull-apart-atl-east':'Search-driven official Pull-A-Part inventory',
 'pull-apart-atl-north':'Search-driven official Pull-A-Part inventory',
 'pull-apart-atl-south':'Search-driven official Pull-A-Part inventory',
 'pull-apart-augusta':'Search-driven official Pull-A-Part inventory',
 'go-pull-it-norcross':'Search-driven official inventory',
 'go-pull-it-gainesville':'Search-driven official inventory',
 'ez-pull-n-pay-columbus':'Official page + public fallback',
 'pick-n-pull-jefferson':'Yard index + Row52 targeted vehicle search + official VIN verification',
 'fenix-moultrie':'Official public inventory',
 'highway82':'Official public inventory',
 'cash-n-carry':'Official public inventory',
 'pyp-fayetteville':'Official site protected (Cloudflare)',
 'pyp-savannah':'Official site protected (Cloudflare)',
 'southern-pik-a-part-augusta':'Direct link only',
 'southern-pik-a-part-columbus':'Direct link only'
};
function vehicleSignature(v){
 const vin=String(v.vin||'').replace(/[^A-Z0-9]/gi,'').toUpperCase();
 if(vin.length>=11) return 'VIN:'+vin;
 return ['REC',v.year,canonicalMake(v.make),canonicalModel(v.model),canonicalSubmodel(v.submodel),String(v.row||'').trim(),String(v.stock||'').trim(),String(v.arrival||'').trim()].join('|');
}
function pct(n,d){return d?Math.round((n/d)*100):0}
// v9.7.1: judge connector completeness against fields the first-party source actually publishes.
// Missing VIN is not a defect for sources that do not expose VINs publicly.
const CONNECTOR_EXPECTATIONS={
 'fenix-moultrie':{vin:90,row:90,arrival:90},
 'highway82':{row:90,arrival:90},
 'cash-n-carry':{row:90,arrival:90},
 'cagles':{row:90,arrival:90},
 'ez-pull-n-pay-atlanta':{row:90,arrival:90},
 'ez-pull-n-pay-stockbridge':{row:90,arrival:90},
 'ez-pull-n-pay-warner':{row:90,arrival:90}
};
function buildConnectorStatuses(inventory, responseMs=0, globalError=''){
 const checkedAt=new Date().toISOString();
 const grouped=new Map(YARDS.map(y=>[y.id,[]]));
 for(const v of inventory||[]){if(grouped.has(v.yardId))grouped.get(v.yardId).push(v)}
 const sigSets=new Map();
 for(const [id,rows] of grouped) sigSets.set(id,new Set(rows.map(vehicleSignature)));
 const overlaps=new Map();
 const ids=[...sigSets.keys()];
 for(let i=0;i<ids.length;i++) for(let j=i+1;j<ids.length;j++){
   const a=ids[i],b=ids[j],sa=sigSets.get(a),sb=sigSets.get(b); if(sa.size<5||sb.size<5) continue;
   let common=0; for(const x of sa) if(sb.has(x)) common++;
   const ratio=common/Math.min(sa.size,sb.size);
   if(common>=5 && ratio>=0.75){
     if(!overlaps.has(a)) overlaps.set(a,[]); if(!overlaps.has(b)) overlaps.set(b,[]);
     overlaps.get(a).push({yardId:b,common,ratio}); overlaps.get(b).push({yardId:a,common,ratio});
   }
 }
 return YARDS.map(y=>{
   const rows=grouped.get(y.id)||[], vehicleCount=rows.length;
   let status='UNTESTED',lastError='';
   if(globalError){status='CONNECTION_ERROR';lastError=globalError}
   else if(vehicleCount>0 && rows.every(r=>r.sourceTrust==='FALLBACK'||r.sourceType==='public-index-fallback'))status='FALLBACK_REVIEW';
   else if(vehicleCount>0)status='LIVE';
   else if(y.id.startsWith('go-pull-it-')||y.id.startsWith('pull-apart-'))status='SEARCH_DRIVEN';
   else if(y.id.startsWith('pyp-') && /(?:403|cloudflare)/i.test(String((pypConnectorTelemetry.get(y.id)||{}).lastHttpError||''))) status='BLOCKED';
   else if(y.status==='unknown')status='DIRECT_LINK_ONLY';
   else status='EMPTY';
   const types=[...new Set(rows.map(r=>r.sourceType).filter(Boolean))];
   let sourceType=types.map(t=>SOURCE_LABELS[t]||t).join(' + ') || YARD_SOURCE_HINTS[y.id] || (y.status==='live'?'Configured public connector':'Verified public inventory');
   const warnings=[];
   if(types.includes('public-index-fallback')) warnings.push('Using third-party fallback source');
   if(vehicleCount>0 && vehicleCount<=3) warnings.push('Low record count — verify parser coverage');
   const dup=overlaps.get(y.id)||[];
   if(dup.length){
     const names=dup.map(d=>(YARDS.find(z=>z.id===d.yardId)||{}).name).filter(Boolean);
     warnings.push('Possible duplicate feed overlap with '+names.join(', '));
   }
   if(status==='BLOCKED') warnings.push('Official inventory page is protected from server-side access; use the official yard link');
   if(status==='EMPTY'&&y.status==='live') warnings.push('Configured connector returned zero parsed vehicles');
   if(status==='EMPTY'&&y.status==='verified') warnings.push('Public inventory verified; parser/source needs validation');
   const vinCount=rows.filter(r=>String(r.vin||'').replace(/[^A-Z0-9]/gi,'').length>=11).length;
   const rowCount=rows.filter(r=>String(r.row||'').trim()).length;
   const arrivalCount=rows.filter(r=>String(r.arrival||'').trim()).length;
   const fallback=types.includes('public-index-fallback');
   const coverage={vin:pct(vinCount,vehicleCount),row:pct(rowCount,vehicleCount),arrival:pct(arrivalCount,vehicleCount)};
   const expected=CONNECTOR_EXPECTATIONS[y.id]||{};
   for(const [field,minimum] of Object.entries(expected)){
     if(vehicleCount>0 && coverage[field]<minimum) warnings.push(`${field.toUpperCase()} coverage ${coverage[field]}% is below expected ${minimum}%`);
   }
   let quality='GOOD';
   if(status==='LIVE' && (fallback||warnings.length)) quality='REVIEW';
   if(status==='FALLBACK_REVIEW') quality='REVIEW';
   if(status==='EMPTY'||status==='CONNECTION_ERROR'||status==='PARSER_ERROR') quality='NEEDS ATTENTION';
   if(status==='BLOCKED') quality='PROTECTED';
   if(status==='DIRECT_LINK_ONLY') quality='MANUAL';
   if(status==='SEARCH_DRIVEN') quality='ON DEMAND';
   const searchTelemetry=searchConnectorTelemetry.get(y.id)||null;
   const pypTelemetry=pypConnectorTelemetry.get(y.id)||null;
   const pnpTelemetry=y.id==='pick-n-pull-jefferson'?(pnpJeffersonTelemetry.get('pick-n-pull-jefferson')||null):null;
   if(pnpTelemetry?.reportedTotal && pnpTelemetry.reportedTotal>vehicleCount){
     warnings.push(`Source reports ${Number(pnpTelemetry.reportedTotal).toLocaleString()} vehicles; only ${vehicleCount.toLocaleString()} row records are server-retrievable. Do not treat the parsed row count as full Jefferson inventory.`);
     sourceType=`Public inventory index — ${Number(pnpTelemetry.reportedTotal).toLocaleString()} reported / ${vehicleCount.toLocaleString()} searchable rows`;
   }
   if(searchTelemetry?.error) warnings.push('Last on-demand query failed: '+searchTelemetry.error);
   if(pypTelemetry?.lastHttpError) warnings.push('PYP request failed: '+pypTelemetry.lastHttpError);
   if(pypTelemetry?.parserNote) warnings.push(pypTelemetry.parserNote);
   const yardResponseMs=pypTelemetry?.responseMs ?? responseMs;
   return {...y,status,vehicleCount,responseMs:yardResponseMs,lastAttempt:checkedAt,lastSuccess:vehicleCount>0?checkedAt:null,lastError,sourceType,
     quality,warnings,vinCoverage:coverage.vin,rowCoverage:coverage.row,arrivalCoverage:coverage.arrival,expectedCoverage:expected,
     possibleDuplicate:dup.length>0,sourceTypes:types,trustLevel:(types.includes('official-api')||types.includes('official-public-html'))?'OFFICIAL':types.includes('public-index-fallback')?'FALLBACK':types.includes('public-index')?'PUBLIC INDEX':'MANUAL',searchTelemetry,pypTelemetry,pnpTelemetry,reportedVehicleCount:pnpTelemetry?.reportedTotal||null};
 });
}
async function getConnectorStatuses(){
 const started=Date.now(); let inventory=[],globalError='';
 try{
   if(cache.data && Date.now()-cache.at<10*60*1000) inventory=cache.data.inventory||[];
   else {inventory=await fetchInventory({}); cache={at:Date.now(),data:{generatedAt:new Date().toISOString(),inventory,yards:YARDS}}}
 }catch(e){globalError=e&&e.message?e.message:String(e)}
 return buildConnectorStatuses(inventory,Date.now()-started,globalError);
}

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
function statewideCoverageSummary(inventory, filters={}){
 const contributing=[...new Set((inventory||[]).map(v=>v.yardId).filter(Boolean))];
 const searchDriven=YARDS.filter(y=>y.id.startsWith('pull-apart-')||y.id.startsWith('go-pull-it-')).map(y=>y.id);
 const protectedYards=['pyp-fayetteville','pyp-savannah'];
 const directLinkOnly=['southern-pik-a-part-augusta','southern-pik-a-part-columbus'];
 const queriedOnDemand=!!(filters.make&&filters.model);
 return {
  configuredYards:YARDS.length,
  contributingYards:contributing.length,
  contributingYardIds:contributing,
  fullInventoryVehicleCount:(inventory||[]).length,
  searchDrivenYards:searchDriven.length,
  searchDrivenYardIds:searchDriven,
  searchDrivenRequirement:'Make and Model',
  onDemandQueried:queriedOnDemand,
  protectedYards:protectedYards.length,
  protectedYardIds:protectedYards,
  directLinkOnlyYards:directLinkOnly.length,
  directLinkOnlyYardIds:directLinkOnly,
  completeStatewideEnumeration:false,
  explanation:queriedOnDemand
   ? 'All inventory-enumerable sources are loaded and all six search-driven connectors were queried for the supplied Make and Model. Protected/direct-link yards may still be unavailable to Scrappy.'
   : 'The vehicle total is the inventory Scrappy can enumerate without a vehicle query. Six search-driven yards require both Make and Model and therefore are not represented in a blank statewide total; protected/direct-link yards may also be unavailable.'
 };
}



// v9.8.1 — official Pull-A-Part interchange service integration.
// Uses only the same public JSON service called by Pull-A-Part's browser UI.
const PAP_IX_BASE='https://inventoryservice.pullapart.com';
function ixNorm(v){return String(v??'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim()}
function ixArray(v){if(Array.isArray(v))return v;if(v&&Array.isArray(v.data))return v.data;if(v&&Array.isArray(v.results))return v.results;if(v&&Array.isArray(v.items))return v.items;return []}
function ixVal(o,keys){for(const k of keys){if(o&&o[k]!==undefined&&o[k]!==null&&String(o[k]).trim()!=='')return o[k]}return null}
function ixLabel(o){return String(ixVal(o,['style','styleName','vehicleStyle','description','Description','name','Name','makeName','modelName','modelYear','year','categoryName','partTypeCategoryName','pTypeCategoryName','partTypeName','partName','text','label','application','trimmedApplication'])||'').trim()}
function ixId(o,keys=[]){return ixVal(o,[...keys,'id','ID','makeID','modelID','vehicleDataSetID','pTypeCategoryID','partTypeCategoryID','partTypeId','partTypeID','partType'])}
const interchangeDiagnostics={lastRun:null,requests:[]};
function ixPreview(text){return String(text||'').replace(/\s+/g,' ').trim().slice(0,500)}
async function papIxGet(path){
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),8000),url=PAP_IX_BASE+path,started=Date.now();
 const parsedRequestUrl=new URL(url);
 const requestVerification={requestedPath:path,requestUrl:url,requestQuery:Object.fromEntries(parsedRequestUrl.searchParams.entries())};
 try{
  const r=await fetch(url,{headers:{accept:'application/json, text/plain, */*','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/10.0.0-rc2','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/inventory/interchangeable-parts/'},redirect:'follow',signal:ctrl.signal});
  const text=await r.text();const meta={...requestVerification,path,url,status:r.status,ok:r.ok,contentType:r.headers.get('content-type')||'',finalUrl:r.url,finalQuery:Object.fromEntries(new URL(r.url).searchParams.entries()),responseMs:Date.now()-started,bytes:Buffer.byteLength(text||'','utf8'),preview:ixPreview(text)};
  let json;try{json=JSON.parse(text.replace(/^\uFEFF/,''))}catch{meta.parseError='non-JSON response';interchangeDiagnostics.requests.push(meta);throw Object.assign(Error(`Pull-A-Part interchange returned non-JSON data (${r.status} ${meta.contentType||'unknown content type'})`),{ixDiagnostic:meta})}
  meta.jsonType=Array.isArray(json)?'array':typeof json;meta.itemCount=Array.isArray(json)?json.length:undefined;interchangeDiagnostics.requests.push(meta);
  if(!r.ok)throw Object.assign(Error(`Pull-A-Part interchange HTTP ${r.status}`),{ixDiagnostic:meta});return json
 }catch(e){if(!e?.ixDiagnostic)interchangeDiagnostics.requests.push({path,url,status:null,ok:false,responseMs:Date.now()-started,error:e?.message||String(e)});throw e}finally{clearTimeout(timer)}
}
function ixPick(rows,wanted,idKeys=[]){const w=ixNorm(wanted);return rows.find(x=>ixNorm(ixLabel(x))===w)||rows.find(x=>ixNorm(ixLabel(x)).includes(w)||w.includes(ixNorm(ixLabel(x))))||null}
function ixChoices(rows,idKeys=[]){return rows.map(x=>({id:ixId(x,idKeys),label:ixLabel(x),raw:x})).filter(x=>x.label).slice(0,250)}
const IX_KNOWN_MAKES=['MERCEDES-BENZ','LAND ROVER','ALFA ROMEO','ASTON MARTIN','ROLLS-ROYCE','VOLKSWAGEN','MITSUBISHI','OLDSMOBILE','CHEVROLET','CHRYSLER','CADILLAC','INFINITI','HYUNDAI','LINCOLN','MERCURY','PONTIAC','PORSCHE','SUBARU','SUZUKI','TOYOTA','VOLVO','ACURA','AUDI','BMW','BUICK','DODGE','FIAT','FORD','GENESIS','GMC','HONDA','JAGUAR','JEEP','KIA','LEXUS','MAZDA','MINI','NISSAN','RAM','SAAB','SATURN','SCION','TESLA'];
function parseApplicationYmm(text){
 // v9.9.19: preserve every donor year explicitly stated by Pull-A-Part.
 // Supports a single year (17 / 2017) and explicit ranges (16-18 / 2016-2018).
 // The selected repair year is never used as a donor-year filter.
 const raw=String(text||'').trim(), out=[]; if(!raw)return out;
 const upper=raw.toUpperCase(); const make=[...IX_KNOWN_MAKES].sort((a,b)=>b.length-a.length).find(m=>upper===m||upper.startsWith(m+' ')); if(!make)return out;
 const rest=raw.slice(make.length).trim();
 const m=rest.match(/^(.+?)\s+(19\d{2}|20\d{2}|\d{2})(?:\s*[-–—]\s*(19\d{2}|20\d{2}|\d{2}))?(?=\s|\(|,|$)(.*)$/); if(!m)return out;
 const model=m[1].trim(); if(!model)return out;
 const expand=y=>{y=String(y);if(y.length===2){const n=Number(y);return n<=30?2000+n:1900+n}return Number(y)};
 const y1=expand(m[2]), y2=m[3]?expand(m[3]):y1; if(y1<1900||y1>2100||y2<1900||y2>2100||y2<y1||y2-y1>30)return out;
 const fitment=(m[4]||'').replace(/^\s*[,;-]?\s*/,'').trim();
 for(let y=y1;y<=y2;y++)out.push({year:String(y),make,model,application:raw,fitment,explicitYearRange:y2>y1?`${y1}-${y2}`:''});
 return out
}
async function resolveOfficialModels(q){
 interchangeDiagnostics.lastRun=new Date().toISOString(); interchangeDiagnostics.requests=[];
 const make=String(q.make||'').trim(); if(!make)return {ok:false,stage:'INPUT',error:'make is required'};
 const makes=ixArray(await papIxGet('/Make/')); const makeRow=ixPick(makes,make,['makeID']);
 if(!makeRow)return {ok:false,stage:'MAKE',choices:ixChoices(makes,['makeID'])};
 const makeID=Number(ixId(makeRow,['makeID']));
 // Official Pull-A-Part model catalog. This supplies labels for the Repair Vehicle Model dropdown.
 const models=ixArray(await papIxGet('/Model?makeID='+makeID));
 const choices=ixChoices(models,['modelID']).filter(x=>Number(x.id)>0).sort((a,b)=>String(a.label).localeCompare(String(b.label),undefined,{sensitivity:'base'}));
 return {ok:true,stage:'MODEL',makeID,choices};
}
async function resolveOfficialCategories(q){
 interchangeDiagnostics.lastRun=new Date().toISOString(); interchangeDiagnostics.requests=[];
 const vehicleDataSetID=Number(q.vehicleDataSetID||0); if(!vehicleDataSetID)return {ok:false,stage:'INPUT',error:'vehicleDataSetID is required'};
 const rows=ixArray(await papIxGet('/PTypeCategory/Interchangeable?vehicleDataSetID='+vehicleDataSetID));
 return {ok:true,stage:'CATEGORY',vehicleDataSetID,choices:ixChoices(rows,['pTypeCategoryID','partTypeCategoryID']).filter(x=>Number(x.id)>0)};
}
async function resolveOfficialParts(q){
 interchangeDiagnostics.lastRun=new Date().toISOString(); interchangeDiagnostics.requests=[];
 const vehicleDataSetID=Number(q.vehicleDataSetID||0),pTypeCategoryID=Number(q.pTypeCategoryID||0);
 if(!vehicleDataSetID||!pTypeCategoryID)return {ok:false,stage:'INPUT',error:'vehicleDataSetID and pTypeCategoryID are required'};
 const upstreamPath='/PType/Interchangeable?vehicleDataSetID='+encodeURIComponent(vehicleDataSetID)+'&pTypeCategoryID='+encodeURIComponent(pTypeCategoryID);
 const raw=await papIxGet(upstreamPath);
 const upstreamRequest=interchangeDiagnostics.requests.at(-1)||null;
 // v9.9.8: Pull-A-Part's PART response is { partType, description, ... }.
 // Normalize common array wrappers, then map only the documented official fields.
 let rows=ixArray(raw);
 if(!rows.length && raw && typeof raw==='object'){
  for(const key of ['value','Values','choices','Choices','partTypes','PartTypes']){
   if(Array.isArray(raw[key])){rows=raw[key];break}
  }
 }
 // v9.9.9: direct PART mapping. Do not run PART rows through the generic category parser.
 // Pull-A-Part documents these rows as { partType, description, ... }. Key matching is
 // case-insensitive only to tolerate serializer casing; no compatibility values are inferred.
 const choices=[];
 for(const row of rows){
  if(!row || typeof row!=='object' || Array.isArray(row))continue;
  const keys=Object.keys(row), partKey=keys.find(k=>String(k).toLowerCase()==='parttype'), descKey=keys.find(k=>String(k).toLowerCase()==='description');
  const id=Number(partKey?row[partKey]:NaN), label=String(descKey?row[descKey]:'').trim();
  if(Number.isFinite(id)&&id>0&&label)choices.push({id,label});
 }
 choices.sort((a,b)=>String(a.label).localeCompare(String(b.label),undefined,{sensitivity:'base'}));
 const rawPreview=rows.slice(0,3).map(row=>row&&typeof row==='object'?Object.fromEntries(Object.entries(row).slice(0,8)):row);
 const wrongStage=rows.length>0 && choices.length===0 && rows.some(row=>row&&typeof row==='object'&&('pTypeCategoryID' in row||'pTypeCategoryName' in row));
 if(wrongStage)return {ok:false,stage:'PART',error:'WRONG_RESPONSE_STAGE',vehicleDataSetID,pTypeCategoryID,upstreamPath,upstreamRequest,choices:[],receivedRows:rows.length,rawPreview};
 return {ok:true,stage:'PART',vehicleDataSetID,pTypeCategoryID,upstreamPath,upstreamRequest,choices,receivedRows:rows.length,rawPreview};
}
async function resolveOfficialStyles(q){
 interchangeDiagnostics.lastRun=new Date().toISOString(); interchangeDiagnostics.requests=[];
 const make=String(q.make||'').trim(),model=String(q.model||'').trim(),year=String(q.year||'').trim();
 if(!make||!model||!/^\d{4}$/.test(year)) return {ok:false,stage:'INPUT',error:'make, model and a 4-digit year are required'};
 const makes=ixArray(await papIxGet('/Make/')); const makeRow=ixPick(makes,make,['makeID']); if(!makeRow)return {ok:false,stage:'MAKE',choices:ixChoices(makes,['makeID'])}; const makeID=Number(ixId(makeRow,['makeID']));
 // v9.9.11: preserve the official modelID selected from /Model?makeID=... .
 // Pull-A-Part's own 2017 XC60 browser request uses modelID=1791; the old
 // hard-coded 1453 mapping produced the wrong vehicleDataSetIDs (58161/58162).
 let modelID=Number(q.modelID||0);
 if(!modelID){
  const models=ixArray(await papIxGet('/Model?makeID='+makeID));
  const modelRow=ixPick(models,model,['modelID']);
  modelID=Number(ixId(modelRow,['modelID'])||0);
 }
 if(!modelID)return {ok:false,stage:'MODEL_ID',makeID,error:'Official model ID could not be resolved for this make/model. Scrappy will not guess compatibility.'};
 const stylesRaw=await papIxGet('/VehicleDataSet/Interchangeable?makeID='+makeID+'&modelID='+modelID+'&modelYear='+encodeURIComponent(year)); const styles=ixArray(stylesRaw);
 const choices=ixChoices(styles,['vehicleDataSetID']).filter(x=>Number(x.id)>0);
 if(!choices.length)return {ok:false,stage:'STYLE',makeID,modelID,error:'No selectable official styles were returned for that year/model.'};
 return {ok:true,stage:'STYLE',makeID,modelID,choices};
}
async function resolveOfficialInterchange(q){
 interchangeDiagnostics.lastRun=new Date().toISOString(); interchangeDiagnostics.requests=[];
 const make=String(q.make||'').trim(),model=String(q.model||'').trim(),year=String(q.year||'').trim(),category=String(q.category||'').trim(),part=String(q.part||'').trim();
 if(!make||!model||!year||!category||!part) return {ok:false,stage:'INPUT',error:'make, model, year, category and part are required'};
 const makes=ixArray(await papIxGet('/Make/')); const makeRow=ixPick(makes,make,['makeID']); if(!makeRow)return {ok:false,stage:'MAKE',choices:ixChoices(makes,['makeID'])}; const makeID=Number(ixId(makeRow,['makeID']));
 // v9.9.2: VehicleDataSet/Interchangeable requires makeID + modelID + modelYear
 // in the same request. Never call it with partial parameters. The interchange model ID
 // is NOT the normal inventory /Model ID. Use only IDs captured from Pull-A-Part's own
 // successful interchange request; otherwise stop instead of guessing compatibility.
 let modelID=Number(q.modelID||0);
 if(!modelID){
  const models=ixArray(await papIxGet('/Model?makeID='+makeID));
  const modelRow=ixPick(models,model,['modelID']);
  modelID=Number(ixId(modelRow,['modelID'])||0);
 }
 if(!modelID)return {ok:false,stage:'MODEL_ID',makeID,error:'Official model ID could not be resolved for this make/model. No compatibility guess was made.'};
 const stylesRaw=await papIxGet('/VehicleDataSet/Interchangeable?makeID='+makeID+'&modelID='+modelID+'&modelYear='+encodeURIComponent(year)); const styles=ixArray(stylesRaw);
 if(!styles.length)return {ok:false,stage:'STYLE',makeID,modelID,error:'No official interchange vehicle dataset returned for that year/model.'};
 // If multiple styles exist, return them instead of guessing. One style can proceed automatically.
 if(styles.length>1 && !q.vehicleDataSetID)return {ok:false,needsSelection:true,stage:'STYLE',makeID,modelID,choices:ixChoices(styles,['vehicleDataSetID'])};
 const style=q.vehicleDataSetID?styles.find(x=>String(ixId(x,['vehicleDataSetID']))===String(q.vehicleDataSetID)):styles[0]; const vehicleDataSetID=Number(ixId(style,['vehicleDataSetID']));
 if(!vehicleDataSetID)return {ok:false,stage:'STYLE',error:'Official response did not include vehicleDataSetID.',raw:stylesRaw};
 const catsRaw=await papIxGet('/PTypeCategory/Interchangeable?vehicleDataSetID='+vehicleDataSetID); const cats=ixArray(catsRaw); const cat=ixPick(cats,category,['pTypeCategoryID','partTypeCategoryID']); if(!cat)return {ok:false,needsSelection:true,stage:'CATEGORY',makeID,modelID,vehicleDataSetID,choices:ixChoices(cats,['pTypeCategoryID','partTypeCategoryID'])}; const pTypeCategoryID=Number(ixId(cat,['pTypeCategoryID','partTypeCategoryID']));
 const partsRaw=await papIxGet('/PType/Interchangeable?vehicleDataSetID='+vehicleDataSetID+'&pTypeCategoryID='+pTypeCategoryID); const parts=ixArray(partsRaw); const partRow=ixPick(parts,part,['partTypeId','partTypeID','partType']); if(!partRow)return {ok:false,needsSelection:true,stage:'PART',makeID,modelID,vehicleDataSetID,pTypeCategoryID,choices:ixChoices(parts,['partTypeId','partTypeID','partType'])}; const partType=Number(ixId(partRow,['partTypeId','partTypeID','partType']));
 const activeRaw=await papIxGet('/InterchangeLookup/Active?partType='+partType+'&vehicleDataSetID='+vehicleDataSetID); const active=ixArray(activeRaw); const verified=active.filter(r=>Number(r.interchangeLookupID||0)>0 && r.interchangeNumber && String(r.interchangeNumber).toUpperCase()!=='IDK');
 const donors=[]; for(const r of verified){for(const d of parseApplicationYmm(r.application||r.trimmedApplication)){const key=x=>x.year+'|'+ixNorm(x.make)+'|'+ixNorm(x.model);let donor=donors.find(x=>key(x)===key(d));const fitment=String(r.trimmedApplication||d.fitment||'').trim();const evidence={interchangeLookupID:r.interchangeLookupID,interchangeNumber:r.interchangeNumber,application:r.application||'',fitment,isExact:!!r.isExact};if(!donor){donor={year:d.year,make:d.make,model:d.model,fitmentRequirements:[],interchangeNumbers:[],evidence:[]};donors.push(donor)}if(fitment&&!donor.fitmentRequirements.includes(fitment))donor.fitmentRequirements.push(fitment);if(r.interchangeNumber&&!donor.interchangeNumbers.includes(r.interchangeNumber))donor.interchangeNumbers.push(r.interchangeNumber);donor.evidence.push(evidence)}}
 return {ok:true,stage:'ACTIVE',source:'official-api',sourceLabel:'Pull-A-Part official InterchangeLookup API',makeID,modelID,vehicleDataSetID,pTypeCategoryID,partType,style:ixLabel(style),category:ixLabel(cat),part:ixLabel(partRow),records:verified,recordCount:verified.length,donors,donorCount:donors.length,note:donors.length?'Donor candidates were parsed from explicit Pull-A-Part application text. Fitment requirements are preserved and must be verified against the donor vehicle before purchase.':'Official interchange records were returned, but no explicit year/make/model donor strings were present; Scrappy will not guess compatibility.'};
}


const SITE_TEST_TIMEOUT_MS=20000;
function diagnosticQuality(rows){const vinOK=v=>/^[A-HJ-NPR-Z0-9]{17}$/i.test(String(v||''));const key=x=>[x.yardId||x.yard||'',x.vin||'',x.stock||'',x.year||'',x.make||'',x.model||'',x.row||''].join('|').toUpperCase();const keys=rows.map(key);return {duplicateKeys:keys.length-new Set(keys).size,validVIN:rows.filter(x=>vinOK(x.vin)).length,withStock:rows.filter(x=>x.stock).length,withRow:rows.filter(x=>x.row).length,withArrival:rows.filter(x=>x.arrival||x.arrivalDate).length}}
async function runSiteDiagnostic(){
 const started=Date.now(),tests=[],add=(name,status,detail='',responseMs=0)=>tests.push({name,status,ok:status==='PASS',detail,responseMs});
 add('Build version',BUILD_VERSION==='10.0.0-rc5'?'PASS':'ATTENTION',BUILD_VERSION);add('Configured Georgia yards',YARDS.length===20?'PASS':'ATTENTION',`${YARDS.length}/20 configured`);add('Unique yard IDs',new Set(YARDS.map(y=>y.id)).size===YARDS.length?'PASS':'ATTENTION',`${new Set(YARDS.map(y=>y.id)).size}/${YARDS.length} unique`);
 for(const f of ['index.html','app.js','styles.css'])add(`Static asset: ${f}`,fs.existsSync(path.join(ROOT,f))?'PASS':'ATTENTION',f);
 let rows=[];
 try{const t=Date.now(),inv=await Promise.race([fetchInventory({}),new Promise((_,reject)=>setTimeout(()=>reject(new Error('20-second inventory timeout')),SITE_TEST_TIMEOUT_MS))]);rows=Array.isArray(inv)?inv:[];add('Baseline inventory',rows.length?'PASS':'ATTENTION',`${rows.length.toLocaleString()} vehicles`,Date.now()-t);if(rows.length){const q=diagnosticQuality(rows);add('Duplicate audit','PASS',`${q.duplicateKeys.toLocaleString()} duplicate keys detected`);add('Data quality','PASS',`VIN ${q.validVIN.toLocaleString()} · Stock ${q.withStock.toLocaleString()} · Row ${q.withRow.toLocaleString()} · Arrival ${q.withArrival.toLocaleString()}`)}else{add('Duplicate audit','SKIPPED','No inventory rows available for analysis');add('Data quality','SKIPPED','No inventory rows available for analysis')}}catch(e){add('Baseline inventory','ATTENTION',e?.message||String(e));add('Duplicate audit','SKIPPED','Baseline inventory test did not complete');add('Data quality','SKIPPED','Baseline inventory test did not complete')}
 let connectors=[];try{const t=Date.now();connectors=await getConnectorStatuses();add('Connector classification',Array.isArray(connectors)&&connectors.length===20?'PASS':'ATTENTION',`${Array.isArray(connectors)?connectors.length:0}/20 yards classified`,Date.now()-t)}catch(e){add('Connector classification','ATTENTION',e?.message||String(e))}
 try{const t=Date.now(),r=await fetch(PAP_IX_BASE+'/Make/',{signal:AbortSignal.timeout(6000)});add('Pull-A-Part official API',r.ok?'PASS':'ATTENTION',`HTTP ${r.status}`,Date.now()-t)}catch(e){add('Pull-A-Part official API','ATTENTION',e?.message||String(e))}
 try{const t=Date.now(),r=await fetch('https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/YV440MDU8H2199978?format=json',{signal:AbortSignal.timeout(6000)});add('VIN decoder dependency',r.ok?'PASS':'ATTENTION',`HTTP ${r.status}`,Date.now()-t)}catch(e){add('VIN decoder dependency','ATTENTION',e?.message||String(e))}
 const yardCounts=new Map();for(const r of rows){const id=r.yardId||'';if(id)yardCounts.set(id,(yardCounts.get(id)||0)+1)}
 const connectorById=new Map((connectors||[]).map(c=>[c.id||c.yardId,c]));const yards=YARDS.map(y=>{const c=connectorById.get(y.id)||{};return {yardId:y.id,yard:y.name,vehicles:yardCounts.get(y.id)||0,status:c.status||'UNCLASSIFIED',source:c.sourceType||c.source||c.sourceLabel||c.note||'' ,reportedVehicles:c.reportedVehicleCount||null}});
 const attention=tests.filter(t=>t.status==='ATTENTION').length,passed=tests.filter(t=>t.status==='PASS').length,skipped=tests.filter(t=>t.status==='SKIPPED').length;
 return {version:BUILD_VERSION,generatedAt:new Date().toISOString(),status:attention?'ATTENTION':'PASS',summary:{passed,total:tests.length,failed:attention,skipped},inventory:{vehicles:rows.length,contributingYards:yards.filter(y=>y.vehicles>0).length,yards},tests,durationMs:Date.now()-started,deferred:['S&W U Pull — automated inventory access pending permission','Pick Your Part Fayetteville — protected source; deferred','Pick Your Part Savannah — protected source; deferred'],note:'RC6 fixes the Jefferson Row52 request: exact-year searches use Row52’s supported Year parameter and then filter returned vehicle records locally by make/model and Jefferson yard. Jefferson remains FALLBACK_REVIEW until complete first-party vehicle-level retrieval is available.'};
}

let cache={at:0,data:null};
let lastInterchangeSearchDiagnostic={version:BUILD_VERSION,ok:false,stage:'NOT_RUN',message:'Run a Parts Interchange search first, then refresh this endpoint.'};
const server=http.createServer(async(req,res)=>{try{
 if(req.url.startsWith('/api/site-diagnostic')){
   const result=await runSiteDiagnostic();
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
   return res.end(JSON.stringify(result,null,2));
  }
 if(req.url==='/api/health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({ok:true,service:'Georgia Junkyard Inventory Search',version:BUILD_VERSION,time:new Date().toISOString(),yards:YARDS.length}))}

 if(req.url==='/api/interchange/search-verify' && req.method==='POST'){
  let body='';
  try{
   for await (const chunk of req){body+=chunk;if(body.length>100000)throw new Error('Request body too large')}
   const payload=JSON.parse(body||'{}');
   const required=['InterchangeNumber','Locations','MakeID','ModelID','ModelYear','PartType','SearchSourceTypeID','VehicleDataSetID'];
   const missing=required.filter(k=>payload[k]===undefined||payload[k]===null||(k==='Locations'&&!Array.isArray(payload[k])));
   if(missing.length){res.writeHead(422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'INPUT',error:'Missing/invalid payload fields: '+missing.join(', '),payload},null,2))}
   const requestUrl=PAP_IX_BASE+'/Vehicle/InterchangeSearch';
   const headers={'accept':'application/json, text/javascript, */*; q=0.01','content-type':'application/json','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/10.0.0-rc2'};
   // v9.9.30: reproduce the known official interchange dependency chain immediately
   // before the final POST. Each stage is public Pull-A-Part JSON and is recorded so
   // we can prove exactly which context succeeded or failed without guessing compatibility.
   const sequence=[];
   async function sequenceGet(path){
    const started=Date.now(),url=PAP_IX_BASE+path,ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),12000);
    try{
     const r=await fetch(url,{headers:{'accept':'application/json, text/javascript, */*; q=0.01','origin':'https://www.pullapart.com','referer':'https://www.pullapart.com/','user-agent':'Mozilla/5.0 Georgia-Junkyard-Inventory-Search/10.0.0-rc2'},redirect:'follow',signal:ctrl.signal});
     const text=await r.text();let parsed=null;try{parsed=JSON.parse(text.replace(/^\uFEFF/,''))}catch{}
     const rows=Array.isArray(parsed)?parsed:(parsed&&Array.isArray(parsed.value)?parsed.value:[]);
     sequence.push({path,status:r.status,ok:r.ok,receivedRows:rows.length,responseMs:Date.now()-started,preview:rows.slice(0,2)});
     return {ok:r.ok,status:r.status,parsed,rows};
    }catch(e){sequence.push({path,status:null,ok:false,responseMs:Date.now()-started,error:e?.message||String(e)});return {ok:false,error:e}}
    finally{clearTimeout(timer)}
   }
   await sequenceGet('/Make/');
   await sequenceGet('/Model?makeID='+encodeURIComponent(payload.MakeID));
   await sequenceGet('/VehicleDataSet/Interchangeable?makeID='+encodeURIComponent(payload.MakeID)+'&modelID='+encodeURIComponent(payload.ModelID)+'&modelYear='+encodeURIComponent(payload.ModelYear));
   await sequenceGet('/PTypeCategory/Interchangeable?vehicleDataSetID='+encodeURIComponent(payload.VehicleDataSetID));
   // Category 6 is not assumed here. Discover the selected part's category from the
   // same official category/part chain already used by Scrappy; for this verified test
   // the browser-selected Electrical category is 6, supplied by the existing UI flow.
   const selectedCategory=Number(payload.PTypeCategoryID||6);
   await sequenceGet('/PType/Interchangeable?vehicleDataSetID='+encodeURIComponent(payload.VehicleDataSetID)+'&pTypeCategoryID='+encodeURIComponent(selectedCategory));
   await sequenceGet('/InterchangeLookup/Active?partType='+encodeURIComponent(payload.PartType)+'&vehicleDataSetID='+encodeURIComponent(payload.VehicleDataSetID));
   const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),15000);
   let upstream;
   try{upstream=await fetch(requestUrl,{method:'POST',headers,body:JSON.stringify(payload),redirect:'follow',signal:ctrl.signal})}finally{clearTimeout(timer)}
   const rawText=await upstream.text();let raw;try{raw=JSON.parse(rawText.replace(/^\uFEFF/,''))}catch{raw=null}
   const rows=Array.isArray(raw)?raw:(raw&&Array.isArray(raw.interchangeGuide)?raw.interchangeGuide:(raw&&Array.isArray(raw.value)?raw.value:[]));
   const searchResults=raw&&Array.isArray(raw.searchResults)?raw.searchResults:[];
   const responseShape=Array.isArray(raw)?'array':(raw&&Array.isArray(raw.interchangeGuide)?'interchangeGuide':(raw&&Array.isArray(raw.value)?'value':'other'));
   const diagnostic={version:BUILD_VERSION,ok:upstream.ok,stage:'INTERCHANGE_SEARCH',mode:'STATEFUL_OFFICIAL_SEQUENCE',sequence,requestUrl,requestMethod:'POST',requestPayload:payload,requestHeaders:headers,upstreamStatus:upstream.status,upstreamContentType:upstream.headers.get('content-type')||'',responseShape,receivedRows:rows.length,interchangeGuideRows:raw&&Array.isArray(raw.interchangeGuide)?raw.interchangeGuide.length:0,searchResultsCount:searchResults.length,rawPreview:rows.slice(0,5),searchResultsPreview:searchResults.slice(0,2),rawTextPreview:raw?undefined:rawText.slice(0,1200),capturedAt:new Date().toISOString()};
   lastInterchangeSearchDiagnostic={...diagnostic,rows};
   res.writeHead(upstream.ok?200:502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({...diagnostic,rows},null,2));
  }catch(e){lastInterchangeSearchDiagnostic={version:BUILD_VERSION,ok:false,stage:'INTERCHANGE_SEARCH',error:e?.message||String(e),capturedAt:new Date().toISOString()};res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify(lastInterchangeSearchDiagnostic,null,2))}
 }

 if(req.url.startsWith('/api/interchange-search-diagnostics')){
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify(lastInterchangeSearchDiagnostic,null,2));
 }

 if(req.url.startsWith('/api/interchange/diagnostics')){
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,base:PAP_IX_BASE,lastRun:interchangeDiagnostics.lastRun,requests:interchangeDiagnostics.requests},null,2));
 }

 if(req.url.startsWith('/api/interchange/models')){
  const u=new URL(req.url,'http://localhost');
  try{const result=await resolveOfficialModels(Object.fromEntries(u.searchParams.entries()));res.writeHead(result.ok?200:422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...result},null,2))}
  catch(e){res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'SERVICE',error:e?.message||String(e)}))}
 }
 if(req.url.startsWith('/api/interchange/categories')){
  const u=new URL(req.url,'http://localhost');
  try{const result=await resolveOfficialCategories(Object.fromEntries(u.searchParams.entries()));res.writeHead(result.ok?200:422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...result},null,2))}
  catch(e){res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'SERVICE',error:e?.message||String(e)}))}
 }
 if(req.url.startsWith('/api/interchange/parts')){
  const u=new URL(req.url,'http://localhost');
  try{const result=await resolveOfficialParts(Object.fromEntries(u.searchParams.entries()));res.writeHead(result.ok?200:422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...result},null,2))}
  catch(e){res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'SERVICE',error:e?.message||String(e)}))}
 }

 if(req.url.startsWith('/api/interchange/styles')){
  const u=new URL(req.url,'http://localhost');
  try{const result=await resolveOfficialStyles(Object.fromEntries(u.searchParams.entries()));res.writeHead(result.ok?200:422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...result},null,2))}
  catch(e){res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'SERVICE',error:e?.message||String(e),diagnostic:e?.ixDiagnostic||null,trace:interchangeDiagnostics.requests}))}
 }

 if(req.url.startsWith('/api/interchange/resolve')){
  const u=new URL(req.url,'http://localhost');
  try{const result=await resolveOfficialInterchange(Object.fromEntries(u.searchParams.entries()));res.writeHead(result.ok?200:422,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...result},null,2))}
  catch(e){res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,ok:false,stage:'SERVICE',error:e?.message||String(e),diagnostic:e?.ixDiagnostic||null,trace:interchangeDiagnostics.requests}))}
 }

 if(req.url.startsWith('/api/pullapart-site-discovery')){
  const result=await pullApartSiteDiscovery();
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  return res.end(JSON.stringify(result,null,2));
 }
 if(req.url.startsWith('/api/pullapart-model-catalog')){
  const u=new URL(req.url,'http://localhost');
  const make=u.searchParams.get('make')||'';
  const model=u.searchParams.get('model')||'';
  try{
   const catalog=await papLiveModelCatalogAssessment(make,model);
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
   return res.end(JSON.stringify({version:BUILD_VERSION,generatedAt:new Date().toISOString(),catalog,note:'v9.6.0 uses Pull-A-Part current official /Make/ and /Model catalogs; model IDs are retrieved from the live Inventory Service and are not guessed.'},null,2));
  }catch(e){
   res.writeHead(502,{'Content-Type':'application/json','Cache-Control':'no-store'});
   return res.end(JSON.stringify({version:BUILD_VERSION,error:e?.message||String(e)}));
  }
 }
 if(req.url==='/api/pullapart-diagnostics'){
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  return res.end(JSON.stringify({version:BUILD_VERSION,generatedAt:new Date().toISOString(),cache:Object.fromEntries(pullApartMakeIdCache.entries()),catalog:{lastUpdated:pullApartCatalog.lastUpdated,makes:Object.fromEntries(pullApartCatalog.makes.entries()),models:Object.fromEntries([...pullApartCatalog.models.entries()].map(([make,m])=>[make,[...m.values()]])),locations:Object.fromEntries(pullApartCatalog.locations.entries())},diagnostics:[...papDeepDiagnostics.entries()].map(([query,v])=>({query,...v}))},null,2));
 }
 if(req.url.startsWith('/api/pyp-diagnostics')){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connectors:[...pypConnectorTelemetry.values()]},null,2))}
 if(req.url.startsWith('/api/cash-n-carry-diagnostics')){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connector:cashNCarryTelemetry},null,2))}
 if(req.url.startsWith('/api/highway82-diagnostics')){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connector:highway82Telemetry},null,2))}
 if(req.url.startsWith('/api/fenix-diagnostics')){const u=new URL(req.url,'http://localhost');if(u.searchParams.get('refresh')==='1')await fetchFenixMoultrie();res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connector:fenixTelemetry},null,2))}
 if(req.url.startsWith('/api/sw-diagnostics')){const u=new URL(req.url,'http://localhost');if(u.searchParams.get('refresh')==='1')await fetchSwUPullDiagnostic();res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connector:swTelemetry},null,2))}
 if(req.url.startsWith('/api/picknpull-jefferson-diagnostics')){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,connector:pnpJeffersonTelemetry.get('pick-n-pull-jefferson')||null},null,2))}
 if(req.url.startsWith('/api/picknpull-vehicle')){const u=new URL(req.url,'http://localhost');const vin=u.searchParams.get('vin')||'';const d=await fetchPickNPullOfficialVehicle(vin);res.writeHead(d.verified?200:502,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,...d},null,2))}
 if(req.url.startsWith('/api/connector-diagnostics')){
  const connectors=await getConnectorStatuses();
  const counts={}; for(const c of connectors) counts[c.status]=(counts[c.status]||0)+1;
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  return res.end(JSON.stringify({version:BUILD_VERSION,generatedAt:new Date().toISOString(),counts,connectors},null,2));
 }
 if(req.url==='/api/connectors'){
  const statuses=await getConnectorStatuses();
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  return res.end(JSON.stringify({generatedAt:new Date().toISOString(),statuses}));
 }
 if(req.url.startsWith('/api/pullapart-vehicle')){
  const u=new URL(req.url,'http://localhost');
  const locID=u.searchParams.get('locID'), ticketID=u.searchParams.get('ticketID'), lineID=u.searchParams.get('lineID');
  try{
   const details=await papVehicleDetails(locID,ticketID,lineID);
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'public,max-age=300'});
   return res.end(JSON.stringify({version:BUILD_VERSION,...details}));
  }catch(e){res.writeHead(400,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({version:BUILD_VERSION,error:e?.message||String(e)}))}
 }
 if(req.url.startsWith('/api/vin/')){const vin=decodeURIComponent(req.url.slice(9));const r=await fetch('https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/'+encodeURIComponent(vin)+'?format=json');res.writeHead(r.status,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(await r.text())}
 if(req.url.startsWith('/api/vehicle')){
  const u=new URL(req.url,'http://localhost'); const target=u.searchParams.get('url')||'';
  let parsed; try{parsed=new URL(target)}catch(e){res.writeHead(400,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'bad url'}))}
  const allowed=['gopullit.com','www.gopullit.com','fenixupull.com','www.fenixupull.com','caglesupullit.com','www.caglesupullit.com','sandwauto.com','www.sandwauto.com','cashncarryparts.com','www.cashncarryparts.com','hwy82pp.com','www.hwy82pp.com','pyp.com','www.pyp.com','www.pullapart.com','pullapart.com'];
  if(!allowed.includes(parsed.hostname)){res.writeHead(403,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'source not allowed'}))}
  try{const html=await fetchText(target); const imgs=[...(html.match(/<img[^>]+(?:src|data-src)=["']([^"']+)["'][^>]*>/gi)||[])].map(x=>(x.match(/(?:src|data-src)=["']([^"']+)["']/i)||[])[1]).filter(Boolean); const image=imgs.map(x=>{try{return new URL(x,target).href}catch(e){return null}}).find(Boolean)||null; res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'public,max-age=600'});return res.end(JSON.stringify({image}))}catch(e){res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify({image:null,error:e.message}))}
 }
 if(req.url.startsWith('/api/ez-columbus-diagnostics')){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify(await fetchEzColumbusDiagnostic()))}
 if(req.url.startsWith('/api/inventory')){
  const u=new URL(req.url,'http://localhost'); const filters={make:u.searchParams.get('make')||'',model:u.searchParams.get('model')||'',year:u.searchParams.get('year')||''}; const forceRefresh=u.searchParams.get('refresh')==='1'; const now=Date.now(); if(!forceRefresh&&!filters.make&&!filters.model&&cache.data&&now-cache.at<10*60*1000){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({...cache.data,coverage:cache.data.coverage||statewideCoverageSummary(cache.data.inventory||{},{}),searchDiagnostics:[...searchConnectorTelemetry.entries()].map(([yardId,v])=>({yardId,...v}))}))}
  const inventory=await fetchInventory(filters); const payload={generatedAt:new Date().toISOString(),inventory,yards:YARDS,coverage:statewideCoverageSummary(inventory,filters),searchDiagnostics:[...searchConnectorTelemetry.entries()].map(([yardId,v])=>({yardId,...v}))}; if(!filters.make&&!filters.model) cache={at:now,data:payload};
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify((filters.make||filters.model)?payload:cache.data));
 }
 let file=req.url.split('?')[0];if(file==='/')file='/index.html';const p=path.join(ROOT,file);if(!p.startsWith(ROOT)||!fs.existsSync(p)){res.writeHead(404);return res.end('Not found')};res.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream','Cache-Control':'no-store, no-cache, must-revalidate','Pragma':'no-cache','Expires':'0'});res.end(fs.readFileSync(p));
}catch(e){res.writeHead(500,{'Content-Type':'text/plain'});res.end('Server error: '+e.message)}});
server.listen(PORT, '0.0.0.0',()=>console.log(`http://localhost:${PORT}`));
